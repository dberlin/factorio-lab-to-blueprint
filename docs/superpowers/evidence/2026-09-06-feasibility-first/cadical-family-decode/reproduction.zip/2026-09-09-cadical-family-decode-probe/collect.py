"""Collect exact baseline family/model inputs; diagnostic, not acceptance."""
import ast
import importlib
import inspect
import json
import sys
import textwrap
import time
from collections import Counter
from dataclasses import asdict
from pathlib import Path
from pydantic import TypeAdapter

name = sys.argv[1]
geometry = importlib.import_module(name + ".family_geometry")
selector = importlib.import_module(name + ".template_cadical")
paths = importlib.import_module(name + ".template_paths")
root = Path(__file__).parent
problem = TypeAdapter(paths.TemplateProblem).validate_json(
    (root.parent / "2026-09-09-cadical-interface-static/problem.json").read_text()
)
cases = []
models = []

def record(left, right, left_levels, right_levels, owners, rectangles):
    cases.append({"left": asdict(left), "right": asdict(right),
                  "left_levels": left_levels, "right_levels": right_levels,
                  "owners": sorted(owners), "rectangles": rectangles})

def record_model(model, selected):
    if not models:
        models.append({"model": model, "selected": selected})

source = textwrap.dedent(inspect.getsource(geometry.PrimitiveIndex.family))
lines = []
inserted = 0
for line in source.splitlines():
    if line.strip().startswith("if not any("):
        indent = line[:len(line) - len(line.lstrip())]
        lines.append(indent + "_record_relation(self.primitives[a], other.primitives[b], self.domain.levels, other.domain.levels, owners, rectangles)")
        inserted += 1
    lines.append(line)
assert inserted == 1
geometry.__dict__["_record_relation"] = record
exec(compile(ast.parse("\n".join(lines)), "<relation-event-corpus>", "exec"), geometry.__dict__)
geometry.PrimitiveIndex.family = geometry.__dict__.pop("family")
source = inspect.getsource(selector.select)
lines = []
inserted = 0
for line in source.splitlines():
    lines.append(line)
    if line.strip() == "selected = factors.select(model)":
        indent = line[:len(line) - len(line.lstrip())]
        lines.append(indent + "_record_model(model, selected)")
        inserted += 1
assert inserted == 1
selector.__dict__["_record_model"] = record_model
exec(compile(ast.parse("\n".join(lines)), "<native-model-corpus>", "exec"), selector.__dict__)
budget = selector.WorkBudget(time.monotonic() + 60)
stats = selector.SolveStats()
outcome, reason = "GEOMETRY_COMPLETE", None
try:
    selector.select(problem, budget, stats)
except selector.ExperimentRefusal as failure:
    outcome, reason = failure.reason, failure.detail
(root / "relations.json").write_text(json.dumps(cases))
(root / "models.json").write_text(json.dumps(models))
report = {"scope": "diagnostic event inputs only; no profiler; no frozen mutation",
          "revision": name, "relations": len(cases), "models": len(models),
          "primitive_pairs": dict(Counter(c["left"]["kind"]+c["right"]["kind"] for c in cases)),
          "outcome": outcome, "reason": reason, "work": budget.counts, "stats": asdict(stats)}
(root / "corpus-report.json").write_text(json.dumps(report, indent=2))
print(json.dumps({k:v for k,v in report.items() if k != "stats"}, sort_keys=True))
