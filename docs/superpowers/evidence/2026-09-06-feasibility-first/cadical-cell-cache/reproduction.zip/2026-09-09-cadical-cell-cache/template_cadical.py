"""Experiment-only exact-domain SAT selection; external hard deadline required."""

from __future__ import annotations

import time
from collections.abc import Callable, Iterator
from dataclasses import dataclass, field
from itertools import combinations

from pysat.card import CardEnc, EncType
from pysat.solvers import Cadical195

from .template_budget import ExperimentRefusal, WorkBudget
from .template_paths import (
    Cell,
    Domain,
    FixedPath,
    TemplateProblem,
    _adapter,
    _compatible,
    _FixedIndex,
    _middle,
    _owned,
    _path_error,
    domains,
)

MAXIMUM_ROUNDS = 2000
MAXIMUM_COLLISION_CUTS = 20000
MAXIMUM_CLAUSES = 20000000
CONFLICTS_PER_CALL = 1000
DECISIONS_PER_CALL = 10000

SOLVER_RULES = {
    "backend": "python-sat==1.9.dev15; Cadical195 (CaDiCaL 1.9.5)",
    "seed": 0,
    "cardinality": "sequential-counter",
    "collision_encoding": "candidate implies cached domain-cell occupancy; AMO over occupancy",
    "checkpoint": "existing counters before/after native calls; no function profiling",
    "candidate_order": "complete original integer ID order; no deduplication",
    "preparation": "height-factored XY interval-row occupancy bitsets; lazy static legality",
    "index_accounting": "merge/event scans: predicates; adapter cells: audit_cells",
    "membership_accounting": "row lookups, binary steps, column comparisons: predicates",
    "collision_queries": "first forbidden cell; immutable occupancy and ownership cache",
    "maximum_rounds": MAXIMUM_ROUNDS,
    "maximum_collision_cuts": MAXIMUM_COLLISION_CUTS,
    "maximum_clauses": MAXIMUM_CLAUSES,
    "conflicts_per_call": CONFLICTS_PER_CALL,
    "decisions_per_call": DECISIONS_PER_CALL,
    "deadline": "external process supervisor; original end-to-end deadline never resets",
}


def cells(points: tuple[Cell, ...]) -> Iterator[Cell]:
    """Expand orthogonal segments; retain retraces but not consecutive duplicates."""
    yield points[0]
    for a, b in zip(points, points[1:], strict=False):
        axes = [axis for axis in range(3) if a[axis] != b[axis]]
        if not axes:
            continue
        if len(axes) != 1:
            raise ValueError("nonorthogonal template segment")
        axis = axes[0]
        step = 1 if a[axis] < b[axis] else -1
        for value in range(a[axis] + step, b[axis] + step, step):
            point = list(a)
            point[axis] = value
            yield point[0], point[1], point[2]


def members(mask: int) -> Iterator[int]:
    while mask:
        bit = mask & -mask
        yield bit.bit_length() - 1
        mask ^= bit


@dataclass(frozen=True)
class IntervalRow:
    coordinates: tuple[int, ...]
    masks: tuple[int, ...]

    def occupants(self, coordinate: int, budget: WorkBudget) -> int:
        lo, hi = 0, len(self.coordinates)
        while lo < hi:
            budget.charge("predicates")
            middle = (lo + hi) // 2
            if self.coordinates[middle] <= coordinate:
                lo = middle + 1
            else:
                hi = middle
        return self.masks[lo - 1] if lo else 0


class CellIndex:
    """Exact occupancy of every original ID, without materializing every height."""

    def __init__(self, domain: Domain, budget: WorkBudget) -> None:
        self.domain = domain
        self.middle: dict[tuple[int, int], IntervalRow] = {}
        events: dict[tuple[int, int], dict[int, int]] = {}
        self.ground: dict[Cell, int] = {}
        self.columns: dict[tuple[int, int], list[tuple[int, int]]] = {}
        self.level_indices = {z: i for i, z in enumerate(domain.levels)}
        levels = len(domain.levels)
        all_levels = (1 << levels) - 1
        source_masks = [0] * 5
        sink_masks = [0] * 5
        for combo in range(len(domain.lengths)):
            budget.check()
            source_adapter, rest = divmod(combo, 5 * len(domain.shapes))
            sink_adapter, shape = divmod(rest, len(domain.shapes))
            bit = 1 << (combo * levels)
            source_masks[source_adapter] |= bit
            sink_masks[sink_adapter] |= bit
            start = _adapter(domain.obligation.source, source_adapter)[-1]
            finish = _adapter(domain.obligation.sink, sink_adapter)[-1]
            points = _middle(
                (start[0], start[1], 0), (finish[0], finish[1], 0), domain.shapes[shape]
            )
            # Union one candidate's collinear intervals before XOR events:
            # overlapping/retraced segments must not cancel its occupancy bit.
            intervals: dict[tuple[int, int], list[tuple[int, int]]] = {}
            for a, b in zip(points, points[1:], strict=False):
                axis = 0 if a[1] == b[1] else 1
                key = axis, a[1 - axis]
                intervals.setdefault(key, []).append((min(a[axis], b[axis]), max(a[axis], b[axis])))
            for key, spans in intervals.items():
                row = events.setdefault(key, {})
                spans.sort()
                lo, hi = spans[0]
                for start, end in spans[1:]:
                    budget.charge("predicates")
                    if start <= hi + 1:
                        hi = max(hi, end)
                    else:
                        row[lo] = row.get(lo, 0) ^ bit
                        row[hi + 1] = row.get(hi + 1, 0) ^ bit
                        lo, hi = start, end
                budget.charge("predicates")
                row[lo] = row.get(lo, 0) ^ bit
                row[hi + 1] = row.get(hi + 1, 0) ^ bit
        for key, row in events.items():
            positions = tuple(sorted(row))
            active = 0
            masks: list[int] = []
            for coordinate in positions:
                budget.charge("predicates")
                active ^= row[coordinate]
                masks.append(active)
            assert active == 0
            self.middle[key] = IntervalRow(positions, tuple(masks))
        for endpoint, masks in (
            (domain.obligation.source, source_masks),
            (domain.obligation.sink, sink_masks),
        ):
            for adapter, mask in enumerate(masks):
                points = _adapter(endpoint, adapter)
                for cell in cells(points):
                    budget.charge("audit_cells")
                    self.ground[cell] = self.ground.get(cell, 0) | mask * all_levels
                tip = points[-1]
                self.columns.setdefault((tip[0], tip[1]), []).append((tip[2], mask))

    def occupants(self, cell: Cell, budget: WorkBudget) -> int:
        budget.charge("predicates", 2)
        result = self.ground.get(cell, 0)
        xy = cell[0], cell[1]
        level_index = self.level_indices.get(cell[2])
        if level_index is not None:
            for axis in range(2):
                budget.charge("predicates")
                row = self.middle.get((axis, cell[1 - axis]))
                if row is not None:
                    result |= row.occupants(cell[axis], budget) << level_index
        for endpoint_z, mask in self.columns.get(xy, ()):
            level_mask = 0
            for i, height in enumerate(self.domain.levels):
                budget.charge("predicates")
                if min(endpoint_z, height) <= cell[2] <= max(endpoint_z, height):
                    level_mask |= 1 << i
            result |= mask * level_mask
        return result


@dataclass
class SolveStats:
    started: float = field(default_factory=time.monotonic)
    preparation_seconds: float = 0
    candidate_variables: int = 0
    auxiliary_variables: int = 0
    occupancy_variables: int = 0
    clauses: int = 0
    rounds: int = 0
    native_calls: int = 0
    solver_seconds: float = 0
    collision_cuts: int = 0
    static_cuts: int = 0
    self_rejections: int = 0
    selected_candidate_ids: dict[int, int] = field(default_factory=dict)


def _identity_conflict(a: FixedPath, b: FixedPath, budget: WorkBudget) -> bool:
    for first in (a.source, a.sink):
        for second in (b.source, b.sink):
            budget.charge("predicates")
            if first.port_id == second.port_id and (
                first.cell != second.cell or not _owned(a, b, first.cell, budget)
            ):
                return True
    return False


def select(
    problem: TemplateProblem,
    budget: WorkBudget,
    stats: SolveStats | None = None,
    checkpoint: Callable[[str], None] | None = None,
) -> dict[int, tuple[Cell, ...]]:
    """SAT is only a relaxation until every selected complete path is checked."""
    stats = stats if stats is not None else SolveStats()
    if checkpoint is not None:
        checkpoint("preparation")
    ds = domains(problem, budget)
    if not ds:
        return {}
    if any(d.count == 0 for d in ds):
        raise ExperimentRefusal("TEMPLATE_FAMILY_EXHAUSTED", "empty complete candidate domain")
    fixed_index = _FixedIndex(problem, budget)
    representatives = [
        FixedPath((), d.obligation.source, d.obligation.sink, d.obligation.item) for d in ds
    ]
    for a, b in combinations(representatives, 2):
        if _identity_conflict(a, b, budget):
            raise ExperimentRefusal(
                "TEMPLATE_FAMILY_EXHAUSTED", "inconsistent global port identities"
            )
    for a in representatives:
        for b in problem.fixed_paths:
            if _identity_conflict(a, b, budget):
                raise ExperimentRefusal(
                    "TEMPLATE_FAMILY_EXHAUSTED", "inconsistent fixed/global port identities"
                )
    indexes = [CellIndex(d, budget) for d in ds]
    fixed_cells: list[set[Cell]] = []
    for path in problem.fixed_paths:
        expanded = set(cells(path.points))
        budget.charge("audit_cells", len(expanded))
        fixed_cells.append(expanded)
    offsets: list[int] = []
    count = 0
    for d in ds:
        offsets.append(count + 1)
        budget.charge("candidates", d.count)
        count += d.count
    stats.candidate_variables = count
    top_id = count
    cuts: set[tuple[Cell, tuple[int, ...]]] = set()
    static_cuts: set[tuple[int, Cell]] = set()
    occupancy_variables: dict[tuple[int, Cell], int] = {}
    cell_queries: dict[Cell, tuple[dict[int, int], bool]] = {}
    with Cadical195(use_timer=True) as solver:
        solver.configure({"seed": 0})

        def add_clause(clause: list[int]) -> None:
            budget.check()
            if stats.clauses >= MAXIMUM_CLAUSES:
                raise ExperimentRefusal("POLICY_BOUND", "CaDiCaL clause cap")
            solver.add_clause(clause)
            stats.clauses += 1

        def cardinality(literals: list[int], *, exactly_one: bool = False) -> None:
            nonlocal top_id
            budget.check()
            encode = CardEnc.equals if exactly_one else CardEnc.atmost
            encoded = encode(lits=literals, bound=1, top_id=top_id, encoding=EncType.seqcounter)
            top_id = max(top_id, encoded.nv)
            stats.auxiliary_variables = top_id - count
            for clause in encoded.clauses:
                add_clause(clause)

        def occupancy_literal(di: int, cell: Cell, mask: int) -> int:
            nonlocal top_id
            key = (di, cell)
            existing = occupancy_variables.get(key)
            if existing is not None:
                return existing
            top_id += 1
            literal = top_id
            occupancy_variables[key] = literal
            stats.occupancy_variables += 1
            stats.auxiliary_variables = top_id - count
            # Exactly one candidate is already selected in each domain.
            # Forward implications suffice under existential occupancy variables:
            # any selected occupant forces this literal; otherwise it may be false.
            for ci in members(mask):
                add_clause([-offsets[di] - ci, literal])
            return literal

        for offset, d in zip(offsets, ds, strict=True):
            cardinality(list(range(offset, offset + d.count)), exactly_one=True)
        stats.preparation_seconds = time.monotonic() - stats.started
        for _ in range(MAXIMUM_ROUNDS):
            budget.charge("assignments")
            stats.rounds += 1
            status = None
            while status is None:
                budget.check()
                solver.conf_budget(CONFLICTS_PER_CALL)
                solver.dec_budget(DECISIONS_PER_CALL)
                stats.native_calls += 1
                if checkpoint is not None:
                    checkpoint("native-call")
                started = time.monotonic()
                status = solver.solve_limited()
                stats.solver_seconds += time.monotonic() - started
                budget.check()
                if checkpoint is not None:
                    checkpoint("checking-model" if status is True else "native-return")
            if status is False:
                raise ExperimentRefusal(
                    "TEMPLATE_FAMILY_EXHAUSTED",
                    "CaDiCaL UNSAT on full original domains and sound cuts",
                )
            model = solver.get_model()
            if model is None:
                raise ExperimentRefusal("SOLVER_UNKNOWN", "SAT without a model")
            positive = {literal for literal in model if 0 < literal <= count}
            selected: list[int] = []
            for offset, d in zip(offsets, ds, strict=True):
                choices = [ci for ci in range(d.count) if offset + ci in positive]
                if len(choices) != 1:
                    raise AssertionError("SAT assignment violates exactly-one domain contract")
                selected.append(choices[0])
            geometries = [d._decode(ci, budget) for d, ci in zip(ds, selected, strict=True)]
            occupied: list[set[Cell]] = []
            rejected = False
            for di, geometry in enumerate(geometries):
                budget.check()
                sequence = list(cells(geometry.path.points))
                budget.charge("audit_cells", len(sequence))
                occupied.append(set(sequence))
                path_error = _path_error(geometry, budget)
                if path_error:
                    add_clause([-offsets[di] - selected[di]])
                    stats.self_rejections += 1
                    rejected = True
                    continue
                if len(sequence) != len(occupied[-1]):
                    raise AssertionError("canonical path check missed a retrace")
                owned = {
                    e.cell
                    for e in (geometry.path.source, geometry.path.sink)
                    if e in problem.owned_endpoints
                }
                bad_cells = (occupied[-1] - owned) & problem.blocked
                for fixed, fixed_occupied in zip(problem.fixed_paths, fixed_cells, strict=True):
                    for cell in occupied[-1] & fixed_occupied:
                        if not _owned(geometry.path, fixed, cell, budget):
                            bad_cells.add(cell)
                canonical_error = fixed_index.error(geometry, budget)
                if bool(canonical_error) != bool(bad_cells):
                    raise AssertionError(
                        ("static geometry disagreement", canonical_error, bad_cells)
                    )
                if bad_cells:
                    cell = min(bad_cells)
                    if (di, cell) in static_cuts:
                        raise AssertionError("static cut failed to exclude its candidate")
                    mask = indexes[di].occupants(cell, budget)
                    if not mask & (1 << selected[di]):
                        raise AssertionError("cell index misses selected static collision")
                    for ci in members(mask):
                        add_clause([-offsets[di] - ci])
                    static_cuts.add((di, cell))
                    stats.static_cuts += 1
                    rejected = True
            if rejected:
                continue
            new_cuts = 0
            for i, j in combinations(range(len(ds)), 2):
                cell = next(
                    (
                        cell
                        for cell in sorted(occupied[i] & occupied[j])
                        if not _owned(geometries[i].path, geometries[j].path, cell, budget)
                    ),
                    None,
                )
                if _compatible(geometries[i], geometries[j], budget) != (cell is None):
                    raise AssertionError("independent selected-path collision disagreement")
                if cell is None:
                    continue
                query = cell_queries.get(cell)
                if query is None:
                    occupants = {
                        di: mask
                        for di, index in enumerate(indexes)
                        if (mask := index.occupants(cell, budget))
                    }
                    can_share = any(
                        _owned(representatives[a], representatives[b], cell, budget)
                        for a, b in combinations(occupants, 2)
                    )
                    cell_queries[cell] = occupants, can_share
                else:
                    occupants, can_share = query
                if not occupants.get(i, 0) & (1 << selected[i]) or not occupants.get(j, 0) & (
                    1 << selected[j]
                ):
                    raise AssertionError("cell index misses selected pair collision")
                owners = (i, j) if can_share else tuple(occupants)
                key = (cell, owners)
                if key in cuts:
                    continue
                if len(cuts) >= MAXIMUM_COLLISION_CUTS:
                    raise ExperimentRefusal("POLICY_BOUND", "CaDiCaL collision cut cap")
                cardinality([occupancy_literal(di, cell, occupants[di]) for di in owners])
                cuts.add(key)
                stats.collision_cuts += 1
                new_cuts += 1
            if new_cuts:
                continue
            if any(not _compatible(a, b, budget) for a, b in combinations(geometries, 2)):
                raise AssertionError("invalid model survived existing collision cuts")
            budget.check()
            stats.selected_candidate_ids = {
                d.obligation.ordinal: ci for d, ci in zip(ds, selected, strict=True)
            }
            if checkpoint is not None:
                checkpoint("geometry-complete")
            return {
                d.obligation.ordinal: g.path.points for d, g in zip(ds, geometries, strict=True)
            }
    raise ExperimentRefusal("POLICY_BOUND", "CaDiCaL round cap")
