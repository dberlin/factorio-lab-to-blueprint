"""Causal strip-emitter trace and counterfactual audit; never a factory gate."""

from __future__ import annotations

import json
import time
from collections import defaultdict
from collections.abc import Sequence
from dataclasses import asdict, replace
from fractions import Fraction
from pathlib import Path
from unittest.mock import patch

from pydantic import BaseModel, TypeAdapter

from flab2bp.dsp import catalog
from flab2bp.lab.data import load_vendored
from flab2bp.lab.flow import canonicalize_dataset
from flab2bp.lab.techs import belt_rules_for_url
from flab2bp.layout import routing_domain as rd
from flab2bp.layout.base import PlacedBuilding, Placement
from flab2bp.spec import BuildSpec

from .run_experiment import Case
from .template_audit import audit_placement
from .template_audit_witness import endpoint_ownership_negative
from .template_budget import WorkBudget, WorkLimits
from .template_paths import TemplateProblem
from .transport_first import capture_inventory

ROOT = Path(__file__).parent


class TopologyEndpoint(BaseModel):
    belt: int


class Demand(BaseModel):
    source: TopologyEndpoint | None
    sink: TopologyEndpoint | None


class Topology(BaseModel):
    demands: tuple[Demand, ...]


def predecessors(buildings: Sequence[PlacedBuilding]) -> dict[int, list[int]]:
    incoming: dict[int, list[int]] = defaultdict(list)
    for index, building in enumerate(buildings):
        if building.output_obj is not None:
            incoming[building.output_obj].append(index)
    return incoming


def main() -> None:
    spec = BuildSpec.model_validate_json((ROOT / "frozen/unsprayed-mall.json").read_text())
    cases = TypeAdapter(tuple[Case, ...]).validate_json((ROOT / "frozen/manifest.json").read_text())
    case = next(case for case in cases if case.name == "unsprayed-mall")
    rules = belt_rules_for_url(case.url, canonicalize_dataset(load_vendored()))
    original = rd._flank_lane
    calls: list[dict[str, object]] = []
    created: set[int] = set()

    def flank(
        canvas: rd._Canvas,
        strip: rd.Strip,
        machines: list[int],
        out_lane: list[int],
        lane_y: int,
        item: str,
        rate: Fraction,
        belt_id: int,
        belt_model: int,
        claimed: dict[int, set[int]],
    ) -> int:
        before = predecessors(canvas.buildings)
        result = original(
            canvas, strip, machines, out_lane, lane_y, item, rate, belt_id, belt_model, claimed
        )
        after = predecessors(canvas.buildings)
        changed = {
            target: feeders
            for target, feeders in after.items()
            if target in out_lane and len(feeders) > 1 and len(before.get(target, ())) <= 1
        }
        created.update(changed)
        calls.append(
            {
                "group": strip.group_key,
                "machines": strip.machines,
                "strip": canvas.buildings[machines[0]].owner_strip,
                "new_merges": changed,
                "out_lane": out_lane,
            }
        )
        return result

    with (
        patch.object(rd, "_flank_lane", flank),
        patch.object(rd, "_route_all", side_effect=AssertionError("global router forbidden")),
    ):
        inventory = capture_inventory(spec, rules, time.monotonic() + 60)
    # Boundary fixtures come from the actual saved factory, not synthetic belt IDs.
    buildings = TypeAdapter(tuple[PlacedBuilding, ...]).validate_json(
        (ROOT / "run/buildings.json").read_text()
    )
    incoming = predecessors(buildings)
    targets = {
        target
        for target, parents in incoming.items()
        if catalog.is_belt(buildings[target].item_id)
        and sum(catalog.is_belt(buildings[i].item_id) for i in parents) > 1
    }
    assert created == targets == {14306, 14331, 14798, 14823}
    assert {i for i, strip in enumerate(inventory.strips) if strip.flank_outputs} == {
        38,
        39,
        45,
        46,
    }
    problem = TypeAdapter(TemplateProblem).validate_json((ROOT / "run/problem.json").read_text())
    topology = Topology.model_validate_json((ROOT / "run/captured/topology.json").read_text())
    ports = {
        endpoint.port_id
        for obligation in problem.obligations
        for endpoint in (obligation.source, obligation.sink)
    }
    ports.update(
        endpoint.belt
        for demand in topology.demands
        for endpoint in (demand.source, demand.sink)
        if endpoint is not None
    )
    removed: set[int] = set()
    branches: list[dict[str, object]] = []
    for target in sorted(targets):
        dead: list[set[int]] = []
        for feeder in incoming[target]:
            pending = [feeder]
            ancestors: set[int] = set()
            while pending:
                index = pending.pop()
                if index in ancestors:
                    continue
                ancestors.add(index)
                pending.extend(incoming.get(index, ()))
            if all(
                catalog.is_belt(buildings[i].item_id)
                and buildings[i].input_obj is None
                and i not in ports
                and buildings[i].owner_strip == buildings[target].owner_strip
                for i in ancestors
            ):
                dead.append(ancestors)
        assert len(dead) == 1 and len(dead[0]) == 4
        removed.update(dead[0])
        branches.append(
            {
                "target": target,
                "dead_prefix": sorted(dead[0]),
                "declared_port_overlap": sorted(dead[0] & ports),
            }
        )
    # Counterfactual only: preserve every productive belt, machine, sorter and endpoint;
    # remove the four provably producer-free prefixes and remap all remaining IDs.
    mapping = {
        old: new for new, old in enumerate(i for i in range(len(buildings)) if i not in removed)
    }
    altered: list[PlacedBuilding] = []
    for index, building in enumerate(buildings):
        if index in removed:
            continue
        assert building.input_obj not in removed and building.output_obj not in removed
        altered.append(
            replace(
                building,
                input_obj=mapping[building.input_obj] if building.input_obj is not None else None,
                output_obj=mapping[building.output_obj]
                if building.output_obj is not None
                else None,
            )
        )
    budget = WorkBudget(time.monotonic() + 60, WorkLimits(predicates=100_000_000))
    counterfactual = audit_placement(Placement(tuple(altered)), spec, rules, budget)
    assert counterfactual.passed, counterfactual.findings
    negative = endpoint_ownership_negative(budget)
    assert not negative.passed
    result = {
        "scope": "Diagnostic counterfactual only; source, gate and audit policies unchanged",
        "flank_calls": calls,
        "created_merges": sorted(created),
        "ordinary_strips": len(inventory.strips) - len(calls),
        "dead_branches": branches,
        "removed_belts": len(removed),
        "remaining_buildings": len(altered),
        "counterfactual_emitted_audit": asdict(counterfactual),
        "separate_coincident_vertices_still_refused": asdict(negative),
        "native_calls": 0,
        "full_validator_or_codec_run": False,
    }
    (ROOT / "hypothesis.json").write_text(json.dumps(result, indent=2, default=str))
    print(
        json.dumps(
            {
                k: v
                for k, v in result.items()
                if k
                not in (
                    "flank_calls",
                    "counterfactual_emitted_audit",
                    "separate_coincident_vertices_still_refused",
                )
            }
        )
    )


if __name__ == "__main__":
    main()
