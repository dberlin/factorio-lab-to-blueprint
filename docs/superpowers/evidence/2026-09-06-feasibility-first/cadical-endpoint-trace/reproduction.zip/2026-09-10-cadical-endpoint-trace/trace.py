"""Reconstruct saved emission; record first multi-feeder ownership boundary, no SAT."""

from __future__ import annotations

import hashlib
import json
import time
from collections import defaultdict
from collections.abc import Callable, Sequence
from dataclasses import asdict
from pathlib import Path
from unittest.mock import patch

from pydantic import BaseModel, TypeAdapter

from flab2bp.dsp import catalog
from flab2bp.layout import routing_domain as rd
from flab2bp.layout.base import PlacedBuilding, Placement
from flab2bp.spec import BuildSpec

from . import constructive_control as control
from . import template_runtime as runtime
from .template_budget import WorkBudget, WorkLimits
from .template_cadical import SolveStats
from .template_experiment import absolute_deadline
from .template_paths import Cell, TemplateProblem
from .template_runtime import TemplateConstructor, TemplateRun
from .transport_first import Inventory

ROOT = Path(__file__).parent
SAVED = ROOT.parent / "2026-09-10-cadical-wall-budget"


class SavedResult(BaseModel):
    selected_points: dict[int, tuple[Cell, ...]]


class SourcePolicy(BaseModel):
    source_sha256: dict[str, str]


def merges(buildings: Sequence[PlacedBuilding]) -> list[dict[str, object]]:
    incoming: dict[int, list[int]] = defaultdict(list)
    for index, building in enumerate(buildings):
        target = building.output_obj
        if (
            catalog.is_belt(building.item_id)
            and target is not None
            and catalog.is_belt(buildings[target].item_id)
        ):
            incoming[target].append(index)
    result: list[dict[str, object]] = []
    for target, feeders in incoming.items():
        if len(feeders) < 2:
            continue
        ids = {target, *feeders}
        ids.update(
            parent for index in feeders if (parent := buildings[index].input_obj) is not None
        )
        owner = buildings[target].owner_strip
        result.append(
            {
                "target": target,
                "feeders": feeders,
                "records": {str(i): asdict(buildings[i]) for i in sorted(ids)},
                "strip_bodies": [
                    {"id": i, **asdict(b)}
                    for i, b in enumerate(buildings)
                    if b.owner_strip == owner
                    and not catalog.is_belt(b.item_id)
                    and not catalog.is_sorter(b.item_id)
                ],
            }
        )
    return result


def main() -> None:
    output = ROOT / "run"
    output.mkdir(exist_ok=False)
    saved = SavedResult.model_validate_json((SAVED / "run/captured/result.json").read_text())
    policy = SourcePolicy.model_validate_json((SAVED / "diagnostic-policy.json").read_text())
    for name, digest in policy.source_sha256.items():
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest
    trace: dict[str, object] = {
        "scope": "Saved-selection emission diagnosis only; no solver or gate run",
        "stages": {},
    }
    stages: dict[str, object] = {}
    trace["stages"] = stages
    active: TemplateConstructor | None = None
    selection_calls = 0
    original_capture = control.capture_inventory
    original_finish = TemplateConstructor.finish
    original_settle = control._settle

    def capture(spec: BuildSpec, rules: catalog.BeltAltitudeRules, deadline: float) -> Inventory:
        inventory = original_capture(spec, rules, deadline)
        (output / "inventory.json").write_text(json.dumps(asdict(inventory), default=str))
        return inventory

    def finish(constructor: TemplateConstructor) -> None:
        nonlocal active
        active = constructor
        stages["before_fixed_flights_and_selection"] = merges(constructor.canvas.buildings)
        original_finish(constructor)
        stages["after_selected_path_emission"] = merges(constructor.canvas.buildings)

    def selected(
        problem: TemplateProblem,
        budget: WorkBudget,
        stats: SolveStats | None = None,
        checkpoint: Callable[[str], None] | None = None,
    ) -> dict[int, tuple[Cell, ...]]:
        nonlocal selection_calls
        selection_calls += 1
        assert active is not None
        stages["at_selector_entry"] = merges(active.canvas.buildings)
        assert {o.ordinal for o in problem.obligations} == set(saved.selected_points)
        for obligation in problem.obligations:
            points = saved.selected_points[obligation.ordinal]
            assert points[0] == obligation.source.cell and points[-1] == obligation.sink.cell
        (output / "problem.json").write_bytes(TypeAdapter(TemplateProblem).dump_json(problem))
        return saved.selected_points

    def settle(
        placement: Placement,
        spec: BuildSpec,
        rules: catalog.BeltAltitudeRules,
        template: TemplateRun | None,
        result: dict[str, object],
        destination: Path,
        cancelled: Callable[[], bool],
    ) -> None:
        stages["slot_bound_emission"] = merges(placement.buildings)
        (output / "trace.json").write_text(json.dumps(trace, indent=2, default=str))
        (output / "buildings.json").write_bytes(
            TypeAdapter(tuple[PlacedBuilding, ...]).dump_json(tuple(placement.buildings))
        )
        original_settle(placement, spec, rules, template, result, destination, cancelled)

    budget = WorkBudget(time.monotonic() + 60, WorkLimits(predicates=100_000_000))
    session = TemplateRun(budget, "captured", output / "captured", mode="GEOMETRY_ONLY")
    with (
        patch.object(control, "capture_inventory", capture),
        patch.object(TemplateConstructor, "finish", finish),
        patch.object(runtime, "select", selected),
        patch.object(control, "_settle", settle),
        patch.object(
            rd, "_route_all", side_effect=AssertionError("global router forbidden")
        ) as router,
    ):
        with absolute_deadline(budget):
            result = control.run(
                "unsprayed-mall", reuse=True, capacity_first=True, template=session
            )
        trace["saved_selection_calls"] = selection_calls
        trace["global_router_calls"] = router.call_count
    trace["native_calls"] = session.solve_stats.native_calls
    trace["outcome"] = result["outcome"]
    trace["reason"] = result.get("reason")
    trace["replay_elapsed_s"] = result["elapsed_s"]
    assert trace["native_calls"] == trace["global_router_calls"] == 0
    assert trace["saved_selection_calls"] == 1
    (output / "trace.json").write_text(json.dumps(trace, indent=2, default=str))
    print(json.dumps({key: value for key, value in trace.items() if key != "stages"}))


if __name__ == "__main__":
    main()
