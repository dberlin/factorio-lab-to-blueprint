"""Exact family/projection oracles for the isolated architectural experiment."""

from __future__ import annotations

import json
import random
import time
from fractions import Fraction
from itertools import product

from .template_budget import WorkBudget
from .template_paths import Endpoint, Obligation, TemplateProblem, _compatible, domains


def run() -> dict[str, int | bool]:
    from pysat.solvers import Cadical195

    from .family_cnf import FactorCNF
    from .family_geometry import PrimitiveIndex

    comparisons = projections = families = 0
    rng = random.Random(41)
    for heights, shared in (
        ((0, 0, 0, 0), False),
        ((0, 7, 3, 7), False),
        ((7, 3, 7, 0), False),
        ((7, 7, 7, 7), False),
        ((0, 0, 0, 0), True),
    ):
        budget = WorkBudget(time.monotonic() + 60)
        az, bz, cz, dz = heights
        source = Endpoint((0, 0 if shared else 5, az), (1, 0), 1, 99 if shared else None)
        peer = Endpoint((0, 0, cz) if shared else (10, -5, cz), (0, 1), 3, 99 if shared else None)
        problem = TemplateProblem(
            (
                Obligation(17, "iron", Fraction(1), source, Endpoint((20, 5, bz), (-1, 0), 2)),
                Obligation(91, "iron", Fraction(1), peer, Endpoint((10, 15, dz), (0, -1), 4)),
            ),
            frozenset(),
            (),
            (-4, 8, 24),
            (-4, 8, 24),
            (3, 5, 7, 8, 11),
        )
        ds = domains(problem, budget)
        left, right = (PrimitiveIndex(d, budget) for d in ds)
        combos = {(0, 0)}
        while len(combos) < 8:
            combos.add((rng.randrange(len(ds[0].lengths)), rng.randrange(len(ds[1].lengths))))
        for ca, cb in sorted(combos):
            ga = [ds[0]._decode(ca * 5 + p, budget) for p in range(5)]
            gb = [ds[1]._decode(cb * 5 + q, budget) for q in range(5)]
            discovered = None
            for p, q in product(range(5), repeat=2):
                incompatible = not _compatible(ga[p], gb[q], budget)
                actual = left.incompatible(right, ca, cb, p, q, budget)
                assert actual == incompatible, (heights, shared, ca, cb, p, q)
                comparisons += 1
                if incompatible and discovered is None:
                    discovered = left.family(right, ca, cb, p, q, budget)
            if discovered is None:
                continue
            families += 1
            with Cadical195() as solver:
                cnf = FactorCNF(ds, solver.add_clause, budget)
                assert cnf.forbid(0, 1, discovered) > 0
                assert cnf.forbid(0, 1, discovered) == 0
                for p, q in product(range(5), repeat=2):
                    forbidden = any(
                        a <= p <= b and c <= q <= d for a, b, c, d in discovered.rectangles
                    )
                    assumptions = [cnf.xy[0][ca], cnf.height[0][p], cnf.xy[1][cb], cnf.height[1][q]]
                    assert solver.solve(assumptions=assumptions) != forbidden
                    if forbidden:
                        assert not _compatible(ga[p], gb[q], budget)
                    projections += 1
                # Every member of either mask must really contain its descriptor.
                for index, mask in ((left, discovered.left_mask), (right, discovered.right_mask)):
                    assert mask and mask.bit_length() <= len(index.domain.lengths)
                member_a = [c for c in range(len(ds[0].lengths)) if discovered.left_mask & (1 << c)]
                member_b = [
                    c for c in range(len(ds[1].lengths)) if discovered.right_mask & (1 << c)
                ]
                for a, b in product(member_a[:2], member_b[:2]):
                    for p, q in product(range(5), repeat=2):
                        if any(
                            lo <= p <= hi and start <= q <= end
                            for lo, hi, start, end in discovered.rectangles
                        ):
                            assert not _compatible(
                                ds[0]._decode(a * 5 + p, budget),
                                ds[1]._decode(b * 5 + q, budget),
                                budget,
                            )
                            comparisons += 1
        with Cadical195() as solver:
            cnf = FactorCNF(ds, solver.add_clause, budget)
            cnf.exclude(0, 3)
            for ci in (0, 1, 3, 4, 5, ds[0].count - 1):
                combo, level = divmod(ci, 5)
                assert solver.solve(assumptions=[cnf.xy[0][combo], cnf.height[0][level]]) == (
                    ci != 3
                )
                if ci != 3:
                    model = solver.get_model()
                    assert model is not None and cnf.select(model)[0] == ci
                projections += 1
    assert families > 0
    return {
        "canonical_comparisons": comparisons,
        "sat_projections": projections,
        "families": families,
        "exact_family_projection": True,
    }


if __name__ == "__main__":
    print(json.dumps(run(), sort_keys=True))
