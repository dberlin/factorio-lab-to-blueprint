"""Original mall must reach a replacement model before exhausting refinement work."""

from __future__ import annotations

import json
import time
from pathlib import Path

from pydantic import TypeAdapter

from .template_budget import WorkBudget
from .template_cadical import SolveStats, select
from .template_paths import TemplateProblem


class ReplacementModelRequested(Exception):
    """End the diagnostic before solving the replacement model."""


def run() -> dict[str, int | bool]:
    path = Path(__file__).parent.parent / "2026-09-09-cadical-interface-static/problem.json"
    problem = TypeAdapter(TemplateProblem).validate_json(path.read_text())
    budget = WorkBudget(time.monotonic() + 60)
    stats = SolveStats()

    def checkpoint(phase: str) -> None:
        if phase == "native-call" and stats.rounds == 2:
            raise ReplacementModelRequested

    try:
        _ = select(problem, budget, stats, checkpoint)
    except ReplacementModelRequested:
        pass
    else:
        raise AssertionError("mall probe did not request a replacement model")
    return {
        "replacement_model_requested": True,
        "completed_families": stats.families,
        "collision_prohibitions": stats.collision_cuts,
        "predicates": budget.counts["predicates"],
    }


if __name__ == "__main__":
    print(json.dumps(run(), sort_keys=True))
