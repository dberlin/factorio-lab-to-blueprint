"""Exhaustive small primitive relations, independent cells, and raw path unions."""

from __future__ import annotations

import json
import time
from fractions import Fraction
from itertools import product

from .family_geometry import Primitive, PrimitiveIndex, relation
from .template_budget import WorkBudget
from .template_cadical import cells
from .template_paths import Cell, Endpoint, Obligation, TemplateProblem, domains


def reference(primitive: Primitive, height: int) -> set[Cell]:
    lo, hi = primitive.lo, primitive.hi
    if primitive.kind == "M":
        lo, hi = (*lo[:2], height), (*hi[:2], height)
    elif primitive.kind == "R":
        lo = (*lo[:2], min(primitive.endpoint_z, height))
        hi = (*lo[:2], max(primitive.endpoint_z, height))
    return set(product(range(lo[0], hi[0] + 1), range(lo[1], hi[1] + 1), range(lo[2], hi[2] + 1)))


def run() -> dict[str, int | bool]:
    levels = (3, 5, 7, 8, 11)
    primitives = (
        Primitive("G", (0, 0, 0), (4, 0, 0)),
        Primitive("G", (0, 0, 7), (4, 0, 7)),
        Primitive("G", (2, -2, 7), (2, 2, 7)),
        Primitive("G", (2, 0, 7), (2, 0, 7)),
        Primitive("M", (0, 0, 0), (4, 0, 0)),
        Primitive("M", (2, -2, 0), (2, 2, 0)),
        Primitive("M", (2, 0, 0), (2, 0, 0)),
        Primitive("R", (2, 0, 0), (2, 0, 0), 0),
        Primitive("R", (2, 0, 0), (2, 0, 0), 7),
        Primitive("R", (4, 0, 0), (4, 0, 0), 11),
    )
    comparisons = 0
    for owners in (frozenset(), frozenset({(2, 0, 7)}), frozenset({(2, 0, 7), (2, 0, 8)})):
        budget = WorkBudget(time.monotonic() + 60)
        for left, right in product(primitives, repeat=2):
            rects = relation(left, right, levels, levels, owners, budget)
            for p, q in product(range(len(levels)), repeat=2):
                overlap = reference(left, levels[p]) & reference(right, levels[q])
                expected = bool(overlap) and not (len(overlap) == 1 and overlap <= owners)
                matches = sum(a <= p <= b and c <= q <= d for a, b, c, d in rects)
                assert matches in (0, 1) and bool(matches) == expected, (left, right, p, q, owners)
                comparisons += 1
    budget = WorkBudget(time.monotonic() + 60)
    problem = TemplateProblem(
        (
            Obligation(
                17,
                "iron",
                Fraction(1),
                Endpoint((0, 0, 7), (1, 0), 1),
                Endpoint((10, 4, 3), (-1, 0), 2),
            ),
        ),
        frozenset(),
        (),
        (-4, 8, 24),
        (-4, 8, 24),
        levels,
    )
    domain = domains(problem, budget)[0]
    index = PrimitiveIndex(domain, budget)
    unions = 0
    for combo in range(len(domain.lengths)):
        for pid, mask in enumerate(index.masks):
            assert bool(mask & (1 << combo)) == (pid in index.combos[combo])
        for p, height in enumerate(levels):
            actual: set[Cell] = set()
            for pid in index.combos[combo]:
                primitive = index.primitives[pid]
                segment = primitive.at(height, budget)
                assert set(cells((segment.lo, segment.hi))) == reference(primitive, height)
                actual.update(reference(primitive, height))
            canonical = set(cells(domain._decode(combo * len(levels) + p, budget).path.points))
            assert actual == canonical, (combo, height)
            unions += 1
    return {
        "primitive_height_comparisons": comparisons,
        "raw_normalized_unions": unions,
        "exact_relations_and_membership": True,
    }


if __name__ == "__main__":
    print(json.dumps(run(), sort_keys=True))
