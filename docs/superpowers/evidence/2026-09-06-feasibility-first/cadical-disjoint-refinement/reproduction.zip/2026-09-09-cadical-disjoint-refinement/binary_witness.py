"""Preserve exact CNF while removing generic binary sorting work."""

from __future__ import annotations

import json
import time
from fractions import Fraction

from .family_cnf import FactorCNF
from .template_budget import WorkBudget
from .template_paths import Endpoint, Obligation, TemplateProblem, domains


def run() -> dict[str, int | bool]:
    budget = WorkBudget(time.monotonic() + 30)
    problem = TemplateProblem(
        (
            Obligation(
                17,
                "iron",
                Fraction(1),
                Endpoint((0, 0, 0), (1, 0), 1),
                Endpoint((10, 4, 0), (-1, 0), 2),
            ),
        ),
        frozenset(),
        (),
        (),
        (),
        (3, 5, 8),
    )
    clauses: list[list[int]] = []
    cnf = FactorCNF(domains(problem, budget), clauses.append, budget)
    before = budget.counts["predicates"]
    count = len(clauses)
    ids = (0, 1, 2, 3, 7, 149)
    for ci in ids:
        cnf.exclude(0, ci)
    expected = [sorted([-cnf.xy[0][ci // 3], -cnf.height[0][ci % 3]]) for ci in ids]
    assert clauses[count:] == expected
    work = budget.counts["predicates"] - before
    assert work <= 4 * len(ids), ("binary construction still performs generic sorting", work)
    return {
        "exact_exclusion_clauses": len(ids),
        "construction_predicates": work,
        "equivalent_binary_exclusions": True,
    }


if __name__ == "__main__":
    print(json.dumps(run(), sort_keys=True))
