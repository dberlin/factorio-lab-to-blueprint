"""Bridge the real strip/interface emitter to bounded complete-path selection."""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from fractions import Fraction
from pathlib import Path
from typing import Literal, override

from flab2bp.dsp import catalog
from flab2bp.layout import routing_domain as rd
from flab2bp.spec import BuildSpec

from .family_cnf import FactorCNF
from .family_geometry import PrimitiveIndex
from .flight_reuse import ReusingConstructor
from .template_budget import ExperimentRefusal, WorkBudget
from .template_cadical import (
    MAXIMUM_CLAUSES,
    MAXIMUM_COLLISION_CUTS,
    CellIndex,
    DomainIndex,
    SolveStats,
    cells,
    entry_rejections,
    exclude_static_middles,
    members,
    select,
)
from .template_flow import Order
from .template_paths import Endpoint, FixedPath, Obligation, TemplateProblem, admit, domains

Cell = tuple[int, int, int]


@dataclass(frozen=True)
class TemplateRun:
    budget: WorkBudget
    order: Order
    output: Path
    admission: bool = False
    mode: Literal["GEOMETRY_ONLY", "RATED_ACCEPTANCE"] = "GEOMETRY_ONLY"

    seen_topologies: set[str] = field(default_factory=set)
    solve_stats: SolveStats = field(default_factory=SolveStats)


class TemplateConstructor(ReusingConstructor):
    def __init__(
        self, spec: BuildSpec, rules: catalog.BeltAltitudeRules, session: TemplateRun
    ) -> None:
        super().__init__(spec, rules)
        self.session = session
        self.x_tracks: tuple[int, ...] = ()
        self.y_tracks: tuple[int, ...] = ()
        self.admission_result: dict[str, object] | None = None
        self.selected_points: dict[int, tuple[Cell, ...]] = {}
        self.selection_complete = False
        self.problem: TemplateProblem | None = None

    def set_tracks(self, x_tracks: tuple[int, ...], y_tracks: tuple[int, ...]) -> None:
        self.x_tracks = x_tracks
        self.y_tracks = y_tracks

    def endpoint(self, port: rd._Port, outward: tuple[int, int]) -> Endpoint:
        building = self.canvas.buildings[port.belt]
        if not catalog.is_belt(building.item_id) or (building.x, building.y, building.z) != (
            port.x,
            port.y,
            port.z,
        ):
            raise ExperimentRefusal("PHYSICAL_ACCESS_CONFLICT", "attachment is not its actual belt")
        node = next(
            (
                index
                for index in (building.input_obj, building.output_obj)
                if index in self.junctions
            ),
            None,
        )
        return Endpoint((port.x, port.y, port.z), outward, port.belt, node)

    def _owns_blocked_endpoint(self, endpoint: Endpoint) -> bool:
        owner = self.canvas.blocked.get(endpoint.cell)
        if owner == endpoint.port_id:
            return True
        node = endpoint.junction_id
        if owner is None or node is None:
            return False
        junction = self.canvas.buildings[node]
        other = self.canvas.buildings[owner]
        # The occupancy map stores only the last of a splitter's co-located
        # attachment belts. Verify actual incidence, not coordinate coincidence.
        return (
            (junction.x, junction.y, junction.z) == endpoint.cell
            and (other.x, other.y, other.z) == endpoint.cell
            and catalog.is_belt(other.item_id)
            and node in (other.input_obj, other.output_obj)
        )

    @override
    def connect(
        self,
        source: rd._Port,
        sink: rd._Port,
        points: list[Cell],
        item: str,
        rate: Fraction,
        role: str,
    ) -> None:
        self.session.budget.check()
        self.session.budget.charge(
            "audit_cells",
            sum(
                sum(abs(a - b) for a, b in zip(first, second, strict=True))
                for first, second in zip(points, points[1:], strict=False)
            )
            + 1,
        )
        super().connect(source, sink, points, item, rate, role)

    def _fixed_path(self, index: int) -> FixedPath:
        link = self.links[index]
        points = link.cells

        def terminal(belt: int, cell: Cell, neighbour: Cell) -> Endpoint:
            dx, dy = neighbour[0] - cell[0], neighbour[1] - cell[1]
            outward = ((dx > 0) - (dx < 0), (dy > 0) - (dy < 0))
            return self.endpoint(rd._Port(belt, *cell[:2], z=cell[2]), outward)

        return FixedPath(
            points,
            terminal(link.source, points[0], points[1]),
            terminal(link.sink, points[-1], points[-2]),
            link.item,
        )

    @override
    def finish(self) -> None:
        budget = self.session.budget
        budget.check()
        # These are fixed interface transfers, not speculative global paths.
        for flight in self.pending:
            if flight.role in ("local-source", "local-sink"):
                if flight.exclusive_level >= self.canvas.levels:
                    raise ExperimentRefusal(
                        "PHYSICAL_ACCESS_CONFLICT", "local transfer exceeds original altitude"
                    )
                self.connect(
                    flight.source.port,
                    flight.sink.port,
                    flight.points(flight.exclusive_level),
                    flight.item,
                    flight.rate,
                    flight.role,
                )
        global_flights = [
            (index, flight)
            for index, flight in enumerate(self.pending)
            if flight.role not in ("local-source", "local-sink")
        ]
        fixed_belts: set[int] = set()
        for link in self.links:
            current = link.source
            visited: set[int] = set()
            while current not in visited:
                visited.add(current)
                fixed_belts.add(current)
                if current == link.sink:
                    break
                onward = self.canvas.buildings[current].output_obj
                if onward is None:
                    raise ExperimentRefusal(
                        "PHYSICAL_ACCESS_CONFLICT", "fixed link is disconnected"
                    )
                current = onward
            else:
                raise ExperimentRefusal("PHYSICAL_ACCESS_CONFLICT", "fixed link has a cycle")
        blocked = {cell for cell, owner in self.canvas.blocked.items() if owner not in fixed_belts}
        blocked.update(self.canvas.guard)
        for (x, y), levels in self.canvas.belt_ban.items():
            blocked.update((x, y, z) for z in levels)
        for x, y in self.canvas.keep_out:
            blocked.update((x, y, z) for z in range(self.canvas.levels))
        blocked.update(
            cell
            for cell, port in self.canvas.reserved.items()
            if port not in self.canvas.routing_ports
        )
        fixed_paths = tuple(self._fixed_path(i) for i in range(len(self.links)))
        extent = set(self.canvas.blocked) | blocked
        extent.update(cell for path in fixed_paths for cell in path.points)
        xs = [cell[0] for cell in extent]
        ys = [cell[1] for cell in extent]
        x_tracks = tuple(sorted(set(self.x_tracks) | {min(xs) - 8, max(xs) + 8}))
        y_tracks = tuple(sorted(set(self.y_tracks) | {min(ys) - 8, max(ys) + 8}))
        self.problem = TemplateProblem(
            tuple(
                Obligation(
                    index,
                    flight.item,
                    flight.rate,
                    self.endpoint(flight.source.port, flight.source.outward),
                    self.endpoint(flight.sink.port, flight.sink.outward),
                )
                for index, flight in global_flights
            ),
            frozenset(blocked),
            fixed_paths,
            x_tracks,
            y_tracks,
            tuple(range(3, self.canvas.levels)),
        )
        endpoints = tuple(
            endpoint
            for path in (*self.problem.obligations, *fixed_paths)
            for endpoint in (path.source, path.sink)
            if self._owns_blocked_endpoint(endpoint)
            and endpoint.cell not in self.canvas.guard
            and endpoint.cell[2] not in self.canvas.belt_ban.get(endpoint.cell[:2], ())
            and endpoint.cell[:2] not in self.canvas.keep_out
            and self.canvas.reserved.get(endpoint.cell, endpoint.cell) == endpoint.cell
        )
        self.problem = TemplateProblem(
            self.problem.obligations,
            self.problem.blocked,
            fixed_paths,
            x_tracks,
            y_tracks,
            self.problem.levels,
            endpoints,
        )
        if self.session.admission:
            self.admission_result = asdict(admit(self.problem, budget, sample_limit=1024))
            ds = domains(self.problem, budget)
            indexes = [CellIndex(domain, budget) for domain in ds]
            domain_index = DomainIndex(indexes, budget)
            fixed_cells = [set(cells(path.points)) for path in self.problem.fixed_paths]
            budget.charge("audit_cells", sum(map(len, fixed_cells)))
            rejected = entry_rejections(self.problem, indexes, fixed_cells, budget)
            exclude_static_middles(
                self.problem, indexes, domain_index, fixed_cells, rejected, budget
            )
            for domain in ds:
                budget.charge("candidates", domain.count)
            primitives = [PrimitiveIndex(domain, budget) for domain in ds]
            clauses = 0

            def count_clause(_clause: list[int]) -> None:
                nonlocal clauses
                budget.check()
                if clauses >= MAXIMUM_CLAUSES:
                    raise ExperimentRefusal("POLICY_BOUND", "CaDiCaL admission clause cap")
                clauses += 1

            factors = FactorCNF(ds, count_clause, budget, MAXIMUM_COLLISION_CUTS)
            for di, mask in enumerate(rejected):
                for ci in members(mask):
                    factors.exclude(di, ci)
            self.admission_result.update(
                logical_candidates=sum(d.count for d in ds),
                primary_variables=factors.primary_variables,
                prepared_variables=factors.top_id,
                prepared_clauses=clauses,
                primitive_occurrences=sum(index.occurrences for index in primitives),
                primitive_descriptors=sum(len(index.primitives) for index in primitives),
            )
            return

        def checkpoint(phase: str) -> None:
            self.session.output.mkdir(parents=True, exist_ok=True)
            temporary = self.session.output / "solver-progress.tmp"
            temporary.write_text(
                json.dumps(
                    {
                        "phase": phase,
                        "work": budget.counts,
                        "stats": asdict(self.session.solve_stats),
                    }
                )
            )
            temporary.replace(self.session.output / "solver-progress.json")

        self.selected_points = select(self.problem, budget, self.session.solve_stats, checkpoint)
        self.selection_complete = True
        for index, flight in global_flights:
            budget.check()
            points = self.selected_points[index]
            self.connect(
                flight.source.port,
                flight.sink.port,
                list(points),
                flight.item,
                flight.rate,
                flight.role,
            )
        budget.check()
