"""One bounded solver-free actual-domain sample; not an original acceptance run."""

from __future__ import annotations

import json
import random
import time
from dataclasses import dataclass
from itertools import combinations, islice
from pathlib import Path

from pydantic import TypeAdapter

from .family_cnf import FactorCNF
from .family_geometry import Family, PrimitiveIndex
from .template_budget import WorkBudget
from .template_paths import TemplateProblem, _compatible, _path_error, domains


@dataclass
class ClauseCount:
    clauses: int = 0

    def add(self, _clause: list[int]) -> None:
        self.clauses += 1
        assert self.clauses <= 20_000_000


def run() -> dict[str, object]:
    started = time.monotonic()
    budget = WorkBudget(started + 60)
    root = Path(__file__).parent
    source = root.parent / "2026-09-09-cadical-interface-static/problem.json"
    problem = TypeAdapter(TemplateProblem).validate_json(source.read_text())
    ds = domains(problem, budget)
    for domain in ds:
        budget.charge("candidates", domain.count)
    rng = random.Random(19)
    chosen: list[int] = []
    geometries = []
    for domain in ds:
        for ci in rng.sample(range(domain.count), min(domain.count, 12)):
            geometry = domain._decode(ci, budget)
            if _path_error(geometry, budget) is None:
                chosen.append(ci)
                geometries.append(geometry)
                break
        else:
            raise AssertionError("predeclared sample has no self-valid candidate")
    indexes = [PrimitiveIndex(domain, budget) for domain in ds]
    point_count, family_count = ClauseCount(), ClauseCount()
    points = FactorCNF(ds, point_count.add, budget)
    families = FactorCNF(ds, family_count.add, budget)
    base_clauses = family_count.clauses
    assert len(ds) == 141 and sum(d.count for d in ds) == 846_000
    assert families.primary_variables == 38_634 and families.top_id <= 53_157
    assert base_clauses <= 102_789
    checked = conflicts = 0
    represented_sum = 0
    for i, j in islice(combinations(range(len(ds)), 2), 1000):
        budget.check()
        ca, p = divmod(chosen[i], len(ds[i].levels))
        cb, q = divmod(chosen[j], len(ds[j].levels))
        expected = not _compatible(geometries[i], geometries[j], budget)
        assert indexes[i].incompatible(indexes[j], ca, cb, p, q, budget) == expected
        checked += 1
        if not expected:
            continue
        family = indexes[i].family(indexes[j], ca, cb, p, q, budget)
        families.forbid(i, j, family)
        points.forbid(i, j, Family(1 << ca, 1 << cb, ((p, p, q, q),)))
        conflicts += 1
        represented_sum += (
            family.left_mask.bit_count()
            * family.right_mask.bit_count()
            * sum((b - a + 1) * (d - c + 1) for a, b, c, d in family.rectangles)
        )
        # Additional original combinations/heights certified beyond the trigger.
        for last in (False, True):
            a = (
                family.left_mask.bit_length() - 1
                if last
                else (family.left_mask & -family.left_mask).bit_length() - 1
            )
            b = (
                family.right_mask.bit_length() - 1
                if last
                else (family.right_mask & -family.right_mask).bit_length() - 1
            )
            lo, hi, start, end = family.rectangles[-1 if last else 0]
            pa, pb = (hi, end) if last else (lo, start)
            assert not _compatible(
                ds[i]._decode(a * len(ds[i].levels) + pa, budget),
                ds[j]._decode(b * len(ds[j].levels) + pb, budget),
                budget,
            )
    assert checked == 1000 and conflicts > 0
    return {
        "scope": "solver-free diagnostic; not original gate acceptance",
        "sample_rule": (
            "Random(19), first self-valid among12 sampled IDs/domain, first1000 unordered pairs"
        ),
        "source": str(source),
        "candidate_ids": chosen,
        "pairs": checked,
        "conflicts": conflicts,
        "logical_candidates": sum(d.count for d in ds),
        "primary_variables": families.primary_variables,
        "base_clauses": base_clauses,
        "point_clauses": point_count.clauses,
        "family_clauses": family_count.clauses,
        "family_rectangles": families.rectangles,
        "point_rectangles": points.rectangles,
        "family_guard_variables": families.guard_count,
        "represented_pair_sum_not_unique": represented_sum,
        "primitive_occurrences": sum(index.occurrences for index in indexes),
        "primitive_descriptors": sum(len(index.primitives) for index in indexes),
        "work": budget.counts,
        "elapsed_s": time.monotonic() - started,
    }


if __name__ == "__main__":
    result = run()
    (Path(__file__).parent / "family-discriminator.json").write_text(json.dumps(result, indent=2))
    print(json.dumps({k: v for k, v in result.items() if k != "candidate_ids"}, sort_keys=True))
