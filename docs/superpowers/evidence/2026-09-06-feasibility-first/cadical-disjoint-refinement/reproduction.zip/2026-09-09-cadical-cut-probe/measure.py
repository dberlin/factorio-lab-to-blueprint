"""Diagnostic family-event census; never an acceptance run."""
import ast
import importlib
import inspect
import json
import sys
import time
from collections import Counter
from dataclasses import asdict
from pathlib import Path
from pydantic import TypeAdapter

name = sys.argv[1]
module = importlib.import_module(name + ".template_cadical")
paths = importlib.import_module(name + ".template_paths")
root = Path(__file__).parent
problem = TypeAdapter(paths.TemplateProblem).validate_json(
    (root.parent / "2026-09-09-cadical-interface-static/problem.json").read_text()
)
budget = module.WorkBudget(time.monotonic() + 60)
stats = module.SolveStats()
events = []

def record(i, j, family):
    events.append({"round": stats.rounds, "left": i, "right": j,
                   "left_members": family.left_mask.bit_count(),
                   "right_members": family.right_mask.bit_count(),
                   "rectangles": family.rectangles})

source = inspect.getsource(module.select)
lines = []
insertions = 0
for line in source.splitlines():
    lines.append(line)
    if line.strip().startswith("family = primitive_indexes[i].family("):
        indent = line[:len(line) - len(line.lstrip())]
        lines.append(indent + "_record_family(i, j, family)")
        insertions += 1
assert insertions == 1
module.__dict__["_record_family"] = record
exec(compile(ast.parse("\n".join(lines)), "<family-event-census>", "exec"), module.__dict__)
outcome, reason = "GEOMETRY_COMPLETE", None
try:
    module.select(problem, budget, stats)
except module.ExperimentRefusal as failure:
    outcome, reason = failure.reason, failure.detail
used = set()
matching = []
for event in events:
    if event["left"] not in used and event["right"] not in used:
        matching.append(event)
        used.update((event["left"], event["right"]))
report = {"scope": "diagnostic event census, not acceptance", "revision": name,
          "outcome": outcome, "reason": reason, "stats": asdict(stats),
          "work": budget.counts, "events": events,
          "rectangle_counts": dict(Counter(len(e["rectangles"]) for e in events)),
          "diagonal_relations": sum(all(a == b == c == d for a,b,c,d in e["rectangles"]) for e in events),
          "prefix_disjoint_families": len(matching),
          "prefix_disjoint_rectangles": sum(len(e["rectangles"]) for e in matching)}
(root / (name + ".json")).write_text(json.dumps(report, indent=2))
print(json.dumps({k:v for k,v in report.items() if k not in ("events", "stats")}, sort_keys=True))
