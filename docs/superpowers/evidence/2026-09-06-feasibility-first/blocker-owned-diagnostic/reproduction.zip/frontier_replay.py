"""Throwaway conditional-domain proof; does not run or modify the factory search."""

from __future__ import annotations

import argparse
import hashlib
import importlib
import json
import sys
import tempfile
import time
import zipfile
from collections import Counter
from fractions import Fraction
from pathlib import Path


def expand(points):
    cells = set()
    for a, b in zip(points, points[1:], strict=False):
        axes = [i for i in range(3) if a[i] != b[i]]
        assert len(axes) == 1
        axis = axes[0]
        step = 1 if b[axis] > a[axis] else -1
        for value in range(a[axis], b[axis] + step, step):
            point = list(a)
            point[axis] = value
            cells.add(tuple(point))
    return cells


def owned(a, b, cell):
    if a.item != b.item:
        return False
    for ea, direction_a in ((a.source, 1), (a.sink, -1)):
        for eb, direction_b in ((b.source, 1), (b.sink, -1)):
            if ea.cell != cell or eb.cell != cell:
                continue
            if ea.port_id == eb.port_id:
                if direction_a != direction_b and ea.outward == tuple(-x for x in eb.outward):
                    return True
            elif (
                ea.junction_id is not None
                and ea.junction_id == eb.junction_id
                and ea.outward != eb.outward
            ):
                return True
    return False


def independent(a, acells, b, bcells):
    for ea in (a.source, a.sink):
        for eb in (b.source, b.sink):
            if ea.port_id == eb.port_id and (ea.cell != eb.cell or not owned(a, b, ea.cell)):
                return False
    return all(owned(a, b, cell) for cell in acells & bcells)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("archive", type=Path)
    parser.add_argument("profile", type=Path)
    args = parser.parse_args()
    data = json.loads((args.profile / "problem.json").read_text())
    profile = json.loads((args.profile / "profile.json").read_text())
    with tempfile.TemporaryDirectory(prefix="blocker-frontier-") as temporary:
        with zipfile.ZipFile(args.archive) as archive:
            archive.extractall(temporary)
        sys.path.insert(0, temporary)
        name = "2026-09-09-blocker-owned-templates"
        paths = importlib.import_module(name + ".template_paths")
        work = importlib.import_module(name + ".template_budget")

        def endpoint(e):
            return paths.Endpoint(
                tuple(e["cell"]), tuple(e["outward"]), e["port_id"], e["junction_id"]
            )

        def fixed(p):
            return paths.FixedPath(
                tuple(tuple(c) for c in p["points"]),
                endpoint(p["source"]),
                endpoint(p["sink"]),
                p["item"],
            )

        problem = paths.TemplateProblem(
            tuple(
                paths.Obligation(
                    o["ordinal"],
                    o["item"],
                    Fraction(o["rate"]),
                    endpoint(o["source"]),
                    endpoint(o["sink"]),
                )
                for o in data["obligations"]
            ),
            frozenset(tuple(c) for c in data["blocked"]),
            tuple(fixed(p) for p in data["fixed_paths"]),
            tuple(data["x_tracks"]),
            tuple(data["y_tracks"]),
            tuple(data["levels"]),
            tuple(endpoint(e) for e in data["owned_endpoints"]),
        )
        started = time.monotonic()
        budget = work.WorkBudget(started + 30)
        domains = {d.obligation.ordinal: d for d in paths.domains(problem, budget)}
        index = paths._FixedIndex(problem, budget)
        prefix = list(profile["terminal"]["selected"].items())[:7]
        selected = {int(i): domains[int(i)]._decode(ci, budget) for i, ci in prefix}
        selected_cells = {i: expand(g.path.points) for i, g in selected.items()}
        survivors = {}
        facts = {}
        first_static = {}
        comparisons = 0
        for target in (13, 18):
            candidates = {}
            failures = Counter()
            static_bad = 0
            for ci in domains[target]._ids(budget):
                budget.check()
                g = domains[target]._decode(ci, budget)
                if paths._path_error(g, budget) or index.error(g, budget):
                    static_bad += 1
                    continue
                cells = expand(g.path.points)
                first_static.setdefault(target, (ci, g, cells))
                for ordinal, other in selected.items():
                    actual = paths._compatible(g, other, budget)
                    oracle = independent(g.path, cells, other.path, selected_cells[ordinal])
                    assert actual == oracle, (target, ci, ordinal)
                    comparisons += 1
                    if not actual:
                        failures[ordinal] += 1
                        break
                else:
                    candidates[ci] = (g, cells)
            survivors[target] = candidates
            facts[target] = {
                "item": domains[target].obligation.item,
                "domain_count": domains[target].count,
                "static_bad": static_bad,
                "first_blocker_counts": dict(failures),
                "surviving_ids": list(candidates),
                "surviving_count": len(candidates),
            }
            assert static_bad + sum(failures.values()) + len(candidates) == domains[target].count
        edges = []
        conflict_cells = Counter()
        for a, (ga, ca) in survivors[13].items():
            for b, (gb, cb) in survivors[18].items():
                budget.check()
                actual = paths._compatible(ga, gb, budget)
                oracle = independent(ga.path, ca, gb.path, cb)
                assert actual == oracle, (a, b)
                comparisons += 1
                if actual:
                    edges.append((a, b))
                else:
                    conflict_cells.update(ca & cb)
        common = {
            target: set.intersection(*(cells for _, cells in candidates.values()))
            if candidates
            else set()
            for target, candidates in survivors.items()
        }
        unavoidable = sorted(common[13] & common[18])
        unconditioned_pair = None
        a, ga, ca = first_static[13]
        for b in domains[18]._ids(budget):
            gb = domains[18]._decode(b, budget)
            if paths._path_error(gb, budget) or index.error(gb, budget):
                continue
            cb = expand(gb.path.points)
            actual = paths._compatible(ga, gb, budget)
            oracle = independent(ga.path, ca, gb.path, cb)
            assert actual == oracle, ("unconditioned", a, b)
            comparisons += 1
            if actual:
                unconditioned_pair = {
                    "ids": {13: a, 18: b},
                    "paths": {13: ga.path.points, 18: gb.path.points},
                    "scope": "static-valid pair without the seven selected blockers",
                }
                break
        result = {
            "scope": "exhaustive finite-domain conditional proof; not global factory infeasibility",
            "fixed_prefix": dict(prefix),
            "targets": facts,
            "joint_pairs_checked": len(survivors[13]) * len(survivors[18]),
            "compatible_pairs": edges,
            "independent_comparisons": comparisons,
            "oracle_disagreements": 0,
            "unavoidable_shared_cells": unavoidable,
            "unconditioned_pair": unconditioned_pair,
            "most_common_collision_cells": [
                (cell, count) for cell, count in conflict_cells.most_common(10)
            ],
            "surviving_paths": {
                str(target): {
                    str(ci): geometry.path.points for ci, (geometry, _) in candidates.items()
                }
                for target, candidates in survivors.items()
            },
            "work": budget.counts,
            "elapsed_s": time.monotonic() - started,
            "profile_sha256": hashlib.sha256(
                (args.profile / "profile.json").read_bytes()
            ).hexdigest(),
        }
        (args.profile / "frontier-replay.json").write_text(
            json.dumps(result, indent=2, default=str)
        )
        print(json.dumps({k: v for k, v in result.items() if k != "surviving_paths"}, default=str))


if __name__ == "__main__":
    main()
