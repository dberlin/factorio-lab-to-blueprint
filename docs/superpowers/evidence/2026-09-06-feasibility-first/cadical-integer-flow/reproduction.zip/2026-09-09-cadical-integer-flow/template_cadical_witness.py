"""Finite exact-domain oracle for height-factored occupancy, not a benchmark."""

from __future__ import annotations

import json
import time
from fractions import Fraction

from .template_budget import ExperimentRefusal, WorkBudget
from .template_cadical import CellIndex, select
from .template_paths import Endpoint, Obligation, TemplateProblem, domains
from .template_paths_witness import _expand


def run() -> dict[str, int | bool]:
    candidates = queries = 0
    # Includes nonconsecutive legal heights and risers both below and above ports.
    for source_z, sink_z, outward, backward in (
        (0, 0, (1, 0), (-1, 0)),
        (7, 3, (0, 1), (0, -1)),
        (3, 7, (-1, 0), (1, 0)),
        (7, 7, (0, -1), (0, 1)),
    ):
        budget = WorkBudget(time.monotonic() + 60)
        obligation = Obligation(
            0,
            "iron",
            Fraction(1),
            Endpoint((0, 0, source_z), outward, 1),
            Endpoint((20, 12, sink_z), backward, 2),
        )
        problem = TemplateProblem(
            (obligation,), frozenset(), (), (-4, 4, 16, 24), (-4, 4, 8, 16), (3, 5, 8)
        )
        domain = domains(problem, budget)[0]
        index = CellIndex(domain, budget)
        expected: dict[tuple[int, int, int], int] = {}
        for ci in range(domain.count):
            geometry = domain._decode(ci, budget)
            for cell in set(_expand(geometry.path.points)):
                expected[cell] = expected.get(cell, 0) | (1 << ci)
            candidates += 1
        # Compare full bitsets, so both missing members and false positives fail.
        for x in range(-7, 28):
            for y in range(-7, 20):
                for z in range(10):
                    cell = (x, y, z)
                    assert index.occupants(cell, budget) == expected.get(cell, 0), cell
                    queries += 1
        assert all(-7 <= x < 28 and -7 <= y < 20 and 0 <= z < 10 for x, y, z in expected)
    east = Obligation(
        0,
        "iron",
        Fraction(1),
        Endpoint((0, 0, 0), (1, 0), 1, 99),
        Endpoint((20, 0, 0), (-1, 0), 2),
    )
    north = Obligation(
        1,
        "iron",
        Fraction(1),
        Endpoint((0, 0, 0), (0, 1), 3, 99),
        Endpoint((0, 20, 0), (0, -1), 4),
    )
    shared = TemplateProblem((east, north), frozenset(), (), (), (), (3, 4))
    chosen = select(shared, WorkBudget(time.monotonic() + 60))
    assert set(chosen) == {0, 1}
    assert set(_expand(chosen[0])) & set(_expand(chosen[1])) == {(0, 0, 0)}
    foreign = Obligation(
        2,
        "iron",
        Fraction(1),
        Endpoint((0, 0, 0), (-1, 0), 5),
        Endpoint((-20, 0, 0), (1, 0), 6),
    )
    refused = TemplateProblem((east, north, foreign), frozenset(), (), (), (), (3, 4))
    try:
        select(refused, WorkBudget(time.monotonic() + 60))
    except ExperimentRefusal as failure:
        assert failure.reason == "TEMPLATE_FAMILY_EXHAUSTED"
    else:
        raise AssertionError("foreign occupant at a shared junction was accepted")
    return {
        "candidate_geometries": candidates,
        "exact_membership_queries": queries,
        "all_adapter_and_shape_families": True,
        "descending_and_ascending_risers": True,
        "owned_shared_occupancy_preserved": True,
        "foreign_third_occupant_refused": True,
    }


if __name__ == "__main__":
    print(json.dumps(run(), sort_keys=True))
