"""Replay saved geometry with coarse pipeline boundaries, not function profiling."""

from __future__ import annotations

import argparse
import importlib
import json
import time
from contextlib import ExitStack
from pathlib import Path
from unittest.mock import patch

from pydantic import BaseModel, TypeAdapter


class Command(BaseModel):
    output: Path


def main() -> None:
    parser = argparse.ArgumentParser()
    _ = parser.add_argument("output", type=Path)
    args = Command.model_validate(vars(parser.parse_args()))
    args.output.mkdir(parents=True, exist_ok=False)
    root = Path.cwd()
    name = "2026-09-09-cadical-occupancy"
    paths = importlib.import_module(name + ".template_paths")
    runtime = importlib.import_module(name + ".template_runtime")
    control = importlib.import_module(name + ".constructive_control")
    work = importlib.import_module(name + ".template_budget")
    experiment = importlib.import_module(name + ".template_experiment")
    from flab2bp.layout import routing_domain

    problem = TypeAdapter(paths.TemplateProblem).validate_python(json.loads((root / ".superpowers/sdd/2026-09-09-joint-domain-templates/joint-frontier-input.json").read_text())["problem"])
    raw = json.loads((root / "docs/superpowers/evidence/2026-09-06-feasibility-first/cadical-occupancy/selected-points.json").read_text())
    selected = {int(k): tuple(tuple(p) for p in points) for k, points in raw.items()}
    events = []
    started = time.monotonic()

    def record(stage, event):
        row = {"stage": stage, "event": event, "elapsed_seconds": time.monotonic() - started}
        events.append(row)
        with (args.output / "stages.jsonl").open("a") as stream:
            stream.write(json.dumps(row) + "\n")

    def select(actual, budget, stats, checkpoint):
        assert actual == problem
        budget.check()
        record("saved-selection", "return")
        return selected

    def stage(function, label):
        def invoke(*args, **kwargs):
            record(label, "begin")
            try:
                return function(*args, **kwargs)
            finally:
                record(label, "end")
        return invoke

    budget = work.WorkBudget(started + 30)
    session = runtime.TemplateRun(budget, "captured", args.output / "factory")
    record("control", "begin")
    with ExitStack() as stack:
        stack.enter_context(patch.object(runtime, "select", select))
        stack.enter_context(patch.object(routing_domain, "_route_all", side_effect=AssertionError("global router forbidden")))
        for owner, symbol, label in (
            (control, "_settle", "settlement-total"),
            (control, "audit_placement", "placement-audit"),
            (control, "rate_assessment", "physical-rate-assessment"),
            (control.finalize, "finalize_placement", "projection"),
            (control.validate, "judge_placement", "registered-validation"),
            (control, "audit_blueprint", "decoded-blueprint-audit"),
        ):
            stack.enter_context(patch.object(owner, symbol, stage(getattr(owner, symbol), label)))
        with experiment.absolute_deadline(budget):
            result = control.run("three-output", reuse=True, capacity_first=True, template=session)
    record("control", "end")
    report = {"diagnostic_only": True, "solver_invoked": False, "function_profile_created": False, "outcome": result["outcome"], "original_gate_promoted": False, "events": events}
    (args.output / "report.json").write_text(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
