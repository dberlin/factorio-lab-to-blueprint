"""Emitted channel crossings and physical fan-out: not factory acceptance."""

from __future__ import annotations

import json
import time
from collections.abc import Sequence
from dataclasses import asdict, replace
from fractions import Fraction
from pathlib import Path

from flab2bp.dsp import catalog
from flab2bp.layout import routing_domain as rd
from flab2bp.layout import validate
from flab2bp.layout.base import Placement
from flab2bp.layout.route_feedback import Cell
from flab2bp.layout.slots import assign_sorter_slots

CHECKS = (
    "geom.footprint",
    "geom.overlap",
    "geom.collide",
    "geom.belt_single_occupancy",
    "geom.altitude_range",
    "geom.altitude_step",
    "geom.bounds",
    "game.belt_crossing",
    "game.belt_collide",
    "belt.continuity",
    "belt.link_adjacent",
    "belt.acyclic",
    "junction.stack_support",
    "junction.ports",
    "junction.colocated",
    "junction.port_pose",
    "junction.records_no_links",
    "game.addon_supply",
    "game.addon_facing",
    "game.addon_corner",
)
ROOT = Path(__file__).resolve().parent


def emit(canvas: rd._Canvas, cells: Sequence[Cell], item: str) -> tuple[int, ...]:
    profile = rd._altitude_profile(cells, ramped=canvas.ramped)
    assert profile is not None
    indices = tuple(
        canvas.add(
            rd.PlacedBuilding(
                item_id=2003,
                model_index=catalog.building(2003).model_index,
                x=x,
                y=y,
                z=z,
                width=1,
                height=1,
                carries_item=item,
            ),
            level=level,
        )
        for (x, y, level), z in zip(cells, profile, strict=True)
    )
    for first, second in zip(indices, indices[1:], strict=False):
        canvas.buildings[first] = rd._relink(canvas.buildings[first], output_obj=second)
    return indices


def report(canvas: rd._Canvas, name: str, *, vertical: bool = True) -> dict[str, object]:
    findings = validate.validate(
        Placement(buildings=assign_sorter_slots(canvas.buildings)),
        only=CHECKS,
        expect_power=False,
        belt_vertical_construction=vertical,
        max_belt_z=Fraction(531, 20),
    )
    return {
        "kind": name,
        "original_factory_gate": False,
        "checks": findings.checks_run,
        "skipped": findings.skipped,
        "errors": len(findings.errors),
        "findings": [asdict(f) for f in findings.findings],
        "buildings": len(canvas.buildings),
    }


def run() -> None:
    rules = replace(rd._DEFAULT_BELT_RULES, max_z=Fraction(531, 20), vertical_construction=True)
    canvas = rd._Canvas(belt_rules=rules)
    # Two orthogonal plane pairs, plus zero-run access to the top local plane.
    # The second access leg crosses the first trunk's XY projection at z=5/2.
    a = (
        (-8, 0, 0),
        (-8, 0, 26),
        (-7, 0, 26),
        (-6, 0, 26),
        (-6, 0, 3),
        *((-6, y, 3) for y in range(1, 11)),
        (-6, 10, 2),
        *((x, 10, 2) for x in range(-5, 9)),
        (8, 10, 3),
        *((8, y, 3) for y in range(9, -1, -1)),
        (8, 0, 26),
        (9, 0, 26),
        (9, 0, 0),
    )
    b = (
        (0, -2, 0),
        (0, -2, 26),
        (1, -2, 26),
        (2, -2, 26),
        (2, -2, 5),
        *((2, y, 5) for y in range(-1, 14)),
        (2, 13, 4),
        *((x, 13, 4) for x in range(3, 13)),
        (12, 13, 5),
        *((12, y, 5) for y in range(12, -3, -1)),
        (12, -2, 26),
        (13, -2, 26),
        (13, -2, 0),
    )
    assert not (set(a) & set(b))
    emit(canvas, a, "iron-ingot")
    emit(canvas, b, "copper-ingot")
    results = [
        report(canvas, "orthogonal-channel-pairs-unlocked"),
        report(canvas, "orthogonal-channel-pairs-locked", vertical=False),
    ]
    junction_canvas = rd._Canvas(belt_rules=rules)
    junction_canvas.limit = (-8, -10, 20, 10)
    source = emit(junction_canvas, ((-2, 0, 0), (-1, 0, 0), (0, 0, 0)), "iron-ingot")[-1]
    sinks = [
        emit(junction_canvas, tuple((x, y, 0) for x in range(12, 15)), "iron-ingot")[0]
        for y in (-5, 5)
    ]
    source_port = rd._Port(source, 0, 0)
    nets = [
        rd._Net(
            source_port,
            rd._Port(sink, 12, y),
            "iron-ingot",
            net_id=rd.NetId(None, None, "iron-ingot", rd.NetRole.INTERNAL, i),
        )
        for i, (sink, y) in enumerate(zip(sinks, (-5, 5), strict=True))
    ]
    routed = rd._route_all(
        junction_canvas,
        nets,
        2003,
        catalog.building(2003).model_index,
        junction_canvas.limit,
        deadline=time.monotonic() + 5,
        budget={"left": 100000},
    )
    fanout = report(junction_canvas, "shared-source-physical-fanout")
    fanout.update({"routed": len(routed.routed), "route_failures": routed.failed_count})
    results.append(fanout)
    (ROOT / "channel-mechanics.json").write_text(json.dumps(results, indent=2, default=str))
    for result in results:
        print(json.dumps(result, default=str), flush=True)
    assert results[0]["errors"] == 0
    assert results[1]["errors"] != 0
    assert fanout["errors"] == 0 and routed.failed_count == 0 and len(routed.routed) == 2


if __name__ == "__main__":
    run()
