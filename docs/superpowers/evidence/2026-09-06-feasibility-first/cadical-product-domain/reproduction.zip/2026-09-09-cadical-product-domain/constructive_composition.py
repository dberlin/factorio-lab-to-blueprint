"""Derived two-unit factory with explicit split/merge hardware and fixed paths.

No global router, no post-result boundary derivation, no production strategy.
"""

from __future__ import annotations

import hashlib
import json
import time
from collections import defaultdict
from dataclasses import asdict, dataclass
from fractions import Fraction
from pathlib import Path

from pydantic import TypeAdapter

from flab2bp import pipeline
from flab2bp.dsp import catalog, codec
from flab2bp.lab.data import load_vendored
from flab2bp.lab.flow import canonicalize_dataset
from flab2bp.lab.techs import belt_rules_for_url
from flab2bp.layout import finalize, freeform, junction, markers, validate
from flab2bp.layout import routing_domain as rd
from flab2bp.layout.band_policy import BandPolicy
from flab2bp.layout.base import Placement
from flab2bp.layout.hierarchy.contracts import LaneEnd, LaneFlow, assign_lanes
from flab2bp.layout.hierarchy.partition import Cut, Unit, sub_spec
from flab2bp.layout.route_feedback import Cell
from flab2bp.layout.slots import assign_sorter_slots
from flab2bp.spec import BuildSpec

from .run_experiment import Case

ROOT = Path(__file__).resolve().parent
POLICY = BandPolicy("portable")


@dataclass(frozen=True)
class Terminal:
    port: rd._Port
    outward: tuple[int, int]


@dataclass(frozen=True)
class ConstructedLink:
    item: str
    source: int
    sink: int
    rate: Fraction
    cells: tuple[Cell, ...]
    role: str


class ConstructionRefusal(ValueError):
    pass


def path_through(points: list[Cell]) -> tuple[Cell, ...]:
    cells = [points[0]]
    for end in points[1:]:
        x, y, z = cells[-1]
        ex, ey, ez = end
        if sum((x != ex, y != ey, z != ez)) > 1:
            raise ConstructionRefusal(f"non-orthogonal planned segment: {cells[-1]} -> {end}")
        if z != ez:
            cells.append(end)
        elif x != ex:
            step = 1 if ex > x else -1
            cells.extend((xx, y, z) for xx in range(x + step, ex + step, step))
        elif y != ey:
            step = 1 if ey > y else -1
            cells.extend((x, yy, z) for yy in range(y + step, ey + step, step))
    return tuple(cells)


class Constructor:
    def __init__(self, spec: BuildSpec, rules: catalog.BeltAltitudeRules) -> None:
        self.spec = spec
        self.canvas = rd._Canvas(
            belt_rules=rules,
            sorter_tiers=rd._sorter_tiers_for(spec),
            sorter_stacks=rd._sorter_stacks_for(spec),
            lane_stacks=rd._lane_stacks_for(spec),
            power_building=catalog.power_tower_building(spec.power_tower_item_id),
        )
        self.belt_id = catalog.get_item_id(spec.belt_item_id) or 2001
        self.belt_model = catalog.building(self.belt_id).model_index
        self.links: list[ConstructedLink] = []
        self.junctions: list[int] = []

    def belt(self, cell: Cell, item: str) -> rd._Port:
        if not self.canvas.free(cell):
            raise ConstructionRefusal(f"fixed belt cell is occupied: {item} at {cell}")
        x, y, z = cell
        index = self.canvas.add(
            rd.PlacedBuilding(
                item_id=self.belt_id,
                model_index=self.belt_model,
                x=x,
                y=y,
                z=Fraction(z),
                width=1,
                height=1,
                carries_item=item,
            ),
            level=z,
        )
        return rd._Port(index, x, y, z=z)

    def connect(
        self,
        source: rd._Port,
        sink: rd._Port,
        points: list[Cell],
        item: str,
        rate: Fraction,
        role: str,
    ) -> None:
        cells = path_through(points)
        assert cells[0] == (source.x, source.y, source.z)
        assert cells[-1] == (sink.x, sink.y, sink.z)
        if self.canvas.buildings[source.belt].output_obj is not None:
            raise ConstructionRefusal(f"source {source.belt} needs a physical splitter")
        indices = [source.belt]
        indices.extend(self.belt(cell, item).belt for cell in cells[1:-1])
        indices.append(sink.belt)
        for left, right in zip(indices, indices[1:], strict=False):
            self.canvas.buildings[left] = rd._relink(self.canvas.buildings[left], output_obj=right)
        self.links.append(ConstructedLink(item, source.belt, sink.belt, rate, cells, role))

    def splitter(self, x: int, y: int, item: str) -> int:
        node = junction.make_splitter(x, y, carries_item=item)
        if not junction.site_is_clear(self.canvas.buildings, x, y):
            raise ConstructionRefusal(f"fixed splitter seat is occupied: {item} at {(x, y)}")
        index = self.canvas.add(node)
        self.junctions.append(index)
        return index

    def dock(self, index: int, direction: tuple[int, int], *, feed: bool) -> Terminal:
        node = self.canvas.buildings[index]
        assert any(
            port.dock == (*direction, 0)
            for port in junction._route_ports(node.model_index, node.yaw)
        )
        # Game attachment records are colocated stubs, not the adjacent lattice
        # docks used by route queries. Canonical slot binding emits port poses.
        stub = self.canvas.add(
            rd.PlacedBuilding(
                item_id=self.belt_id,
                model_index=self.belt_model,
                x=node.x,
                y=node.y,
                z=node.z,
                width=1,
                height=1,
                carries_item=node.carries_item,
            )
        )
        port = rd._Port(stub, int(node.x), int(node.y), z=int(node.z))
        self.canvas.buildings[port.belt] = (
            junction.attach_input(self.canvas.buildings[port.belt], index)
            if feed
            else junction.attach_output(self.canvas.buildings[port.belt], index)
        )
        return Terminal(port, direction)

    def flight(
        self,
        source: Terminal,
        sink: Terminal,
        item: str,
        rate: Fraction,
        level: int,
        middle_x: int,
        role: str,
    ) -> None:
        if level >= self.canvas.levels:
            raise ConstructionRefusal("fixed flight allocation exceeds original technology")
        a, b = source.port, sink.port
        ax, ay = a.x + 2 * source.outward[0], a.y + 2 * source.outward[1]
        bx, by = b.x + 2 * sink.outward[0], b.y + 2 * sink.outward[1]
        self.connect(
            a,
            b,
            [
                (a.x, a.y, a.z),
                (ax, ay, a.z),
                (ax, ay, level),
                (middle_x, ay, level),
                (middle_x, by, level),
                (bx, by, level),
                (bx, by, b.z),
                (b.x, b.y, b.z),
            ],
            item,
            rate,
            role,
        )


def run() -> None:
    rows = TypeAdapter(list[Case]).validate_json((ROOT / "frozen/manifest.json").read_text())
    case = next(row for row in rows if row.name == "three-output")
    original_raw = (ROOT / "frozen/three-output.json").read_bytes()
    assert hashlib.sha256(original_raw).hexdigest() == case.spec_sha256
    original = BuildSpec.model_validate_json(original_raw)
    groups = [
        group for group in original.groups if group.recipe_id in {"circuit-board", "processor"}
    ]
    assert len(groups) == 2
    spec = sub_spec(original, [Unit(i, group, group.count) for i, group in enumerate(groups)], 0)
    assert spec.machine_count == 14 and "circuit-board" not in spec.external_inputs
    rules = belt_rules_for_url(case.url, canonicalize_dataset(load_vendored()))
    output = ROOT / "constructive-witness"
    output.mkdir(exist_ok=True)
    raw = spec.model_dump_json(indent=2)
    (output / "spec.json").write_text(raw)
    result: dict[str, object] = {
        "kind": "derived-two-unit-mismatch",
        "original_factory_gate": False,
        "spec_sha256": hashlib.sha256(raw.encode()).hexdigest(),
        "budget_s": 30,
        "global_router_calls": 0,
    }
    started = time.monotonic()
    constructor = Constructor(spec, rules)
    try:
        strips = freeform.plan_strips(spec, strip_len=2, band_policy=POLICY)
        adapted = rd._adapt(spec)
        producer_strips = [s for s in strips if "circuit-board" in adapted[s.group_key].outputs]
        consumer_strips = [s for s in strips if "processor" in adapted[s.group_key].outputs]
        assert [s.machines for s in producer_strips] == [2, 2]
        assert [s.machines for s in consumer_strips] == [2] * 5
        left_x = 10
        left_width = max(freeform._box(s)[0] for s in producer_strips)
        right_x = left_x + left_width + 24
        step_y = max(freeform._box(s)[1] for s in strips) + 6
        input_ports: list[tuple[str, rd._Port, Fraction, int]] = []
        output_ports: list[tuple[str, rd._Port, Fraction, int]] = []
        rates = {
            item: max(
                (g.outputs.get(item, Fraction()) * g.count for g in adapted.values()),
                default=Fraction(),
            )
            for item in {i for g in adapted.values() for i in g.outputs}
        }
        for block, members in enumerate((producer_strips, consumer_strips)):
            for rank, strip in enumerate(members):
                group = adapted[strip.group_key]
                ordinal = strips.index(strip)
                ins, outs, _, fixed = rd._emit_strip(
                    constructor.canvas,
                    strip,
                    (left_x if block == 0 else right_x) + strip.west_channel,
                    10 + rank * step_y,
                    constructor.belt_id,
                    constructor.belt_model,
                    rates,
                    group.inputs,
                    group.outputs,
                    owner_strip=ordinal,
                )
                if fixed:
                    raise ConstructionRefusal("witness unexpectedly requires a piler transition")
                input_ports.extend(
                    (item, port, group.inputs[item] * strip.machines, block)
                    for item, port in ins.items()
                )
                output_ports.extend(
                    (item, port, group.outputs[item] * strip.machines, block)
                    for (item, _, _), port in outs.items()
                )
        tails = [
            LaneEnd(block, port.belt, item, rate)
            for item, port, rate, block in output_ports
            if item == "circuit-board"
        ]
        heads = [
            LaneEnd(block, port.belt, item, rate)
            for item, port, rate, block in input_ports
            if item == "circuit-board"
        ]
        flows = assign_lanes([Cut("circuit-board", 0, 1, Fraction(20, 3))], {0: tails}, {1: heads})
        for tail in tails:
            assert sum((f.rate for f in flows if f.src == tail), Fraction()) == tail.rate
        for head in heads:
            assert sum((f.rate for f in flows if f.dst == head), Fraction()) == head.rate
        by_source: dict[int, list[LaneFlow]] = defaultdict(list)
        by_sink: dict[int, list[LaneFlow]] = defaultdict(list)
        for flow in flows:
            by_source[flow.src.building].append(flow)
            by_sink[flow.dst.building].append(flow)
        assert max(map(len, by_source.values())) == 3 and max(map(len, by_sink.values())) == 2
        result["lane_assignment"] = [asdict(flow) for flow in flows]
        ports = {port.belt: port for _, port, _, _ in (*input_ports, *output_ports)}
        sources: dict[LaneFlow, Terminal] = {}
        sinks: dict[LaneFlow, Terminal] = {}
        directions = ((1, 0), (0, 1), (0, -1))
        for belt, family in by_source.items():
            port = ports[belt]
            node = constructor.splitter(port.x + 4, port.y, "circuit-board")
            dock = constructor.dock(node, (-1, 0), feed=True)
            constructor.connect(
                port,
                dock.port,
                [(port.x, port.y, 0), (dock.port.x, dock.port.y, 0)],
                "circuit-board",
                sum((f.rate for f in family), Fraction()),
                "local-source",
            )
            for flow, direction in zip(family, directions, strict=True):
                sources[flow] = constructor.dock(node, direction, feed=False)
        for belt, family in by_sink.items():
            port = ports[belt]
            if len(family) == 1:
                sinks[family[0]] = Terminal(port, (-1, 0))
                continue
            node = constructor.splitter(port.x - 6, port.y, "circuit-board")
            dock = constructor.dock(node, (1, 0), feed=False)
            constructor.connect(
                dock.port,
                port,
                [(dock.port.x, dock.port.y, 0), (port.x, port.y, 0)],
                "circuit-board",
                sum((f.rate for f in family), Fraction()),
                "local-merge",
            )
            for flow, direction in zip(family, ((-1, 0), (0, 1)), strict=True):
                sinks[flow] = constructor.dock(node, direction, feed=True)
        middle_x = (left_x + left_width + right_x) // 2
        for index, flow in enumerate(flows):
            constructor.flight(
                sources[flow], sinks[flow], flow.item, flow.rate, 3 + index, middle_x, "internal"
            )
        external = [
            (item, port, rate) for item, port, rate, _ in input_ports if item != "circuit-board"
        ]
        for index, (item, port, rate) in enumerate(external):
            root = constructor.belt((0, -4 - 3 * index, 0), item)
            constructor.flight(
                Terminal(root, (1, 0)),
                Terminal(port, (-1, 0)),
                item,
                rate,
                3 + len(flows) + index,
                middle_x,
                "external",
            )
        right_edge = max(port.x for _, port, _, _ in output_ports) + 6
        for item, port, rate, _ in output_ports:
            if item != "processor":
                continue
            end = constructor.belt((right_edge, port.y, 0), item)
            constructor.connect(
                port, end, [(port.x, port.y, 0), (end.x, end.y, 0)], item, rate, "output"
            )

        def cancelled() -> bool:
            return time.monotonic() >= started + 30

        constructor.canvas.limit = rd._core_bounds(constructor.canvas)
        demand = (
            left_x,
            10,
            right_x + max(freeform._box(s)[0] for s in consumer_strips),
            10
            + (len(consumer_strips) - 1) * step_y
            + max(freeform._box(s)[1] for s in consumer_strips),
        )
        sites = rd._power_plan(constructor.canvas, demand, policy=POLICY, cancelled=cancelled)
        constructor.canvas.keep_out.clear()
        rd._place_power(constructor.canvas, sites)
        placement = Placement(buildings=assign_sorter_slots(constructor.canvas.buildings))
        placement = finalize.finalize_placement(placement, POLICY, cancelled=cancelled)
        report = validate.judge_placement(
            placement, spec, ids=pipeline._id_map(spec), expect_power=True, belt_rules=rules
        )
        (output / "report.json").write_text(json.dumps(asdict(report), indent=2, default=str))
        result.update(
            {
                "checks_run": len(report.checks_run),
                "errors": len(report.errors),
                "skipped": report.skipped,
                "area": placement.area,
                "bounds": placement.bounds,
            }
        )
        if report.errors or report.skipped or set(report.checks_run) != set(validate.CHECKS):
            result["outcome"] = "combined-spec-refused"
            return
        blueprint = codec.encode(markers.mark_external_belts(placement, spec))
        decoded = codec.decode(blueprint)
        assert len(decoded.buildings) == len(placement.buildings)
        (output / "blueprint.txt").write_text(blueprint)
        result.update(
            {
                "outcome": "local-composition-clean",
                "buildings": len(decoded.buildings),
                "within_budget": not cancelled(),
            }
        )
    except (
        ConstructionRefusal,
        rd._Unseatable,
        rd._PreparationDeadline,
        finalize.ProjectionRefusal,
        finalize.ProjectionCancelled,
    ) as failure:
        result.update({"outcome": "constructive-interface-refused", "reason": str(failure)})
    finally:
        result.update(
            {
                "elapsed_s": time.monotonic() - started,
                "junctions": constructor.junctions,
                "constructed_links": len(constructor.links),
            }
        )
        (output / "links.json").write_text(
            json.dumps([asdict(link) for link in constructor.links], indent=2, default=str)
        )
        (output / "result.json").write_text(json.dumps(result, indent=2, default=str))
        print(json.dumps(result, default=str), flush=True)


if __name__ == "__main__":
    run()
