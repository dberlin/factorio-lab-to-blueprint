"""Fixed-rule held-outs and explicit optimistic cost bounds, not factories."""

from __future__ import annotations

import hashlib
import json
import math
import time
from dataclasses import replace
from fractions import Fraction
from pathlib import Path

from pydantic import TypeAdapter

from flab2bp.lab.data import load_vendored
from flab2bp.lab.flow import canonicalize_dataset
from flab2bp.lab.techs import belt_rules_for_url
from flab2bp.layout import finalize
from flab2bp.layout import routing_domain as rd
from flab2bp.spec import BuildSpec

from .run_experiment import Case
from .transport_first import PITCH, POLICY, TURN, capture_inventory, channel_plan, summary

ROOT = Path(__file__).resolve().parent


def run() -> None:
    rows = TypeAdapter(list[Case]).validate_json((ROOT / "frozen/manifest.json").read_text())
    dataset = canonicalize_dataset(load_vendored())
    output = ROOT / "fixed-rule-generalization"
    output.mkdir(exist_ok=True)
    aggregate: list[dict[str, object]] = []
    for case in sorted(rows, key=lambda case: case.held_out):
        started = time.monotonic()
        raw = (ROOT / "frozen" / f"{case.name}.json").read_bytes()
        assert hashlib.sha256(raw).hexdigest() == case.spec_sha256
        spec = BuildSpec.model_validate_json(raw)
        rules = belt_rules_for_url(case.url, dataset)
        inventory = capture_inventory(spec, rules, started + case.budget_s)
        plan = channel_plan(inventory, rules)
        result = summary(inventory, plan)
        result.update(
            {
                "case": case.name,
                "held_out": case.held_out,
                "spec_sha256": case.spec_sha256,
                "outcome": "band-admitted-unverified"
                if plan.fits_band
                else "topology-band-refused",
                "original_factory_gate": False,
                "settlement": "not reached: primary physical integration refused",
            }
        )
        # Charge every actual coater locally, but one globally rated service
        # interface per strip. Total original spray demand itself fits one belt,
        # so this is a conservative per-strip capacity bound without apportioning
        # mixed recipes by machine counts or fabricating a new factory boundary.
        service = [d for d in inventory.demands if d.role == "coater-service"]
        spray_total = sum(
            (rate for item, rate in spec.external_inputs.items() if "proliferator" in item),
            Fraction(),
        )
        result["coater_service_demands"] = len(service)
        result["original_spray_rate"] = str(spray_total)
        if service:
            assert spray_total <= spec.lane_capacity
            modules = {d.sink.strip for d in service if d.sink is not None}
            retained = [d for d in inventory.demands if d.role != "coater-service"]
            for module in sorted(modules):
                representative = next(
                    d for d in service if d.sink is not None and d.sink.strip == module
                )
                retained.append(replace(representative, role="module-service-envelope"))
            reduced = replace(
                inventory, demands=tuple(replace(d, ordinal=i) for i, d in enumerate(retained))
            )
            reduced_plan = channel_plan(reduced, rules)
            result["local_service_sharing_price"] = {
                "global_service_interfaces": len(modules),
                "frame": (reduced_plan.width, reduced_plan.height),
                "fits_band_cost_only": reduced_plan.fits_band,
                "physical_status": (
                    "not implemented: needs locally compiled and globally connected service roots"
                ),
            }
        # This removes column pressure only by assuming safe layer-changing
        # interfaces. It is deliberately NOT an admissible geometry or a route.
        pairs = (plan.levels - 2) // 2
        compact_width = (
            plan.width
            - sum(b.width for b in plan.bays)
            + sum(2 * TURN + PITCH * math.ceil(len(b.ports) / pairs) for b in plan.bays)
        )
        compact_fits = bool(
            finalize.band_policy_search_envelope(POLICY, perimeter=rd._ENTRY_RING).frame_candidates(
                compact_width, plan.height
            )
        )
        result["multiplexed_access_optimistic_price"] = {
            "frame": (compact_width, plan.height),
            "fits_band_cost_only": compact_fits,
            "physical_status": (
                "unproved cross-layer access and shared-column conflicts; not an admitted plan"
            ),
        }
        result["elapsed_s"] = time.monotonic() - started
        (output / f"{case.name}.json").write_text(json.dumps(result, indent=2, default=str))
        concise = {k: v for k, v in result.items() if k not in ("plan", "demands_detail")}
        aggregate.append(concise)
        print(json.dumps(concise), flush=True)
    (output / "summary.json").write_text(json.dumps(aggregate, indent=2, default=str))


if __name__ == "__main__":
    run()
