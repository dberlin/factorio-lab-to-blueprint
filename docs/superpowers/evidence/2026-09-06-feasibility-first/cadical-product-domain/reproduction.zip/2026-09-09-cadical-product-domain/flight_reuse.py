"""Throwaway joint fixed-path level reuse; no global router or relaxed geometry."""

from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from typing import override

from flab2bp.dsp import catalog
from flab2bp.layout import routing_domain as rd
from flab2bp.layout.route_feedback import Cell
from flab2bp.spec import BuildSpec

from .constructive_composition import ConstructionRefusal, Constructor, Terminal, path_through


def occupied_cells(path: tuple[Cell, ...]) -> set[Cell]:
    """Include every height crossed by an emitted direct vertical link."""
    cells = set(path)
    for a, b in zip(path, path[1:], strict=False):
        if a[:2] == b[:2] and a[2] != b[2]:
            cells.update((a[0], a[1], z) for z in range(min(a[2], b[2]), max(a[2], b[2]) + 1))
    return cells


@dataclass(frozen=True)
class Flight:
    source: Terminal
    sink: Terminal
    item: str
    rate: Fraction
    exclusive_level: int
    middle_x: int
    role: str

    def points(self, level: int) -> list[Cell]:
        reverse = self.role == "local-sink"
        source, sink = (self.sink, self.source) if reverse else (self.source, self.sink)
        a, b = source.port, sink.port
        local = self.role in ("local-source", "local-sink")
        launch = 2 * self.exclusive_level if local else 2
        ax, ay = a.x + launch * source.outward[0], a.y + launch * source.outward[1]
        bx, by = b.x + 2 * sink.outward[0], b.y + 2 * sink.outward[1]
        # Input lanes may begin at the machine edge; stay two cells west of it.
        # Ascending sink ranks terminate beyond the lower-ranked collector trees.
        middle_x = a.x - 2 if local and self.exclusive_level > 1 else self.middle_x
        points = [
            (a.x, a.y, a.z),
            (ax, ay, a.z),
            (ax, ay, level),
            (middle_x, ay, level),
            (middle_x, by, level),
            (bx, by, level),
            (bx, by, b.z),
            (b.x, b.y, b.z),
        ]
        if reverse:
            points.reverse()
        return points


class ReusingConstructor(Constructor):
    def __init__(self, spec: BuildSpec, rules: catalog.BeltAltitudeRules) -> None:
        super().__init__(spec, rules)
        self.occupied: set[Cell] = set()
        self.allocations: list[dict[str, object]] = []
        self.pending: list[Flight] = []

    @override
    def connect(
        self,
        source: rd._Port,
        sink: rd._Port,
        points: list[Cell],
        item: str,
        rate: Fraction,
        role: str,
    ) -> None:
        path = path_through(points)
        full = occupied_cells(path) - {path[0], path[-1]}
        blocked = full & self.occupied
        if blocked:
            raise ConstructionRefusal(f"constructed paths intersect: {item} at {min(blocked)}")
        if len(path) != len(set(path)):
            raise ConstructionRefusal(f"fixed path retraces itself: {item}")
        for cell in sorted(full):
            if not self.canvas.free(cell):
                raise ConstructionRefusal(
                    f"constructed path meets fixed geometry: {item} at {cell}"
                )
        super().connect(source, sink, points, item, rate, role)
        self.occupied.update(occupied_cells(path))

    @override
    def flight(
        self,
        source: Terminal,
        sink: Terminal,
        item: str,
        rate: Fraction,
        level: int,
        middle_x: int,
        role: str,
    ) -> None:
        self.pending.append(Flight(source, sink, item, rate, level, middle_x, role))

    def finish(self) -> None:
        """Allocate heights jointly, then emit through the guarded constructor.

        A plane crossing another flight's ground-origin riser must be ABOVE that
        flight. Horizontal overlap forbids an equal level. These constraints use all
        future columns, unlike online first-fit. Fixed local transfers keep levels 1/2.
        """
        global_ids = [
            i for i, f in enumerate(self.pending) if f.role not in ("local-source", "local-sink")
        ]
        planes: dict[int, set[tuple[int, int]]] = {}
        columns: dict[int, set[tuple[int, int]]] = {}
        predecessors: dict[int, set[int]] = {i: set() for i in global_ids}
        conflicts: dict[int, set[int]] = {i: set() for i in global_ids}
        for i in global_ids:
            flight = self.pending[i]
            if flight.source.port.z or flight.sink.port.z:
                raise ConstructionRefusal("joint prototype requires ground-origin terminals")
            points = flight.points(3)
            planes[i] = {cell[:2] for cell in path_through(points[2:6])}
            columns[i] = {points[2][:2], points[5][:2]}
        for position, i in enumerate(global_ids):
            for j in global_ids:
                if i != j and planes[i] & columns[j]:
                    predecessors[i].add(j)
            for j in global_ids[position + 1 :]:
                if planes[i] & planes[j]:
                    conflicts[i].add(j)
                    conflicts[j].add(i)
        # A deterministic topological order, not a search or a relaxed coloring.
        order: list[int] = []
        remaining = set(global_ids)
        while remaining:
            ready = sorted(i for i in remaining if not predecessors[i] & remaining)
            if not ready:
                self.allocations.append(
                    {
                        "precedence_cycle": [
                            {
                                "id": i,
                                "item": self.pending[i].item,
                                "predecessors": sorted(predecessors[i] & remaining),
                            }
                            for i in sorted(remaining)
                        ]
                    }
                )
                raise ConstructionRefusal(
                    "fixed paths contain a cyclic plane/riser height dependency"
                )
            order.extend(ready)
            remaining.difference_update(ready)
        levels: dict[int, int] = {}
        local_ids = [
            i for i, f in enumerate(self.pending) if f.role in ("local-source", "local-sink")
        ]
        for i in local_ids + order:
            flight = self.pending[i]
            minimum = max((levels[j] + 1 for j in predecessors.get(i, set())), default=3)
            candidates = (
                (flight.exclusive_level,) if i in local_ids else range(minimum, self.canvas.levels)
            )
            rejected: list[dict[str, object]] = []
            for candidate in candidates:
                if any(levels.get(j) == candidate for j in conflicts.get(i, set())):
                    rejected.append({"level": candidate, "reason": "horizontal-overlap"})
                    continue
                points = flight.points(candidate)
                path = path_through(points)
                if len(path) != len(set(path)):
                    raise ConstructionRefusal(f"fixed flight retraces itself: {flight.item}")
                full = occupied_cells(path) - {path[0], path[-1]}
                blocked = full & self.occupied
                static = next((cell for cell in sorted(full) if not self.canvas.free(cell)), None)
                if blocked or static is not None:
                    rejected.append(
                        {
                            "level": candidate,
                            "occupied": min(blocked) if blocked else None,
                            "fixed": static,
                        }
                    )
                    continue
                self.connect(
                    flight.source.port,
                    flight.sink.port,
                    points,
                    flight.item,
                    flight.rate,
                    flight.role,
                )
                levels[i] = candidate
                self.allocations.append(
                    {
                        "id": i,
                        "item": flight.item,
                        "role": flight.role,
                        "level": candidate,
                        "exclusive_level": flight.exclusive_level,
                        "predecessors": sorted(predecessors.get(i, set())),
                        "rejected": rejected,
                    }
                )
                break
            else:
                self.allocations.append(
                    {
                        "id": i,
                        "item": flight.item,
                        "role": flight.role,
                        "level": None,
                        "minimum": minimum,
                        "rejected": rejected,
                    }
                )
                raise ConstructionRefusal(
                    f"no legal reused level on fixed flight: {flight.item}, {flight.role}"
                )
