"""Independent singleton-source capacity cuts in the frozen captured topology."""

from __future__ import annotations

import hashlib
import json
import time
from collections import defaultdict
from fractions import Fraction

from pydantic import TypeAdapter

from flab2bp.lab.data import load_vendored
from flab2bp.lab.flow import canonicalize_dataset
from flab2bp.lab.techs import belt_rules_for_url
from flab2bp.layout import routing_domain as rd
from flab2bp.spec import BuildSpec

from .constructive_control import ROOT
from .run_experiment import Case
from .transport_first import capture_inventory


def run() -> None:
    name = "unsprayed-mall"
    raw = (ROOT / "frozen" / f"{name}.json").read_bytes()
    spec = BuildSpec.model_validate_json(raw)
    case = next(
        row
        for row in TypeAdapter(list[Case]).validate_json(
            (ROOT / "frozen/manifest.json").read_text()
        )
        if row.name == name
    )
    assert hashlib.sha256(raw).hexdigest() == case.spec_sha256
    rules = belt_rules_for_url(case.url, canonicalize_dataset(load_vendored()))
    inventory = capture_inventory(spec, rules, time.monotonic() + case.budget_s)
    assert inventory.prelinked == 0
    adapted = rd._adapt(spec)
    options: dict[tuple[str, int], set[int | None]] = defaultdict(set)
    for demand in inventory.demands:
        if demand.sink is not None:
            options[demand.item, demand.sink.strip].add(
                demand.source.strip if demand.source is not None else None
            )
    forced: dict[tuple[str, int], list[int]] = defaultdict(list)
    for (item, sink), sources in options.items():
        if len(sources) == 1:
            source = next(iter(sources))
            if source is not None:
                forced[item, source].append(sink)
    cuts: list[dict[str, object]] = []
    for (item, source), sinks in sorted(forced.items()):
        strip = inventory.strips[source]
        available = adapted[strip.group_key].outputs[item] * strip.machines
        required = {
            sink: adapted[inventory.strips[sink].group_key].inputs[item]
            * inventory.strips[sink].machines
            for sink in sinks
        }
        total = sum(required.values(), Fraction())
        if total > available:
            cuts.append(
                {
                    "item": item,
                    "source_strip": source,
                    "source_group": strip.group_key,
                    "source_machines": strip.machines,
                    "capacity": str(available),
                    "forced_consumers": {str(k): str(v) for k, v in required.items()},
                    "required": str(total),
                    "deficit": str(total - available),
                }
            )
    assert cuts, "the original mall must retain its independently witnessed capacity cut"
    result = {
        "case": name,
        "spec_sha256": case.spec_sha256,
        "scope": "captured adjacency, not original-factory infeasibility",
        "cuts": cuts,
    }
    (ROOT / "reuse-capacity-certificate.json").write_text(json.dumps(result, indent=2))
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    run()
