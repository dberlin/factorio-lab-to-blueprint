"""Focused executable experiment probes. Main runs these after integration."""

from __future__ import annotations

import json
import time
from dataclasses import asdict, replace
from fractions import Fraction

from flab2bp.dsp import catalog, codec
from flab2bp.layout import junction, slots
from flab2bp.layout.base import AreaFrame, PlacedBuilding, Placement
from flab2bp.spec import BuildSpec, MachineGroup

from .template_audit import (
    AuditReport,
    RateReport,
    audit_blueprint,
    audit_placement,
    rate_assessment,
)
from .template_budget import WorkBudget


class Fixture:
    def __init__(self) -> None:
        self.buildings: list[PlacedBuilding] = []

    def add(self, building: PlacedBuilding) -> int:
        index = len(self.buildings)
        self.buildings.append(building)
        return index

    def belt(self, x: int, y: int, item: str, z: int = 0) -> int:
        return self.add(
            PlacedBuilding(
                2001, catalog.building(2001).model_index, x, y, Fraction(z), carries_item=item
            )
        )

    def chain(self, points: tuple[tuple[int, int], ...], item: str) -> tuple[int, ...]:
        indices = tuple(self.belt(x, y, item) for x, y in points)
        for a, b in zip(indices, indices[1:], strict=False):
            self.buildings[a] = replace(self.buildings[a], output_obj=b)
        return indices

    def machine(self, item: str, recipe: str, x: int, y: int) -> int:
        info = catalog.building(catalog.item_id(item))
        return self.add(
            PlacedBuilding(
                info.item_id,
                info.model_index,
                x,
                y,
                width=info.width,
                height=info.height,
                recipe_id=catalog.recipe_id(recipe),
            )
        )

    def sorter(self, machine: int, belt: int, *, feed: bool, tier: int = 2013) -> int:
        host, target = self.buildings[machine], self.buildings[belt]
        anchor = slots.attachment(host, (target.x, target.y))
        if anchor is None:
            raise ValueError(f"witness machine {machine} cannot reach belt {belt}")
        machine_xy, belt_xy = anchor.cell, (target.x, target.y)
        start, end = (belt_xy, machine_xy) if feed else (machine_xy, belt_xy)
        return self.add(
            PlacedBuilding(
                tier,
                catalog.building(tier).model_index,
                *start,
                x2=end[0],
                y2=end[1],
                z2=Fraction(),
                input_obj=belt if feed else machine,
                output_obj=machine if feed else belt,
                carries_item=target.carries_item,
            )
        )

    def dock(self, host: int, dx: int, dy: int, *, feed: bool) -> tuple[int, ...]:
        node = self.buildings[host]
        item = node.carries_item
        if item is None:
            raise ValueError("witness junction needs an explicit item")
        cells = tuple((node.x + n * dx, node.y + n * dy) for n in range(4))
        indices = self.chain(tuple(reversed(cells)) if feed else cells, item)
        stub = indices[-1] if feed else indices[0]
        self.buildings[stub] = (
            replace(self.buildings[stub], output_obj=host)
            if feed
            else replace(self.buildings[stub], input_obj=host)
        )
        return indices

    def placement(self) -> Placement:
        return Placement(slots.assign_sorter_slots(self.buildings))


def rules() -> catalog.BeltAltitudeRules:
    return catalog.BeltAltitudeRules(Fraction(26), True, 8, 8, False)


def long_segment_negative(budget: WorkBudget) -> AuditReport:
    fixture = Fixture()
    a = fixture.belt(10, 10, "iron-ingot", 0)
    b = fixture.belt(10, 10, "iron-ingot", 6)
    c = fixture.belt(9, 10, "iron-ingot", 3)
    d = fixture.belt(11, 10, "iron-ingot", 3)
    fixture.buildings[a] = replace(fixture.buildings[a], output_obj=b)
    fixture.buildings[c] = replace(fixture.buildings[c], output_obj=d)
    report = audit_placement(fixture.placement(), BuildSpec(groups=()), rules(), budget)
    assert not report.passed
    assert any("FULL_SEGMENT_CONFLICT" in finding for finding in report.findings)
    return report


def endpoint_ownership_negative(budget: WorkBudget) -> AuditReport:
    fixture = Fixture()
    fixture.chain(((9, 10), (10, 10)), "iron-ingot")
    fixture.chain(((10, 10), (11, 10)), "iron-ingot")
    report = audit_placement(fixture.placement(), BuildSpec(groups=()), rules(), budget)
    assert not report.passed
    assert any("FULL_SEGMENT_CONFLICT" in finding for finding in report.findings)
    return report


def physical_capacity_positive(budget: WorkBudget) -> tuple[AuditReport, RateReport, AuditReport]:
    spec = BuildSpec(
        groups=(), external_inputs={"iron-ingot": Fraction(3)}, outputs={"iron-ingot": Fraction(3)}
    )
    fixture = Fixture()
    fixture.chain(tuple((x, 10) for x in range(6, 15)), "iron-ingot")
    placement = fixture.placement()
    geometry = audit_placement(placement, spec, rules(), budget)
    capacity = rate_assessment(placement, spec, rules(), budget)
    assert geometry.passed, geometry.findings
    assert capacity.capacity_feasible and capacity.cut is None
    assert capacity.status == "RATE_REALIZATION_UNPROVED"
    # This small framed physical artifact exercises the real codec round trip.
    framed = replace(placement, frame=AreaFrame(24, 24, 200, (200,), False))
    marked = replace(
        framed,
        buildings=tuple(
            replace(b, parameters=catalog.belt_marker(catalog.item_id("iron-ingot")))
            for b in framed.buildings
        ),
    )
    decoded = audit_blueprint(codec.encode(marked), spec, rules(), budget)
    assert decoded.passed, decoded.findings
    return geometry, capacity, decoded


def shared_producer_cut(budget: WorkBudget) -> tuple[RateReport, RateReport]:
    spec = BuildSpec(
        groups=(
            MachineGroup(
                recipe_id="iron-ingot",
                machine_item_id="arc-smelter",
                count=1,
                inputs_per_machine={"iron-ore": Fraction(1)},
                outputs_per_machine={"iron-ingot": Fraction(1)},
            ),
        ),
        external_inputs={"iron-ore": Fraction(1)},
        outputs={"iron-ingot": Fraction(1)},
    )
    fixture = Fixture()
    machine = fixture.machine("arc-smelter", "iron-ingot", 20, 20)
    host = fixture.buildings[machine]
    cx = host.x + host.width // 2
    incoming = fixture.chain(tuple((x, host.y - 3) for x in range(cx - 4, cx + 1)), "iron-ore")
    outgoing = fixture.chain(
        tuple((x, host.y + host.height + 2) for x in range(cx, cx + 5)), "iron-ingot"
    )
    fixture.sorter(machine, incoming[-1], feed=True)
    extraction = fixture.sorter(machine, outgoing[0], feed=False, tier=2011)
    split = fixture.add(
        junction.make_splitter(cx + 8, host.y + host.height + 2, carries_item="iron-ingot")
    )
    feeder = fixture.dock(split, -1, 0, feed=True)
    fixture.buildings[outgoing[-1]] = replace(fixture.buildings[outgoing[-1]], output_obj=feeder[0])
    fixture.dock(split, 1, 0, feed=False)
    fixture.dock(split, 0, 1, feed=False)
    placement = fixture.placement()
    cut = rate_assessment(placement, spec, rules(), budget)
    assert not cut.capacity_feasible and cut.cut is not None, cut.findings
    assert cut.cut.capacity == cut.achieved < cut.required
    assert any(
        edge.kind == "actual-sorter-capacity" and extraction in edge.buildings
        for edge in cut.cut.edges
    )
    upgraded = list(placement.buildings)
    upgraded[extraction] = replace(
        upgraded[extraction], item_id=2013, model_index=catalog.building(2013).model_index
    )
    positive = rate_assessment(replace(placement, buildings=tuple(upgraded)), spec, rules(), budget)
    assert positive.capacity_feasible, positive.findings
    assert positive.status == "RATE_REALIZATION_UNPROVED"
    return cut, positive


def annotation_split_refusal(budget: WorkBudget) -> tuple[AuditReport, RateReport]:
    """3/s supply, internal 2/s demand, open 1/s export: never certify annotation."""
    spec = BuildSpec(
        groups=(
            MachineGroup(
                recipe_id="steel",
                machine_item_id="plane-smelter",
                count=1,
                inputs_per_machine={"iron-ingot": Fraction(2)},
                outputs_per_machine={"steel": Fraction(2, 3)},
            ),
        ),
        external_inputs={"iron-ingot": Fraction(3)},
        outputs={"iron-ingot": Fraction(1), "steel": Fraction(2, 3)},
    )
    fixture = Fixture()
    split = fixture.add(junction.make_splitter(10, 10, carries_item="iron-ingot"))
    fixture.dock(split, -1, 0, feed=True)
    internal = fixture.dock(split, 1, 0, feed=False)
    fixture.dock(split, 0, 1, feed=False)
    machine = fixture.machine("plane-smelter", "steel", 15, 9)
    fixture.sorter(machine, internal[-1], feed=True)
    host = fixture.buildings[machine]
    cx = host.x + host.width // 2
    output = fixture.chain(tuple((cx, host.y + host.height + n) for n in range(2, 5)), "steel")
    fixture.sorter(machine, output[0], feed=False)
    placement = fixture.placement()
    geometry = audit_placement(placement, spec, rules(), budget)
    report = rate_assessment(placement, spec, rules(), budget)
    assert report.capacity_feasible, report.findings
    assert report.status == "RATE_REALIZATION_UNPROVED"
    assert any("allocation" in reason for reason in report.unproved_mechanics)
    # This is conditional algebra, NOT a claim that DSP implements fair sharing.
    hypothetical_equal_share = Fraction(3, 2)
    assert hypothetical_equal_share < spec.groups[0].inputs_per_machine["iron-ingot"]
    return geometry, report


def owned_dock_positive_and_negative(budget: WorkBudget) -> tuple[AuditReport, AuditReport]:
    fixture = Fixture()
    host = fixture.add(junction.make_splitter(10, 10, carries_item="iron-ingot"))
    fixture.dock(host, -1, 0, feed=True)
    outlet = fixture.dock(host, 1, 0, feed=False)
    placement = fixture.placement()
    spec = BuildSpec(
        groups=(), external_inputs={"iron-ingot": Fraction(1)}, outputs={"iron-ingot": Fraction(1)}
    )
    positive = audit_placement(placement, spec, rules(), budget)
    assert positive.passed, positive.findings
    wrong = list(placement.buildings)
    wrong[outlet[0]] = replace(
        wrong[outlet[0]], input_from_slot=(wrong[outlet[0]].input_from_slot + 1) % 4
    )
    negative = audit_placement(replace(placement, buildings=tuple(wrong)), spec, rules(), budget)
    assert not negative.passed
    assert any("junction.port_pose" in finding for finding in negative.findings)
    return positive, negative


def run() -> None:
    budget = WorkBudget(time.monotonic() + 30)
    results = {
        "long_segment": asdict(long_segment_negative(budget)),
        "endpoint_ownership": asdict(endpoint_ownership_negative(budget)),
        "physical_capacity": [asdict(r) for r in physical_capacity_positive(budget)],
        "shared_producer": [asdict(r) for r in shared_producer_cut(budget)],
        "annotation_split": [asdict(r) for r in annotation_split_refusal(budget)],
        "owned_dock": [asdict(r) for r in owned_dock_positive_and_negative(budget)],
        "work": dict(budget.counts),
    }
    print(json.dumps(results, default=str, indent=2))


if __name__ == "__main__":
    run()
