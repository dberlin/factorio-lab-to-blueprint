"""Cold experiment entry point; never changes a frozen original specification."""

from __future__ import annotations

import argparse
import hashlib
import json
import time
from pathlib import Path

from pydantic import BaseModel, ConfigDict, TypeAdapter

from flab2bp.lab.data import load_vendored
from flab2bp.lab.flow import canonicalize_dataset
from flab2bp.lab.techs import belt_rules_for_url
from flab2bp.spec import BuildSpec

from .channel_probe import exercise
from .transport_first import capture_inventory, channel_plan, summary

ROOT = Path(__file__).resolve().parent


class Case(BaseModel):
    model_config = ConfigDict(extra="ignore", frozen=True)
    name: str
    url: str
    spec_sha256: str
    budget_s: float
    held_out: bool


def run(name: str, output: Path) -> None:
    rows = TypeAdapter(list[Case]).validate_json((ROOT / "frozen/manifest.json").read_text())
    case = next(row for row in rows if row.name == name)
    raw = (ROOT / "frozen" / f"{name}.json").read_bytes()
    assert hashlib.sha256(raw).hexdigest() == case.spec_sha256
    spec = BuildSpec.model_validate_json(raw)
    prep_start = time.monotonic()
    rules = belt_rules_for_url(case.url, canonicalize_dataset(load_vendored()))
    request_s = time.monotonic() - prep_start
    started = time.monotonic()
    inventory = capture_inventory(spec, rules, started + case.budget_s)
    captured_s = time.monotonic() - started
    plan = channel_plan(inventory, rules)
    result = summary(inventory, plan)
    result.update(
        {
            "case": name,
            "spec_sha256": case.spec_sha256,
            "held_out": case.held_out,
            "request_preparation_s": request_s,
            "capture_s": captured_s,
            "elapsed_s": time.monotonic() - started,
            "outcome": "band-admitted-unverified" if plan.fits_band else "topology-band-refused",
            "original_factory_gate": False,
            "settlement": "not reached",
        }
    )
    output.parent.mkdir(parents=True, exist_ok=True)
    if plan.fits_band:
        result.update(exercise(spec, rules, inventory, plan, started, case.budget_s, output))
    output.write_text(json.dumps(result, indent=2, default=str))
    print(
        json.dumps({k: v for k, v in result.items() if k not in ("plan", "demands_detail")}),
        flush=True,
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("case")
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    run(args.case, args.output)
