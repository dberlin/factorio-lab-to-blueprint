"""Transport-first module mechanics on the unchanged corrected routing backend.

A module reserves coater node positions before packing. No search may relocate
those nodes. Derived local specimens are never original-factory acceptance.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import time
from dataclasses import asdict, dataclass
from pathlib import Path

from flab2bp import pipeline
from flab2bp.dsp import catalog, codec
from flab2bp.lab.data import load_vendored
from flab2bp.lab.flow import canonicalize_dataset
from flab2bp.lab.techs import belt_rules_for_url
from flab2bp.layout import finalize, freeform, markers, validate
from flab2bp.layout import routing_domain as rd
from flab2bp.layout.band_policy import BandPolicy
from flab2bp.layout.hierarchy.partition import Unit, sub_spec
from flab2bp.spec import BuildSpec

ROOT = Path(__file__).resolve().parent
POLICY = BandPolicy("portable")


@dataclass(frozen=True, slots=True)
class ServiceSite:
    item: str
    head: tuple[int, int]
    node: tuple[int, int]


@dataclass(frozen=True, slots=True)
class ModulePlan:
    origin: tuple[int, int]
    width: int
    height: int
    service_sites: tuple[ServiceSite, ...]


def plan_module(strip: rd.Strip) -> ModulePlan:
    # Five host belts plus the existing one-cell physical clearance ring.
    # The service terminal approaches transversely. Disjoint three-row rings
    # allocate node/service room before the layout sees any machine position.
    node_tiles = rd._COATER_NODE_TILES
    service_pitch = catalog.oriented_footprint(catalog.SPRAY_COATER_ID, 90.0)[1] + 2
    origin = (node_tiles + 4, 2)
    lanes = strip.in_above + strip.in_below
    sites = tuple(
        ServiceSite(
            lane[0],
            (origin[0], origin[1] + strip.row_of_input(lane[0])),
            (1, 2 + service_pitch * index),
        )
        for index, lane in enumerate(lanes)
    )
    width = origin[0] + freeform._box(strip)[0]
    height = max(origin[1] + freeform._box(strip)[1], 2 + service_pitch * len(sites))
    return ModulePlan(origin, width, height, sites)


def run(name: str, output: Path) -> None:
    parent = BuildSpec.model_validate_json((ROOT / f"local-{name}.json").read_text())
    source_strips = freeform.plan_strips(parent, strip_len=48, band_policy=POLICY)
    # This is exactly one planned physical strip, not an arbitrary downscale.
    count = source_strips[0].machines
    spec = sub_spec(parent, [Unit(0, parent.groups[0], count)], 0)
    strips = freeform.plan_strips(spec, strip_len=48, band_policy=POLICY)
    if len(strips) != 1:
        raise ValueError("local mechanics specimen did not retain one canonical strip")
    plan = plan_module(strips[0])
    sites = {site.head: site.node for site in plan.service_sites}
    selected: list[tuple[int, int]] = []
    original_site = rd._coater_node_site

    def planned_site(
        canvas: rd._Canvas, near: tuple[int, int], *, radius: int = 48
    ) -> tuple[int, int] | None:
        position = sites[near]
        selected.append(position)
        return position if rd._coater_node_site_is_clear(canvas, *position) else None

    manifest = json.loads((ROOT / "frozen/manifest.json").read_text())
    url = next(row["url"] for row in manifest if row["name"] == name)
    rules = belt_rules_for_url(url, canonicalize_dataset(load_vendored()))
    output.mkdir(exist_ok=False)
    raw = spec.model_dump_json(indent=2)
    (output / "spec.json").write_text(raw)
    (output / "plan.json").write_text(json.dumps(asdict(plan), indent=2))
    result: dict[str, object] = {
        "case": name,
        "kind": "one-canonical-strip-mechanics",
        "parent_machines": parent.machine_count,
        "local_machines": spec.machine_count,
        "spec_sha256": hashlib.sha256(raw.encode()).hexdigest(),
        "budget_s": 30,
        "router_levels": math.floor(rules.max_z) + 1,
        "original_factory_gate": False,
        "service_locations_fixed_before_packing": True,
    }
    started = time.monotonic()
    rd._coater_node_site = planned_site
    try:
        pack = rd._Pack({0: plan.origin}, plan.width, plan.height, "planned-service-module")
        built = freeform._build(
            spec,
            strips,
            pack,
            power=True,
            route=True,
            policy=POLICY,
            belt_rules=rules,
            deadline=started + 25,
            budget={"left": 25 * freeform._ROUTING_EXPANSIONS_PER_SECOND},
        )
        result.update(
            {
                "preparation_s": built.preparation_time_s,
                "routing_s": built.detailed_route_time_s,
                "routing_status": built.routing.status.value,
                "routing_failures": [asdict(failure) for failure in built.routing.failures],
                "routing_expansions": built.routing.expansions,
                "routing_iterations": built.routing.iterations,
                "routed": len(built.routing.routed),
            }
        )
        if built.placement is None or built.routing.failed_count:
            result["outcome"] = "local-routing-refused"
            return

        def cancelled() -> bool:
            return time.monotonic() >= started + 30

        placement = finalize.compact_open_boundary_belts(
            built.placement, spec, expect_power=True, belt_rules=rules
        )
        placement = finalize.finalize_placement(placement, POLICY, cancelled=cancelled)
        report = validate.judge_placement(
            placement, spec, ids=pipeline._id_map(spec), expect_power=True, belt_rules=rules
        )
        (output / "report.json").write_text(json.dumps(asdict(report), indent=2, default=str))
        result.update(
            {
                "area": placement.area,
                "bounds": placement.bounds,
                "stats": dict(placement.stats),
                "checks_run": len(report.checks_run),
                "skipped": report.skipped,
                "errors": len(report.errors),
            }
        )
        if report.errors or report.skipped or set(report.checks_run) != set(validate.CHECKS):
            result["outcome"] = "local-validation-refused"
            return
        blueprint = codec.encode(markers.mark_external_belts(placement, spec))
        decoded = codec.decode(blueprint)
        assert len(decoded.buildings) == len(placement.buildings)
        assert len(selected) == len(plan.service_sites)
        result.update(
            {
                "outcome": "local-clean",
                "buildings": len(decoded.buildings),
                "within_budget": not cancelled(),
            }
        )
        (output / "blueprint.txt").write_text(blueprint)
    except (rd._Unseatable, finalize.ProjectionRefusal, finalize.ProjectionCancelled) as failure:
        result.update({"outcome": "local-geometry-refused", "reason": str(failure)})
    finally:
        rd._coater_node_site = original_site
        result["elapsed_s"] = time.monotonic() - started
        (output / "result.json").write_text(json.dumps(result, indent=2, default=str))
        print(
            json.dumps(
                {k: v for k, v in result.items() if k not in ("stats", "routing_failures")},
                default=str,
            ),
            flush=True,
        )


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("case", choices=("coated-mall", "universe-matrix"))
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    run(args.case, args.output)
