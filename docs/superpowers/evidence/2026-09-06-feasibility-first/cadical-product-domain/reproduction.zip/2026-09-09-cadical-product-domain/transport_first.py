"""Throwaway, capacity-preserving channel topology on the corrected backend.

Capture the existing exact flow allocation, reserve module/service/access space,
then color disjoint elevated trunk intervals. No production source is modified.
"""

from __future__ import annotations

import heapq
import math
import time
from collections import Counter
from collections.abc import Collection, Mapping, Sequence
from dataclasses import asdict, dataclass
from fractions import Fraction
from types import MappingProxyType

from flab2bp.dsp import catalog
from flab2bp.layout import finalize, freeform
from flab2bp.layout import routing_domain as rd
from flab2bp.layout.band_policy import BAND_DIMENSIONS, BandPolicy
from flab2bp.layout.route_feedback import Cell
from flab2bp.spec import BuildSpec

from .planned_service import ModulePlan, plan_module

POLICY = BandPolicy("portable")
PITCH = 3
TURN = 2


@dataclass(frozen=True)
class Endpoint:
    strip: int
    belt: int
    x: int
    y: int
    z: int


@dataclass(frozen=True)
class TransportDemand:
    ordinal: int
    item: str
    domain: str
    source: Endpoint | None
    sink: Endpoint | None
    role: str


@dataclass(frozen=True)
class Inventory:
    strips: tuple[rd.Strip, ...]
    modules: tuple[ModulePlan, ...]
    demands: tuple[TransportDemand, ...]
    shared_roots: int
    prelinked: int
    shared_groups: tuple[tuple[str, str, tuple[int, ...]], ...]


@dataclass(frozen=True)
class AccessBay:
    bank: int
    side: str
    left: int
    width: int
    ports: tuple[tuple[int, int], ...]  # physical belt identity -> dedicated column


@dataclass(frozen=True)
class TrunkTrack:
    demand: int
    left: int
    right: int
    row: int
    level: int
    source_column: int
    sink_column: int


@dataclass(frozen=True)
class ChannelPlan:
    origins: tuple[tuple[int, int], ...]  # module, not machine, origins
    banks: tuple[tuple[int, ...], ...]
    bays: tuple[AccessBay, ...]
    tracks: tuple[TrunkTrack, ...]
    machine_height: int
    track_rows: int
    width: int
    height: int
    levels: int
    fits_band: bool
    iterations: int


class Captured(Exception):
    def __init__(self, inventory: Inventory) -> None:
        super().__init__("captured pre-admission inventory")
        self.inventory = inventory


def capture_inventory(
    spec: BuildSpec, rules: catalog.BeltAltitudeRules, deadline: float
) -> Inventory:
    strips = freeform.plan_strips(spec, strip_len=48, band_policy=POLICY)
    sprayed = bool(spec.spray_lanes)
    modules = tuple(
        plan_module(strip)
        if sprayed
        else ModulePlan(
            (strip.west_channel, TURN), freeform._box(strip)[0], freeform._box(strip)[1] + TURN, ()
        )
        for strip in strips
    )
    bases = {i: (1000 * i, 0) for i in range(len(strips))}
    at = {i: (bases[i][0] + module.origin[0], module.origin[1]) for i, module in enumerate(modules)}
    sites = {
        (bases[i][0] + site.head[0], site.head[1]): (bases[i][0] + site.node[0], site.node[1])
        for i, module in enumerate(modules)
        for site in module.service_sites
    }
    shared: tuple[tuple[str, rd.CargoDomain, tuple[rd._Port, ...]], ...] = ()
    original_shared = rd._plan_shared_external_inputs
    original_inventory = rd._port_access_inventory
    original_site = rd._coater_node_site

    def fixed_site(
        canvas: rd._Canvas, near: tuple[int, int], *, radius: int = 48
    ) -> tuple[int, int] | None:
        site = sites[near]
        return site if rd._coater_node_site_is_clear(canvas, *site) else None

    def capture_shared(
        candidate: BuildSpec,
        physical_strips: Sequence[rd.Strip],
        ports: Sequence[Mapping[str, rd._Port]],
        rates: Mapping[str, tuple[Mapping[str, Fraction], Mapping[str, Fraction]]],
    ) -> tuple[
        dict[int, tuple[rd._Port, int]],
        dict[int, str],
        tuple[tuple[str, rd.CargoDomain, tuple[rd._Port, ...]], ...],
    ]:
        nonlocal shared
        result = original_shared(candidate, physical_strips, ports, rates)
        shared = result[2]
        return result

    def capture(
        nets: Sequence[rd._Net],
        *,
        boundary_inputs: Sequence[tuple[str, rd._Port, int | None]] = (),
        boundary_outputs: Sequence[tuple[str, rd._Port]] = (),
        late_output_belts: Collection[int] = (),
        shared_boundary_root_belts: Collection[int] = (),
        strip_of_belt: Mapping[int, int] = MappingProxyType({}),
    ) -> rd.PortAccessInventory:
        def endpoint(port: rd._Port | None) -> Endpoint | None:
            if port is None:
                return None
            owner = strip_of_belt[port.belt]
            return Endpoint(owner, port.belt, port.x - bases[owner][0], port.y, port.z)

        demands: list[TransportDemand] = []

        def add(
            item: str, domain: str, source: Endpoint | None, sink: Endpoint | None, role: str
        ) -> None:
            demands.append(TransportDemand(len(demands), item, domain, source, sink, role))

        for net in nets:
            if not net.prelinked:
                source, sink = endpoint(net.src), endpoint(net.dst)
                role = (
                    "local"
                    if source is not None and sink is not None and source.strip == sink.strip
                    else "internal"
                )
                add(net.item, net.cargo_domain.value, source, sink, role)
        for item, port, _ in boundary_inputs:
            add(item, port.cargo_domain.value, None, endpoint(port), "external")
        for item, port in boundary_outputs:
            add(item, port.cargo_domain.value, endpoint(port), None, "output")
        # Members are already present in boundary_inputs at this capture seam.
        # Keep their existing capacity grouping, do not count them twice.
        node_outputs = {
            (d.source.strip, d.source.x, d.source.y)
            for d in demands
            if d.role == "local" and d.source is not None
        }
        for index, module in enumerate(modules):
            for ordinal, site in enumerate(module.service_sites):
                if (
                    index,
                    site.node[0] + rd._COATER_NODE_TILES - 1,
                    site.node[1],
                ) not in node_outputs:
                    continue
                sink = Endpoint(
                    index, -1 - index * 100 - ordinal, site.node[0] + 1, site.node[1] - 1, 1
                )
                add("proliferator-service", "unsprayed", None, sink, "coater-service")
        raise Captured(
            Inventory(
                tuple(strips),
                modules,
                tuple(demands),
                len(shared),
                sum(net.prelinked for net in nets),
                tuple(
                    (item, domain.value, tuple(port.belt for port in ports))
                    for item, domain, ports in shared
                ),
            )
        )

    rd._plan_shared_external_inputs = capture_shared
    rd._port_access_inventory = capture
    rd._coater_node_site = fixed_site
    try:
        rd._prepare_routing_problem(
            spec,
            strips,
            rd._Pack(at, 1000 * len(strips), 50, "inventory-only"),
            power=False,
            policy=POLICY,
            belt_rules=rules,
            deadline=deadline,
            cancelled=lambda: time.monotonic() >= deadline,
        )
    except Captured as captured:
        return captured.inventory
    finally:
        rd._plan_shared_external_inputs = original_shared
        rd._port_access_inventory = original_inventory
        rd._coater_node_site = original_site
    raise AssertionError("inventory seam not reached")


def banks_for(modules: Sequence[ModulePlan], height: int) -> list[list[int]]:
    banks: list[list[int]] = []
    used: list[int] = []
    for index in sorted(range(len(modules)), key=lambda i: (-modules[i].width, i)):
        needed = modules[index].height + TURN
        available = [i for i in range(len(banks)) if used[i] + needed <= height]
        bank = (
            min(available, key=lambda i: (height - used[i] - needed, i))
            if available
            else len(banks)
        )
        if bank == len(banks):
            banks.append([])
            used.append(0)
        banks[bank].append(index)
        used[bank] += needed
    return banks


def channel_plan(inventory: Inventory, rules: catalog.BeltAltitudeRules) -> ChannelPlan:
    # Ground/service stay below the global buses. Integer levels 2..max are
    # available only with the original request's vertical-construction tech.
    if not rules.vertical_construction:
        raise ValueError("compact-riser topology requires vertical construction")
    levels = math.floor(rules.max_z) + 1
    trunk_levels = tuple(range(2, levels - 1, 2))
    if not trunk_levels:
        raise ValueError("no legal elevated trunk level")
    ceiling = max(height for height, _ in BAND_DIMENSIONS) - 2 * rd._ENTRY_RING
    machine_height = ceiling - TURN
    roles: dict[tuple[int, str], set[int]] = {}
    for demand in inventory.demands:
        if demand.role == "local":
            continue
        for side, endpoint in (("east", demand.source), ("west", demand.sink)):
            if endpoint is not None:
                roles.setdefault((endpoint.strip, side), set()).add(endpoint.belt)
    iteration = 0
    while True:
        iteration += 1
        banks = banks_for(inventory.modules, machine_height)
        origins = [(0, 0)] * len(inventory.modules)
        bays: list[AccessBay] = []
        columns: dict[tuple[int, str], int] = {}
        x = TURN
        for bank, members in enumerate(banks):
            west = sorted({belt for i in members for belt in roles.get((i, "west"), ())})
            east = sorted({belt for i in members for belt in roles.get((i, "east"), ())})
            west_width = 2 * TURN + PITCH * len(west)
            west_ports = tuple((belt, x + TURN + PITCH * rank) for rank, belt in enumerate(west))
            bays.append(AccessBay(bank, "west", x, west_width, west_ports))
            columns.update({(belt, "west"): column for belt, column in west_ports})
            content_x = x + west_width
            content_width = max(inventory.modules[i].width for i in members)
            y = 0
            for i in members:
                origins[i] = (content_x, y)
                y += inventory.modules[i].height + TURN
            east_start = content_x + content_width
            east_ports = tuple(
                (belt, east_start + TURN + PITCH * rank) for rank, belt in enumerate(east)
            )
            east_width = 2 * TURN + PITCH * len(east)
            bays.append(AccessBay(bank, "east", east_start, east_width, east_ports))
            columns.update({(belt, "east"): column for belt, column in east_ports})
            x = east_start + east_width
        intervals: list[tuple[int, int, int, int, int]] = []
        for demand in inventory.demands:
            if demand.role == "local":
                continue
            source_x = columns[demand.source.belt, "east"] if demand.source else TURN
            sink_x = columns[demand.sink.belt, "west"] if demand.sink else x
            intervals.append(
                (min(source_x, sink_x), max(source_x, sink_x), demand.ordinal, source_x, sink_x)
            )
        active: list[tuple[int, int]] = []
        free: list[int] = []
        track_count = 0
        tracks: list[TrunkTrack] = []
        for left, right, ordinal, source_x, sink_x in sorted(intervals):
            while active and active[0][0] + TURN < left:
                _, released = heapq.heappop(active)
                heapq.heappush(free, released)
            if free:
                track = heapq.heappop(free)
            else:
                track = track_count
                track_count += 1
            heapq.heappush(active, (right, track))
            tracks.append(
                TrunkTrack(
                    ordinal,
                    left,
                    right,
                    machine_height + TURN + PITCH * (track // len(trunk_levels)),
                    trunk_levels[track % len(trunk_levels)],
                    source_x,
                    sink_x,
                )
            )
        rows = PITCH * math.ceil(track_count / len(trunk_levels))
        width, height = x + TURN, machine_height + TURN + rows
        fits = bool(
            finalize.band_policy_search_envelope(POLICY, perimeter=rd._ENTRY_RING).frame_candidates(
                width, height
            )
        )
        next_height = ceiling - TURN - rows
        minimum = max(module.height + TURN for module in inventory.modules)
        if fits or next_height >= machine_height or next_height < minimum:
            plan = ChannelPlan(
                tuple(origins),
                tuple(map(tuple, banks)),
                tuple(bays),
                tuple(tracks),
                machine_height,
                rows,
                width,
                height,
                levels,
                fits,
                iteration,
            )
            verify_plan(inventory, plan)
            return plan
        machine_height = next_height


def verify_plan(inventory: Inventory, plan: ChannelPlan) -> None:
    assert {track.demand for track in plan.tracks} == {
        d.ordinal for d in inventory.demands if d.role != "local"
    }
    assert sorted(i for bank in plan.banks for i in bank) == list(range(len(inventory.modules)))
    by_track: dict[tuple[int, int], list[TrunkTrack]] = {}
    for track in plan.tracks:
        assert 0 <= track.left <= track.right < plan.width
        assert 0 <= track.row < plan.height and 2 <= track.level < plan.levels
        by_track.setdefault((track.row, track.level), []).append(track)
    for tracks in by_track.values():
        ordered = sorted(tracks, key=lambda track: track.left)
        assert all(a.right + TURN < b.left for a, b in zip(ordered, ordered[1:], strict=False))
    for bank in plan.banks:
        assert sum(inventory.modules[i].height + TURN for i in bank) <= plan.machine_height
    for bay in plan.bays:
        assert all(b - a >= PITCH for (_, a), (_, b) in zip(bay.ports, bay.ports[1:], strict=False))


def summary(inventory: Inventory, plan: ChannelPlan) -> dict[str, object]:
    return {
        "strips": len(inventory.strips),
        "demands": len(inventory.demands),
        "roles": dict(Counter(d.role for d in inventory.demands)),
        "shared_roots": inventory.shared_roots,
        "prelinked": inventory.prelinked,
        "shared_groups": inventory.shared_groups,
        "module_area": sum(m.width * m.height for m in inventory.modules),
        "banks": len(plan.banks),
        "access_columns": sum(b.width for b in plan.bays),
        "trunk_rows": plan.track_rows,
        "levels": plan.levels,
        "frame": (plan.width, plan.height),
        "area": plan.width * plan.height,
        "fits_band": plan.fits_band,
        "plan": asdict(plan),
        "demands_detail": [asdict(d) for d in inventory.demands],
    }


def world_endpoint(endpoint: Endpoint, plan: ChannelPlan) -> Cell:
    x, y = plan.origins[endpoint.strip]
    return x + endpoint.x, y + endpoint.y, endpoint.z
