"""Physical integration gate for the fixed channel plan, without global fallback."""

from __future__ import annotations

import json
import time
from collections.abc import Collection, Mapping
from dataclasses import asdict
from pathlib import Path
from unittest.mock import patch

from flab2bp import pipeline
from flab2bp.dsp import catalog, codec
from flab2bp.layout import finalize, freeform, markers, validate
from flab2bp.layout import routing_domain as rd
from flab2bp.layout.route_feedback import Cell
from flab2bp.spec import BuildSpec

from .transport_first import POLICY, ChannelPlan, Inventory, TransportDemand, world_endpoint


class GraphRefusal(RuntimeError):
    pass


class ChannelGraph:
    def __init__(self, inventory: Inventory, plan: ChannelPlan) -> None:
        self.inventory = inventory
        self.plan = plan
        self.tracks = {track.demand: track for track in plan.tracks}
        self.keys = {
            d.ordinal: frozenset(
                world_endpoint(e, plan) for e in (d.source, d.sink) if e is not None
            )
            for d in inventory.demands
        }
        self.allowed: dict[int, frozenset[Cell]] = {}
        self.current: frozenset[Cell] | None = None
        self.boundary_demand: TransportDemand | None = None
        self.queries = 0
        self.paths = 0
        self.path_cells = 0
        self.unmapped: list[dict[str, object]] = []
        self.original_astar = rd._astar
        self.original_flags = rd._routing_flags

    def cells(self, demand: TransportDemand) -> frozenset[Cell]:
        cached = self.allowed.get(demand.ordinal)
        if cached is not None:
            return cached
        plan = self.plan
        cells: set[Cell] = set()
        track = self.tracks.get(demand.ordinal)
        for source, endpoint in ((True, demand.source), (False, demand.sink)):
            if endpoint is None:
                if track is not None:
                    edge = 0 if source else plan.width - 1
                    column = track.source_column if source else track.sink_column
                    for x in range(
                        min(edge - rd._ENTRY_RING, column), max(edge + rd._ENTRY_RING, column) + 1
                    ):
                        for y in range(-rd._ENTRY_RING, plan.height + rd._ENTRY_RING):
                            for z in range(plan.levels):
                                cells.add((x, y, z))
                continue
            ox, oy = plan.origins[endpoint.strip]
            module = self.inventory.modules[endpoint.strip]
            for x in range(ox - 1, ox + module.width + 1):
                for y in range(oy - 1, oy + module.height + 1):
                    for z in range(plan.levels):
                        cells.add((x, y, z))
            if track is None:
                continue
            px, py, _ = world_endpoint(endpoint, plan)
            column = track.source_column if source else track.sink_column
            # Orthogonal planes: horizontal buses even, access legs odd.
            # Local egress uses the otherwise unassigned top plane.
            for x in range(min(px, column), max(px, column) + 1):
                cells.add((x, py, plan.levels - 1))
            for z in range(track.level + 1, plan.levels):
                cells.add((column, py, z))
            for y in range(min(py, track.row), max(py, track.row) + 1):
                cells.add((column, y, track.level + 1))
            cells.add((column, track.row, track.level))
        if track is not None:
            for x in range(track.left, track.right + 1):
                cells.add((x, track.row, track.level))
        result = frozenset(cells)
        self.allowed[demand.ordinal] = result
        return result

    def boundary_search(
        self, canvas: rd._Canvas, port: rd._Port, bounds: tuple[int, int, int, int]
    ) -> None:
        key = frozenset({(port.x, port.y, port.z)})
        candidates = [
            d
            for d in self.inventory.demands
            if self.keys[d.ordinal] == key and (d.source is None or d.sink is None)
        ]
        if len(candidates) != 1:
            raise GraphRefusal("boundary terminal has no unique preallocated demand")
        self.boundary_demand = candidates[0]
        # Force the existing boundary router through the constrained query.
        # Its straight-line shortcut otherwise bypasses every graph mask.
        return None

    def identify(self, canvas: rd._Canvas, starts: list[Cell], goals: set[Cell]) -> TransportDemand:
        ports = canvas.routing_ports
        candidates = [d for d in self.inventory.demands if self.keys[d.ordinal] == ports]
        if len(candidates) == 1:
            return candidates[0]
        if not ports and self.boundary_demand is not None:
            demand = self.boundary_demand
            self.boundary_demand = None
            return demand
        self.unmapped.append(
            {
                "ports": sorted(ports),
                "starts": starts[:8],
                "goals": sorted(goals)[:8],
                "candidates": [d.ordinal for d in candidates],
            }
        )
        raise GraphRefusal("physical endpoint query has no unique preallocated demand")

    def flags(
        self,
        grid: rd._Grid,
        *,
        routing_ports: Collection[Cell] = (),
        released_reservations: Collection[int] = (),
    ) -> bytearray:
        original = self.original_flags(
            grid, routing_ports=routing_ports, released_reservations=released_reservations
        )
        if self.current is None:
            raise GraphRefusal("routing flags requested without an allocated channel")
        restricted = bytearray(grid.size)
        x0, y0, x1, y1 = grid.span
        for x, y, z in self.current:
            if x0 <= x <= x1 and y0 <= y <= y1 and 0 <= z < grid.levels:
                index = (x - grid.gx0) * grid.xstep + (y - grid.gy0) * grid.levels + z
                restricted[index] = original[index]
        return restricted

    def astar(
        self,
        canvas: rd._Canvas,
        starts: list[Cell],
        goals: set[Cell],
        history: dict[Cell, float],
        pressure: float,
        bounds: tuple[int, int, int, int],
        budget: dict[str, int] | None = None,
        deadline: float | None = None,
        blame: dict[Cell, float] | None = None,
        grid: rd._Grid | None = None,
        owned_starts: Collection[Cell] = (),
        released_starts: Collection[Cell] = (),
        forbidden: Collection[Cell] = (),
        blocking_owners: Mapping[Cell, int] | None = None,
        *,
        extra_edges: dict[int, tuple[tuple[int, float], ...]] | None = None,
    ) -> rd._PathSearchResult:
        demand = self.identify(canvas, starts, goals)
        allowed = self.cells(demand)
        self.queries += 1
        previous = self.current
        self.current = allowed
        try:
            # Connector shortcuts are disabled: endpoint-only edges cannot prove
            # that their intermediate physical witness stays on this graph.
            result = self.original_astar(
                canvas,
                [s for s in starts if s in allowed],
                goals & allowed,
                history,
                pressure,
                bounds,
                budget,
                deadline,
                blame,
                grid,
                owned_starts,
                released_starts,
                forbidden,
                blocking_owners,
                extra_edges=None,
            )
            if result.path is not None:
                assert set(result.path) <= allowed
                self.paths += 1
                self.path_cells += len(result.path)
            return result
        finally:
            self.current = previous


def exercise(
    spec: BuildSpec,
    rules: catalog.BeltAltitudeRules,
    inventory: Inventory,
    plan: ChannelPlan,
    started: float,
    budget_s: float,
    output: Path,
) -> dict[str, object]:
    graph = ChannelGraph(inventory, plan)
    result: dict[str, object] = {"original_factory_gate": False}
    at = {
        i: (base[0] + inventory.modules[i].origin[0], base[1] + inventory.modules[i].origin[1])
        for i, base in enumerate(plan.origins)
    }
    sites = {
        (base[0] + site.head[0], base[1] + site.head[1]): (
            base[0] + site.node[0],
            base[1] + site.node[1],
        )
        for i, base in enumerate(plan.origins)
        for site in inventory.modules[i].service_sites
    }
    original_core = rd._core_bounds

    def fixed_core(canvas: rd._Canvas) -> tuple[int, int, int, int]:
        x0, y0, x1, y1 = original_core(canvas)
        return min(0, x0), min(0, y0), max(plan.width - 1, x1), max(plan.height - 1, y1)

    def fixed_site(
        canvas: rd._Canvas, near: tuple[int, int], *, radius: int = 48
    ) -> tuple[int, int] | None:
        site = sites[near]
        return site if rd._coater_node_site_is_clear(canvas, *site) else None

    def cancelled() -> bool:
        return time.monotonic() >= started + budget_s

    try:
        preparation_started = time.monotonic()
        with (
            patch.object(rd, "_core_bounds", fixed_core),
            patch.object(rd, "_coater_node_site", fixed_site),
        ):
            prepared = rd._prepare_routing_problem(
                spec,
                list(inventory.strips),
                rd._Pack(at, plan.width, plan.height, "transport-first"),
                power=True,
                policy=POLICY,
                belt_rules=rules,
                cancelled=cancelled,
                deadline=started + budget_s - 5,
            )
        preparation_s = time.monotonic() - preparation_started
        with (
            patch.object(rd, "_astar", graph.astar),
            patch.object(rd, "_routing_flags", graph.flags),
            patch.object(rd, "_straight_to_edge", graph.boundary_search),
        ):
            built = freeform._build_prepared(
                spec,
                list(inventory.strips),
                prepared,
                power=True,
                route=True,
                deadline=started + budget_s - 5,
                budget={"left": int(budget_s * freeform._ROUTING_EXPANSIONS_PER_SECOND)},
            )
        result.update(
            {
                "preparation_s": preparation_s,
                "routing_s": built.detailed_route_time_s,
                "routing_failures": [asdict(f) for f in built.routing.failures],
                "routed": len(built.routing.routed),
                "expansions": built.routing.expansions,
            }
        )
        if built.placement is None or built.routing.failed_count:
            result["outcome"] = "allocated-channel-routing-refused"
            return result
        placement = finalize.compact_open_boundary_belts(
            built.placement, spec, expect_power=True, belt_rules=rules
        )
        placement = finalize.finalize_placement(placement, POLICY, cancelled=cancelled)
        report = validate.judge_placement(
            placement, spec, ids=pipeline._id_map(spec), expect_power=True, belt_rules=rules
        )
        output.with_suffix(".report.json").write_text(
            json.dumps(asdict(report), indent=2, default=str)
        )
        result.update(
            {
                "checks_run": len(report.checks_run),
                "errors": len(report.errors),
                "skipped": report.skipped,
                "area": placement.area,
            }
        )
        if report.errors or report.skipped or set(report.checks_run) != set(validate.CHECKS):
            result["outcome"] = "original-spec-validation-refused"
            return result
        blueprint = codec.encode(markers.mark_external_belts(placement, spec))
        decoded = codec.decode(blueprint)
        assert len(decoded.buildings) == len(placement.buildings)
        output.with_suffix(".blueprint.txt").write_text(blueprint)
        result.update(
            {
                "outcome": "clean" if not cancelled() else "settlement-budget-refused",
                "original_factory_gate": not cancelled(),
                "buildings": len(decoded.buildings),
            }
        )
    except (
        GraphRefusal,
        rd._Unseatable,
        rd._PreparationDeadline,
        finalize.ProjectionRefusal,
        finalize.ProjectionCancelled,
    ) as failure:
        result.update({"outcome": "allocated-channel-integration-refused", "reason": str(failure)})
    finally:
        result.update(
            {
                "constrained_queries": graph.queries,
                "constrained_paths": graph.paths,
                "constrained_path_cells": graph.path_cells,
                "unmapped_queries": graph.unmapped,
                "settlement": "reached" if "checks_run" in result else "not reached",
                "elapsed_s": time.monotonic() - started,
            }
        )
    return result
