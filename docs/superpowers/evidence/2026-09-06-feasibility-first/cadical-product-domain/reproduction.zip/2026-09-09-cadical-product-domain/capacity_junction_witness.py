"""Experiment-only high-degree physical interfaces; not factory acceptance."""

from __future__ import annotations

import json
from dataclasses import asdict
from fractions import Fraction
from pathlib import Path
from unittest.mock import patch

from flab2bp.layout import routing_domain as rd
from flab2bp.spec import BuildSpec

from .channel_mechanics import CHECKS, report
from .flight_reuse import ReusingConstructor
from .junction_tree import terminals

ROOT = Path(__file__).resolve().parent


def run() -> None:
    spec = BuildSpec.model_validate_json((ROOT / "frozen/three-output.json").read_text())
    output = ROOT / "capacity-junction-witness"
    output.mkdir(exist_ok=True)
    summaries = []
    for branches in (1, 2, 3, 4, 5, 15):
        for feed in (False, True):
            constructor = ReusingConstructor(spec, rd._DEFAULT_BELT_RULES)
            node = constructor.splitter(10, 10, "iron-ingot")
            trunk = constructor.dock(node, (1, 0) if feed else (-1, 0), feed=not feed)
            rates = [Fraction(i + 1, branches * branches) for i in range(branches)]
            leaves = terminals(constructor, node, rates, feed=feed)
            for terminal, rate, incoming in [
                (trunk, sum(rates, Fraction()), not feed),
                *[(leaf, rate, feed) for leaf, rate in zip(leaves, rates, strict=True)],
            ]:
                p = terminal.port
                dx, dy = terminal.outward
                external = constructor.belt((p.x + 3 * dx, p.y + 3 * dy, 0), "iron-ingot")
                source, sink = (external, p) if incoming else (p, external)
                constructor.connect(
                    source,
                    sink,
                    [(source.x, source.y, 0), (sink.x, sink.y, 0)],
                    "iron-ingot",
                    rate,
                    "witness-boundary",
                )
            # Independently balance every emitted junction using link endpoints.
            for index in constructor.junctions:
                junction = constructor.canvas.buildings[index]
                entering = leaving = Fraction()
                for link in constructor.links:
                    source = constructor.canvas.buildings[link.source]
                    sink = constructor.canvas.buildings[link.sink]
                    if (source.x, source.y, source.z) == (junction.x, junction.y, junction.z):
                        leaving += link.rate
                    if (sink.x, sink.y, sink.z) == (junction.x, junction.y, junction.z):
                        entering += link.rate
                assert entering == leaving and entering > 0
                assert entering <= spec.lane_capacity
            name = f"{'merge' if feed else 'split'}-{branches}"
            result = report(constructor.canvas, name)
            assert not result["errors"] and not result["skipped"]
            assert result["checks"] in (CHECKS, list(CHECKS))
            result["junctions"] = len(constructor.junctions)
            result["rated_leaves"] = [str(rate) for rate in rates]
            result["junction_rate_conservation"] = True
            (output / f"{name}.json").write_text(json.dumps(result, indent=2, default=str))
            (output / f"{name}-links.json").write_text(
                json.dumps([asdict(link) for link in constructor.links], indent=2, default=str)
            )
            summaries.append({k: v for k, v in result.items() if k != "findings"})
    (output / "summary.json").write_text(json.dumps(summaries, indent=2, default=str))
    print(json.dumps(summaries, default=str))


if __name__ == "__main__":
    with patch.object(
        rd, "_route_all", side_effect=AssertionError("global router is forbidden")
    ) as router:
        run()
        assert router.call_count == 0
