"""Run one original gate with a hard deadline covering native CaDiCaL calls."""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time
from pathlib import Path

from pydantic import BaseModel


class Command(BaseModel):
    case: str
    deps: Path


class Progress(BaseModel):
    case: str
    started_monotonic: float
    deadline: float
    budget_s: float
    outcome: str


def progress(path: Path) -> Progress | None:
    try:
        content = path.read_text()
        json.loads(content)
    except FileNotFoundError, json.JSONDecodeError:
        return None
    return Progress.model_validate_json(content)


def main() -> None:
    parser = argparse.ArgumentParser()
    _ = parser.add_argument("case")
    _ = parser.add_argument("--deps", type=Path, required=True)
    args = Command.model_validate(vars(parser.parse_args()))
    root = Path(__file__).resolve().parent
    output = root / "template-cases" / args.case
    output.mkdir(parents=True, exist_ok=True)
    if (output / "result.json").exists() or (output / "progress.json").exists():
        raise RuntimeError("A gate record already exists; refusing an implicit rerun")
    environment = dict(os.environ)
    environment["PYTHONPATH"] = os.pathsep.join((str(root.parent), str(args.deps.resolve())))
    command = [sys.executable, "-m", f"{root.name}.template_experiment", "run", args.case]
    started = time.monotonic()
    deadline = started + 30
    state = None
    killed = False
    with (output / "stdout.txt").open("w") as stdout, (output / "stderr.txt").open("w") as stderr:
        child = subprocess.Popen(command, env=environment, stdout=stdout, stderr=stderr)
        while child.poll() is None:
            state = progress(output / "progress.json") or state
            if state is not None:
                deadline = state.deadline
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                killed = True
                child.terminate()
                try:
                    _ = child.wait(timeout=0.2)
                except subprocess.TimeoutExpired:
                    child.kill()
                break
            time.sleep(min(0.02, remaining))
        code = child.wait()
    summary = {
        "command": command,
        "exit": code,
        "hard_deadline_terminated": killed,
        "bootstrap_inclusive_seconds": time.monotonic() - started,
        "original_budget_s": state.budget_s if state is not None else None,
        "progress": state.model_dump() if state is not None else None,
        "final_report_written": (output / "result.json").exists(),
    }
    if killed or not summary["final_report_written"]:
        summary["outcome"] = "UNKNOWN"
        summary["reason"] = "hard deadline or missing final report; not infeasibility or acceptance"
    (output / "supervisor.json").write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary))


if __name__ == "__main__":
    main()
