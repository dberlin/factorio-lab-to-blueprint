"""Shared finite-work accounting for the complete-path experiment."""

from __future__ import annotations

import time
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Literal

WorkKind = Literal[
    "arcs", "augmentations", "candidates", "audit_cells", "predicates", "assignments"
]


class ExperimentRefusal(RuntimeError):
    def __init__(self, reason: str, detail: str) -> None:
        super().__init__(detail)
        self.reason = reason
        self.detail = detail


@dataclass(frozen=True)
class WorkLimits:
    arcs: int = 100_000
    augmentations: int = 100_000
    candidates: int = 2_000_000
    audit_cells: int = 5_000_000
    predicates: int = 5_000_000
    assignments: int = 100_000


@dataclass
class WorkBudget:
    deadline: float
    limits: WorkLimits = field(default_factory=WorkLimits)
    clock: Callable[[], float] = time.monotonic
    counts: dict[WorkKind, int] = field(default_factory=dict)

    def check(self) -> None:
        if self.clock() >= self.deadline:
            raise ExperimentRefusal("DEADLINE", "original absolute experiment deadline reached")

    def charge(self, kind: WorkKind, amount: int = 1) -> None:
        if amount < 0:
            raise ValueError("work charge must be nonnegative")
        self.check()
        current = self.counts.get(kind, 0)
        if current + amount > getattr(self.limits, kind):
            raise ExperimentRefusal("POLICY_BOUND", f"{kind} work limit reached at {current}")
        self.counts[kind] = current + amount
