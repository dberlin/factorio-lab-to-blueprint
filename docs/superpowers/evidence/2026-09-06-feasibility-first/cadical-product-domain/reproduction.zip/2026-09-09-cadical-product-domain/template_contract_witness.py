"""Executable experiment contracts, not production tests or factory acceptance."""

from __future__ import annotations

import json
import time
from dataclasses import replace
from fractions import Fraction
from pathlib import Path

from pydantic import TypeAdapter

from flab2bp.lab.data import load_vendored
from flab2bp.lab.flow import canonicalize_dataset
from flab2bp.lab.techs import belt_rules_for_url
from flab2bp.spec import BuildSpec

from .run_experiment import Case
from .template_budget import ExperimentRefusal, WorkBudget, WorkKind, WorkLimits
from .template_flow import ORDERS, allocate, select_topology
from .transport_first import capture_inventory

ROOT = Path(__file__).resolve().parent


def budget_witness() -> dict[str, object]:
    clock = [0.0]
    work = WorkBudget(1.0, WorkLimits(1, 1, 1, 1, 1, 1), clock=lambda: clock[0])
    kinds: tuple[WorkKind, ...] = (
        "arcs",
        "augmentations",
        "candidates",
        "audit_cells",
        "predicates",
        "assignments",
    )
    for kind in kinds:
        work.charge(kind)
        try:
            work.charge(kind)
        except ExperimentRefusal as refusal:
            assert refusal.reason == "POLICY_BOUND"
            assert work.counts[kind] == 1
        else:
            raise AssertionError(f"uncapped {kind}")
    clock[0] = 1.0
    try:
        work.check()
    except ExperimentRefusal as refusal:
        assert refusal.reason == "DEADLINE"
    else:
        raise AssertionError("deadline was not checked")
    return {"caps_exercised": list(kinds), "before_exceeding": True, "exact_deadline": True}


def flow_witness() -> list[dict[str, object]]:
    results: list[dict[str, object]] = []
    cases = TypeAdapter(list[Case]).validate_json((ROOT / "frozen/manifest.json").read_text())
    data = canonicalize_dataset(load_vendored())
    for case in cases:
        if case.name not in {"three-output", "unsprayed-mall"}:
            continue
        spec = BuildSpec.model_validate_json((ROOT / "frozen" / f"{case.name}.json").read_text())
        rules = belt_rules_for_url(case.url, data)
        inventory = capture_inventory(spec, rules, time.monotonic() + case.budget_s)
        shared = WorkBudget(time.monotonic() + case.budget_s)
        selections = [select_topology(spec, inventory, order, shared) for order in ORDERS]
        repeated = select_topology(
            spec, inventory, "captured", WorkBudget(time.monotonic() + case.budget_s)
        )
        assert selections[0].inventory.demands == repeated.inventory.demands
        assert selections[0].rates == repeated.rates
        results.append(
            {
                "case": case.name,
                "orders": list(ORDERS),
                "positive_arcs": [len(s.rates) for s in selections],
                "exact_ledgers": True,
                "deterministic": True,
                "shared_work": dict(shared.counts),
            }
        )
        if case.name == "unsprayed-mall":
            try:
                allocate(spec, inventory, WorkBudget(time.monotonic() + case.budget_s))
            except ExperimentRefusal as refusal:
                assert refusal.reason == "CAPACITY_CUT"
                cut = json.loads(refusal.detail)
                capacity = sum((Fraction(edge[2]) for edge in cut["cut"]), Fraction())
                assert capacity == Fraction(cut["delivered"]) < Fraction(cut["required"])
                results[-1]["captured_capacity_cut_verified"] = True
            else:
                raise AssertionError("known captured capacity deficit disappeared")
        # Deliberately reduce one real producer resource without changing demand.
        producer = next(i for i, strip in enumerate(inventory.strips) if strip.machines > 1)
        strip = inventory.strips[producer]
        # The exact allocator must not certify a fabricated machine count mismatch.
        changed = replace(strip, machines=strip.machines - 1)
        damaged = replace(
            inventory,
            strips=tuple(
                changed if i == producer else value for i, value in enumerate(inventory.strips)
            ),
        )
        try:
            allocate(spec, damaged, WorkBudget(time.monotonic() + case.budget_s))
        except AssertionError, ExperimentRefusal:
            results[-1]["changed_machine_contract_rejected"] = True
        else:
            raise AssertionError("changed physical machine resource silently accepted")
    return results


def run() -> None:
    result = {"budget": budget_witness(), "flow": flow_witness(), "original_factory_gate": False}
    (ROOT / "template-contract-witness.json").write_text(json.dumps(result, indent=2, default=str))
    print(json.dumps(result, default=str))


if __name__ == "__main__":
    run()
