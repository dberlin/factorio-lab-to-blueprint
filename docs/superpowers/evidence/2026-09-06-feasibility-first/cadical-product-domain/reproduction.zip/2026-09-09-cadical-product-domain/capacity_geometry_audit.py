"""Independent segment occupancy and fixed-path impossibility certificates."""

from __future__ import annotations

import json
from pathlib import Path

from pydantic import BaseModel, TypeAdapter

Cell = tuple[int, int, int]
ROOT = Path(__file__).resolve().parent


class Link(BaseModel):
    source: int
    sink: int
    cells: tuple[Cell, ...]


class Flight(BaseModel):
    id: int
    item: str
    role: str
    points_at_level_3: tuple[Cell, ...]


class Result(BaseModel):
    case: str
    original_factory_gate: bool
    junction_cells: tuple[Cell, ...]
    reason: str = ""


def expand(points: tuple[Cell, ...]) -> set[Cell]:
    result = {points[0]}
    for start, end in zip(points, points[1:], strict=False):
        axes = [axis for axis in range(3) if start[axis] != end[axis]]
        assert len(axes) <= 1
        if axes:
            axis = axes[0]
            for value in range(min(start[axis], end[axis]), max(start[axis], end[axis]) + 1):
                cell = list(start)
                cell[axis] = value
                result.add((cell[0], cell[1], cell[2]))
    return result


def cycle(edges: dict[int, set[int]]) -> list[int]:
    active: list[int] = []
    done: set[int] = set()

    def visit(node: int) -> list[int]:
        if node in active:
            return active[active.index(node) :] + [node]
        if node in done:
            return []
        active.append(node)
        for child in sorted(edges[node]):
            found = visit(child)
            if found:
                return found
        active.pop()
        done.add(node)
        return []

    for node in edges:
        found = visit(node)
        if found:
            return found
    return []


def run() -> None:
    summaries: list[dict[str, object]] = []
    for path in sorted((ROOT / "capacity-first-cases").iterdir()):
        result = Result.model_validate_json((path / "result.json").read_text())
        links = TypeAdapter(list[Link]).validate_json((path / "links.json").read_text())
        cells = [expand(link.cells) for link in links]
        intersections = []
        for i, first in enumerate(links):
            first_ends = {first.cells[0]: first.source, first.cells[-1]: first.sink}
            for j in range(i + 1, len(links)):
                second = links[j]
                second_ends = {second.cells[0]: second.source, second.cells[-1]: second.sink}
                common = cells[i] & cells[j]
                for cell in first_ends.keys() & second_ends.keys():
                    if first_ends[cell] == second_ends[cell] or cell in result.junction_cells:
                        common.discard(cell)
                if common:
                    intersections.append({"links": [i, j], "cells": sorted(common)})
        assert not intersections, (result.case, intersections)
        summary: dict[str, object] = {
            "case": result.case,
            "original_factory_gate": result.original_factory_gate,
            "audited_links": len(links),
            "full_segment_intersections": intersections,
            "partial_geometry_only": not result.original_factory_gate,
        }
        flights = TypeAdapter(list[Flight]).validate_json((path / "flights.json").read_text())
        flights = [flight for flight in flights if flight.role != "local-source"]
        planes = {f.id: {cell[:2] for cell in expand(f.points_at_level_3[2:6])} for f in flights}
        columns = {f.id: {f.points_at_level_3[2][:2], f.points_at_level_3[5][:2]} for f in flights}
        dependencies = {
            f.id: {
                other.id
                for other in flights
                if f.id != other.id and planes[f.id] & columns[other.id]
            }
            for f in flights
        }
        witness = cycle(dependencies)
        if "cyclic" in result.reason:
            assert witness
            by_id = {flight.id: flight for flight in flights}
            summary["impossible_height_cycle"] = [
                {
                    "higher": higher,
                    "higher_item": by_id[higher].item,
                    "lower": lower,
                    "lower_item": by_id[lower].item,
                    "plane_crosses_ground_riser_at": sorted(planes[higher] & columns[lower]),
                }
                for higher, lower in zip(witness, witness[1:], strict=False)
            ]
        elif result.original_factory_gate:
            assert not witness
        (path / "independent-audit.json").write_text(json.dumps(summary, indent=2))
        summaries.append(summary)
    (ROOT / "capacity-independent-audit.json").write_text(json.dumps(summaries, indent=2))
    print(json.dumps(summaries))


if __name__ == "__main__":
    run()
