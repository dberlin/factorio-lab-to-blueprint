"""Throwaway exact transport selection; original production/boundaries stay fixed."""

from __future__ import annotations

from collections import defaultdict
from collections.abc import Callable
from dataclasses import dataclass, replace
from fractions import Fraction

from flab2bp.layout import routing_domain as rd
from flab2bp.spec import BuildSpec

from .constructive_composition import ConstructionRefusal
from .transport_first import Endpoint, Inventory, TransportDemand


@dataclass(frozen=True)
class SelectedTopology:
    inventory: Inventory
    rates: dict[int, Fraction]
    candidates: int
    added: int
    removed: int


def select_topology(
    spec: BuildSpec,
    inventory: Inventory,
    allocate: Callable[[BuildSpec, Inventory], dict[int, Fraction]],
) -> SelectedTopology:
    if inventory.prelinked or any(d.domain != "unsprayed" for d in inventory.demands):
        raise ConstructionRefusal(
            "capacity-first probe requires uncoated, non-prelinked interfaces"
        )
    sources: dict[str, set[Endpoint]] = defaultdict(set)
    sinks: dict[str, set[Endpoint]] = defaultdict(set)
    candidates = list(inventory.demands)
    original = {(d.item, d.source, d.sink) for d in candidates}
    for demand in candidates:
        if demand.source is not None:
            sources[demand.item].add(demand.source)
        if demand.sink is not None:
            sinks[demand.item].add(demand.sink)
    # Preserve the old adjacency's preference, not its impossible capacity cuts.
    # Export and external-feed eligibility remain the captured boundary contract.
    for item in sorted(sources):
        for source in sorted(sources[item], key=lambda p: (p.strip, p.belt)):
            for sink in sorted(sinks[item], key=lambda p: (p.strip, p.belt)):
                if (item, source, sink) not in original and source.strip != sink.strip:
                    candidates.append(
                        TransportDemand(
                            len(candidates), item, "unsprayed", source, sink, "internal"
                        )
                    )
    candidate_inventory = replace(inventory, demands=tuple(candidates))
    allocated = allocate(spec, candidate_inventory)
    selected: list[TransportDemand] = []
    rates: dict[int, Fraction] = {}
    for demand in candidates:
        rate = allocated[demand.ordinal]
        if rate > 0:
            ordinal = len(selected)
            selected.append(replace(demand, ordinal=ordinal))
            rates[ordinal] = rate
    chosen = replace(inventory, demands=tuple(selected))
    verify_rates(spec, chosen, rates)
    selected_keys = {(d.item, d.source, d.sink) for d in selected}
    return SelectedTopology(
        chosen, rates, len(candidates), len(selected_keys - original), len(original - selected_keys)
    )


def verify_rates(spec: BuildSpec, inventory: Inventory, rates: dict[int, Fraction]) -> None:
    """Independent ledger: no residual-flow implementation is reused here."""
    supplied: dict[tuple[int, str], Fraction] = defaultdict(Fraction)
    consumed: dict[tuple[int, str], Fraction] = defaultdict(Fraction)
    imports: dict[str, Fraction] = defaultdict(Fraction)
    exports: dict[str, Fraction] = defaultdict(Fraction)
    out_lanes: dict[tuple[int, str], Fraction] = defaultdict(Fraction)
    in_lanes: dict[tuple[int, str], Fraction] = defaultdict(Fraction)
    for demand in inventory.demands:
        rate = rates[demand.ordinal]
        assert rate > 0
        if demand.source is None:
            imports[demand.item] += rate
        else:
            supplied[demand.source.strip, demand.item] += rate
            out_lanes[demand.source.belt, demand.item] += rate
        if demand.sink is None:
            exports[demand.item] += rate
        else:
            consumed[demand.sink.strip, demand.item] += rate
            in_lanes[demand.sink.belt, demand.item] += rate
    assert dict(imports) == dict(spec.external_inputs)
    expected_exports = {
        item: spec.outputs.get(item, Fraction()) + spec.surplus_outputs.get(item, Fraction())
        for item in set(spec.outputs) | set(spec.surplus_outputs)
    }
    assert dict(exports) == expected_exports
    adapted = rd._adapt(spec)
    for index, strip in enumerate(inventory.strips):
        group = adapted[strip.group_key]
        for item, rate in group.outputs.items():
            assert supplied[index, item] == rate * strip.machines
        for item, rate in group.inputs.items():
            assert consumed[index, item] == rate * strip.machines
    stacks = rd._lane_stacks_for(spec)
    for (_, item), rate in out_lanes.items():
        assert rate <= spec.lane_capacity * stacks.produced[item]
    for (_, item), rate in in_lanes.items():
        assert rate <= spec.lane_capacity * stacks.consumed[item]
