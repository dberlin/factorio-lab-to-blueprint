"""Admission, immutable policy and guarded execution for complete-path templates."""

from __future__ import annotations

import argparse
import hashlib
import json
import signal
import time
from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import asdict
from pathlib import Path
from types import FrameType
from typing import Literal
from unittest.mock import patch

from pydantic import BaseModel, TypeAdapter

from flab2bp.layout import routing_domain as rd

from .constructive_control import ROOT, run
from .run_experiment import Case
from .template_budget import ExperimentRefusal, WorkBudget, WorkLimits
from .template_flow import ORDERS
from .template_runtime import TemplateRun

OUTPUT = ROOT / "template-cases"
POLICY = ROOT / "template-policy.json"
SUPPORTED = (
    "three-output",
    "unsprayed-mall",
    "unsprayed-mall-075",
    "unsprayed-mall-125",
    "unsprayed-universe",
)
POLICY_RULES = {
    "adapters": ["straight-2", "straight-4", "straight-6", "out-2-side+2", "out-2-side-2"],
    "middle_tracks_per_axis": 4,
    "exterior_margin": 8,
    "minimum_global_level": 3,
    "strips_per_bank": 5,
    "topology_orders": list(ORDERS),
    "admission_samples": 1024,
    "dynamic_pruning": "exact-blocker-selection-lifetime",
    "limits": asdict(WorkLimits()),
}


class AdmissionEvidence(BaseModel):
    case: str
    spec_sha256: str
    budget_s: float
    elapsed_s: float
    outcome: str
    rule_sha256: str
    within_admission_budget: bool
    manifest_sha256: str
    source_sha256: dict[str, str]


class FrozenPolicy(BaseModel):
    rule_sha256: str
    spec_sha256: dict[str, str]
    admission_sha256: dict[str, str]
    manifest_sha256: str
    source_sha256: dict[str, str]


class Command(BaseModel):
    command: Literal["admit", "freeze", "run"]
    names: tuple[str, ...]
    mode: Literal["GEOMETRY_ONLY", "RATED_ACCEPTANCE"]


def rule_hash() -> str:
    return hashlib.sha256(json.dumps(POLICY_RULES, sort_keys=True).encode()).hexdigest()


def manifest_hash() -> str:
    return hashlib.sha256((ROOT / "frozen/manifest.json").read_bytes()).hexdigest()


def source_hashes() -> dict[str, str]:
    return {
        path.name: hashlib.sha256(path.read_bytes()).hexdigest()
        for path in sorted(Path(__file__).parent.glob("*.py"))
    }


def cases() -> list[Case]:
    return TypeAdapter(list[Case]).validate_json((ROOT / "frozen/manifest.json").read_text())


@contextmanager
def absolute_deadline(budget: WorkBudget) -> Iterator[None]:
    # Canonical settlement helpers do not all expose cooperative cancellation.
    # This standalone Linux CLI owns SIGALRM for the entire original budget.
    def expired(_signal: int, _frame: FrameType | None) -> None:
        raise ExperimentRefusal("DEADLINE", "absolute layout-through-settlement deadline reached")

    old = signal.getsignal(signal.SIGALRM)
    if signal.getitimer(signal.ITIMER_REAL)[0]:
        raise RuntimeError("another absolute timer already owns this process")
    signal.signal(signal.SIGALRM, expired)
    signal.setitimer(signal.ITIMER_REAL, max(0.000001, budget.deadline - time.monotonic()))
    try:
        yield
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        signal.signal(signal.SIGALRM, old)


def admission(name: str) -> dict[str, object]:
    case = next(c for c in cases() if c.name == name)
    started = time.monotonic()
    budget = WorkBudget(started + case.budget_s / 10)
    folder = OUTPUT / "admission" / name
    session = TemplateRun(budget, "captured", folder, admission=True)
    with absolute_deadline(budget):
        result = run(name, reuse=True, capacity_first=True, template=session)
    result["elapsed_s"] = time.monotonic() - started
    result["within_admission_budget"] = time.monotonic() <= budget.deadline
    result["policy_rules"] = POLICY_RULES
    result["rule_sha256"] = rule_hash()
    result["manifest_sha256"] = manifest_hash()
    result["source_sha256"] = source_hashes()
    (folder / "result.json").write_text(json.dumps(result, indent=2, default=str))
    return result


def freeze() -> FrozenPolicy:
    identities: dict[str, str] = {}
    admissions: dict[str, str] = {}
    for name in SUPPORTED:
        path = OUTPUT / "admission" / name / "result.json"
        evidence = AdmissionEvidence.model_validate_json(path.read_text())
        if evidence.outcome != "COST_ADMISSION_MEASURED" or not evidence.within_admission_budget:
            raise ExperimentRefusal("COST_ADMISSION_FAILED", f"{name}: {evidence.outcome}")
        if evidence.rule_sha256 != rule_hash():
            raise ExperimentRefusal("FROZEN_IDENTITY_MISMATCH", f"admission rules: {name}")
        if evidence.manifest_sha256 != manifest_hash() or evidence.source_sha256 != source_hashes():
            raise ExperimentRefusal("FROZEN_IDENTITY_MISMATCH", f"admission implementation: {name}")
        raw_spec = (ROOT / "frozen" / f"{name}.json").read_bytes()
        if hashlib.sha256(raw_spec).hexdigest() != evidence.spec_sha256:
            raise ExperimentRefusal("FROZEN_IDENTITY_MISMATCH", name)
        identities[name] = evidence.spec_sha256
        admissions[name] = hashlib.sha256(path.read_bytes()).hexdigest()
    frozen = FrozenPolicy(
        rule_sha256=rule_hash(),
        spec_sha256=identities,
        admission_sha256=admissions,
        manifest_sha256=manifest_hash(),
        source_sha256=source_hashes(),
    )
    if POLICY.exists():
        previous = FrozenPolicy.model_validate_json(POLICY.read_text())
        if previous != frozen:
            raise ExperimentRefusal(
                "POLICY_ALREADY_FROZEN", "existing policy/admission identity cannot be replaced"
            )
    else:
        POLICY.write_text(frozen.model_dump_json(indent=2))
    return frozen


def execute(name: str, mode: Literal["GEOMETRY_ONLY", "RATED_ACCEPTANCE"]) -> dict[str, object]:
    case = next(c for c in cases() if c.name == name)
    if name in SUPPORTED and name != "three-output":
        prerequisite = "unsprayed-mall" if case.held_out else "three-output"
        prerequisite_path = OUTPUT / prerequisite / "result.json"
        if not prerequisite_path.exists():
            raise ExperimentRefusal("PREREQUISITE_NOT_MET", prerequisite)
        prerequisite_result = json.loads(prerequisite_path.read_text())
        acceptable = (
            ("RATED_ORIGINAL_ACCEPTED",)
            if mode == "RATED_ACCEPTANCE"
            else ("VALIDATOR_COMPLETE_WITNESS", "RATED_ORIGINAL_ACCEPTED")
        )
        if prerequisite_result["outcome"] not in acceptable:
            raise ExperimentRefusal("PREREQUISITE_NOT_MET", prerequisite)
    # Unsupported interfaces are executable refusals, not a bypass into geometry.
    if name in SUPPORTED:
        policy = FrozenPolicy.model_validate_json(POLICY.read_text())
        if policy.rule_sha256 != rule_hash() or policy.spec_sha256[name] != case.spec_sha256:
            raise ExperimentRefusal("FROZEN_IDENTITY_MISMATCH", name)
        if policy.manifest_sha256 != manifest_hash() or policy.source_sha256 != source_hashes():
            raise ExperimentRefusal("FROZEN_IDENTITY_MISMATCH", "manifest or implementation")
        for admitted, digest in policy.admission_sha256.items():
            if (
                hashlib.sha256(
                    (OUTPUT / "admission" / admitted / "result.json").read_bytes()
                ).hexdigest()
                != digest
            ):
                raise ExperimentRefusal("FROZEN_IDENTITY_MISMATCH", f"admission: {admitted}")
    started = time.monotonic()
    budget = WorkBudget(started + case.budget_s)
    seen: set[str] = set()
    attempts: list[dict[str, object]] = []
    try:
        with absolute_deadline(budget):
            for order in ORDERS:
                session = TemplateRun(
                    budget, order, OUTPUT / name / order, mode=mode, seen_topologies=seen
                )
                attempt = run(name, reuse=True, capacity_first=True, template=session)
                attempts.append(attempt)
                outcome = attempt["outcome"]
                if outcome in {
                    "VALIDATOR_COMPLETE_WITNESS",
                    "RATED_ORIGINAL_ACCEPTED",
                    "RATE_REALIZATION_UNPROVED",
                    "DEADLINE",
                    "POLICY_BOUND",
                    "CAPACITY_CUT",
                    "UNSUPPORTED_INTERFACE",
                    "EMISSION_OR_AUDIT_FAILURE",
                    "FACTORY_VALIDATION_FAILURE",
                }:
                    break
    except ExperimentRefusal as failure:
        attempts.append({"outcome": failure.reason, "reason": failure.detail})
    substantive = [attempt for attempt in attempts if attempt["outcome"] != "DUPLICATE_TOPOLOGY"]
    terminal = (substantive or attempts)[-1]
    result = {
        "case": name,
        "mode": mode,
        "spec_sha256": case.spec_sha256,
        "outcome": terminal["outcome"],
        "reason": terminal.get("reason"),
        "attempts": attempts,
        "elapsed_s": time.monotonic() - started,
        "budget_s": case.budget_s,
        "work": budget.counts,
        "original_factory_gate": False,
        "rule_sha256": rule_hash(),
        "global_router_calls": 0,
    }
    folder = OUTPUT / name
    folder.mkdir(parents=True, exist_ok=True)
    (folder / "result.json").write_text(json.dumps(result, indent=2, default=str))
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=("admit", "freeze", "run"))
    parser.add_argument("names", nargs="*")
    parser.add_argument(
        "--mode", choices=("GEOMETRY_ONLY", "RATED_ACCEPTANCE"), default="GEOMETRY_ONLY"
    )
    args = Command.model_validate(vars(parser.parse_args()))
    with patch.object(
        rd, "_route_all", side_effect=AssertionError("global router is forbidden")
    ) as router:
        try:
            if args.command == "freeze":
                print(freeze().model_dump_json(indent=2))
            else:
                names = args.names or (
                    SUPPORTED if args.command == "admit" else ("three-output", "unsprayed-mall")
                )
                for name in names:
                    result = (
                        admission(name) if args.command == "admit" else execute(name, args.mode)
                    )
                    print(json.dumps(result, default=str), flush=True)
        except ExperimentRefusal as failure:
            print(json.dumps({"outcome": failure.reason, "reason": failure.detail}), flush=True)
            raise SystemExit(2) from failure
        assert router.call_count == 0


if __name__ == "__main__":
    main()
