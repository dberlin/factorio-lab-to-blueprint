"""Throwaway independent feasibility probe; never modifies frozen selector sources."""

from __future__ import annotations

import argparse
import contextlib
import hashlib
import importlib
import io
import json
import signal
import sys
import tempfile
import time
import zipfile
from collections import defaultdict
from dataclasses import asdict, replace
from itertools import combinations
from pathlib import Path
from unittest.mock import patch

import ortools
from ortools.sat.python import cp_model
from pydantic import TypeAdapter


class DiagnosticLimit(RuntimeError):
    pass


def expand(points):
    result = [points[0]]
    for a, b in zip(points, points[1:], strict=False):
        axes = [i for i in range(3) if a[i] != b[i]]
        assert len(axes) == 1
        axis = axes[0]
        step = 1 if b[axis] > a[axis] else -1
        for value in range(a[axis] + step, b[axis] + step, step):
            point = list(a)
            point[axis] = value
            result.append(tuple(point))
    return result


def share(a, b, cell):
    if a.item != b.item:
        return False
    for ea, sa in ((a.source, True), (a.sink, False)):
        for eb, sb in ((b.source, True), (b.sink, False)):
            if ea.cell != cell or eb.cell != cell:
                continue
            if ea.port_id == eb.port_id:
                if sa != sb and ea.outward == (-eb.outward[0], -eb.outward[1]):
                    return True
            elif (
                ea.junction_id is not None
                and ea.junction_id == eb.junction_id
                and ea.outward != eb.outward
            ):
                return True
    return False


def port_conflict(a, b):
    return any(
        ea.port_id == eb.port_id and (ea.cell != eb.cell or not share(a, b, ea.cell))
        for ea in (a.source, a.sink)
        for eb in (b.source, b.sink)
    )


def conflict(a, acells, b, bcells):
    return port_conflict(a, b) or any(not share(a, b, cell) for cell in acells & bcells)


def static_valid(geometry, cells, problem, fixed_cells):
    path = geometry.path
    if len(cells) != len(set(cells)):
        return False
    if (
        path.points[0] != path.source.cell
        or path.points[-1] != path.sink.cell
        or path.source.port_id == path.sink.port_id
    ):
        return False
    for endpoint, near in ((path.source, path.points[1]), (path.sink, path.points[-2])):
        dx, dy = endpoint.outward
        if (dx, dy) not in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            return False
        if (
            near[2] != endpoint.cell[2]
            or (near[0] - endpoint.cell[0]) * dx + (near[1] - endpoint.cell[1]) * dy <= 0
        ):
            return False
    occupied = set(cells)
    owned = {e.cell for e in (path.source, path.sink) if e in problem.owned_endpoints}
    if (occupied - owned) & problem.blocked:
        return False
    return not any(
        conflict(path, occupied, fixed, f_cells)
        for fixed, f_cells in zip(problem.fixed_paths, fixed_cells, strict=True)
    )


def solve(problem, paths, work, policy, report, checkpoint):
    deadline = report["started_monotonic"] + policy["wall_seconds_including_preparation"]
    budget = work.WorkBudget(
        deadline,
        replace(
            work.WorkLimits(),
            predicates=policy["diagnostic_predicate_limit"],
            candidates=policy["diagnostic_candidate_limit"],
        ),
    )
    report["geometry_work"] = budget.counts
    domains = paths.domains(problem, budget)
    index = paths._FixedIndex(problem, budget)
    fixed_cells = [set(expand(p.points)) for p in problem.fixed_paths]
    choices = []
    postings = defaultdict(lambda: defaultdict(list))
    report["domains"] = []
    expanded = 0
    for di, domain in enumerate(domains):
        unique = {}
        candidates = []
        rejected = duplicates = 0
        for ci in domain._ids(budget):
            geometry = domain._decode(ci, budget)
            # Exact duplicate geometry has the same endpoints/item within this domain.
            key = geometry.path.points
            if key in unique:
                duplicates += 1
                continue
            cells = expand(key)
            expanded += len(cells)
            if expanded > policy["maximum_expanded_candidate_cells"]:
                raise DiagnosticLimit("expanded candidate cell allowance")
            actual = (
                paths._path_error(geometry, budget) is None
                and index.error(geometry, budget) is None
            )
            independent = static_valid(geometry, cells, problem, fixed_cells)
            if actual != independent:
                raise AssertionError(
                    (
                        "static geometry disagreement",
                        domain.obligation.ordinal,
                        ci,
                        actual,
                        independent,
                    )
                )
            if not actual:
                rejected += 1
                continue
            representative = len(candidates)
            unique[key] = representative
            candidates.append((ci, geometry))
            for cell in cells:
                postings[cell][di].append(representative)
        choices.append(candidates)
        report["domains"].append(
            {
                "ordinal": domain.obligation.ordinal,
                "enumerated": domain.count,
                "static_rejected": rejected,
                "exact_duplicates": duplicates,
                "retained": len(candidates),
            }
        )
        report["expanded_candidate_cells"] = expanded
        checkpoint("preparation")
    report["complete_domain_enumeration"] = True
    if any(not candidates for candidates in choices):
        report["outcome"] = "FROZEN_FAMILY_INFEASIBLE"
        report["reason"] = "A fully enumerated domain has no statically legal candidate."
        return None
    for i, j in combinations(range(len(domains)), 2):
        if port_conflict(choices[i][0][1].path, choices[j][0][1].path):
            report["outcome"] = "FROZEN_FAMILY_INFEASIBLE"
            report["reason"] = (
                "Two obligations have inconsistent immutable physical port identities."
            )
            report["port_conflict_ordinals"] = [
                domains[i].obligation.ordinal,
                domains[j].obligation.ordinal,
            ]
            return None
    model = cp_model.CpModel()
    variables = [
        [model.new_bool_var(f"d{di}c{ci}") for ci in range(len(candidates))]
        for di, candidates in enumerate(choices)
    ]
    for variables_for_domain in variables:
        model.add_exactly_one(variables_for_domain)
    cuts = set()
    report["rounds"] = []
    report["cuts"] = []
    report["solver_variables"] = sum(map(len, variables))
    report["preparation_seconds"] = time.monotonic() - report["started_monotonic"]
    solver = cp_model.CpSolver()
    solver.parameters.num_search_workers = policy["solver_workers"]
    solver.parameters.random_seed = policy["solver_random_seed"]
    solver.parameters.randomize_search = False
    for iteration in range(policy["maximum_rounds"]):
        budget.check()
        solver.parameters.max_time_in_seconds = max(0.001, deadline - time.monotonic())
        status = solver.solve(model)
        report["rounds"].append(
            {
                "round": iteration,
                "status": solver.status_name(status),
                "wall_seconds": solver.wall_time,
                "conflicts": solver.num_conflicts,
                "branches": solver.num_branches,
                "cuts_before": len(cuts),
            }
        )
        checkpoint("solving")
        if status == cp_model.INFEASIBLE:
            report["outcome"] = "FROZEN_FAMILY_INFEASIBLE"
            report["reason"] = (
                "CP-SAT proved the fully enumerated exact-domain relaxation "
                "with sound collision exclusions infeasible."
            )
            return None
        if status not in (cp_model.FEASIBLE, cp_model.OPTIMAL):
            if status == cp_model.MODEL_INVALID:
                raise AssertionError(solver.response_stats())
            raise DiagnosticLimit("CP-SAT returned no feasibility conclusion")
        selected = [
            next(ci for ci, var in enumerate(row) if solver.boolean_value(var)) for row in variables
        ]
        selected_geometries = [
            candidates[ci][1] for candidates, ci in zip(choices, selected, strict=True)
        ]
        selected_cells = [set(expand(g.path.points)) for g in selected_geometries]
        new_cuts = 0
        for i, j in combinations(range(len(domains)), 2):
            budget.check()
            a, b = selected_geometries[i], selected_geometries[j]
            bad_cells = sorted(
                cell
                for cell in selected_cells[i] & selected_cells[j]
                if not share(a.path, b.path, cell)
            )
            assert paths._compatible(a, b, budget) == (not bad_cells)
            if not bad_cells:
                continue
            # One exact shared-cell exclusion also removes all other candidates
            # with the same unavoidable resource conflict, not just this pair.
            cell = bad_cells[0]
            occupants = postings[cell]
            can_share = any(
                share(choices[x][0][1].path, choices[y][0][1].path, cell)
                for x, y in combinations(occupants, 2)
            )
            owners = (i, j) if can_share else tuple(sorted(occupants))
            key = (cell, owners)
            if key in cuts:
                # A cut already added in this same round may cover many pairs.
                continue
            if len(cuts) == policy["maximum_collision_cuts"]:
                raise DiagnosticLimit("collision cut allowance")
            model.add_at_most_one(variables[di][ci] for di in owners for ci in occupants[di])
            cuts.add(key)
            new_cuts += 1
            report["cuts"].append(
                {
                    "cell": cell,
                    "ordinals": [domains[di].obligation.ordinal for di in owners],
                    "candidate_terms": sum(len(occupants[di]) for di in owners),
                }
            )
        if new_cuts:
            continue
        # With no new cut, an invalid relaxed witness would be a model bug.
        assert all(
            not conflict(a.path, selected_cells[i], b.path, selected_cells[j])
            for i, a in enumerate(selected_geometries)
            for j, b in enumerate(selected_geometries)
            if i < j
        )
        budget.check()
        report["outcome"] = "COMPLETE_TEMPLATE_GEOMETRY_WITNESS"
        report["selected_candidate_ids"] = {
            domain.obligation.ordinal: candidates[ci][0]
            for domain, candidates, ci in zip(domains, choices, selected, strict=True)
        }
        report["selected_points"] = {
            domain.obligation.ordinal: geometry.path.points
            for domain, geometry in zip(domains, selected_geometries, strict=True)
        }
        report["independent_selected_pairs"] = len(domains) * (len(domains) - 1) // 2
        return report["selected_points"]
    raise DiagnosticLimit("solver round allowance")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("archive", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    policy_source = Path(__file__).with_name("diagnostic-policy.json")
    policy = json.loads(policy_source.read_text())
    started = time.monotonic()
    report = {
        "outcome": "UNKNOWN",
        "diagnostic_only": True,
        "policy": policy,
        "policy_sha256": hashlib.sha256(policy_source.read_bytes()).hexdigest(),
        "ortools_version": ortools.__version__,
        "archive_sha256": hashlib.sha256(args.archive.read_bytes()).hexdigest(),
        "started_monotonic": started,
    }

    def checkpoint(phase):
        report["phase"] = phase
        report["elapsed_seconds"] = time.monotonic() - started
        (args.output / "progress.json").write_text(json.dumps(report, indent=2, default=str))

    def expired(_signal, _frame):
        raise DiagnosticLimit("absolute diagnostic deadline")

    signal.signal(signal.SIGALRM, expired)
    signal.setitimer(signal.ITIMER_REAL, policy["wall_seconds_including_preparation"])
    try:
        with tempfile.TemporaryDirectory(prefix="independent-template-") as temporary:
            with zipfile.ZipFile(args.archive) as archive:
                archive.extractall(temporary)
            prefix = "2026-09-09-joint-domain-templates"
            sys.path.insert(0, temporary)
            package = Path(temporary) / prefix
            paths = importlib.import_module(prefix + ".template_paths")
            work = importlib.import_module(prefix + ".template_budget")
            control = importlib.import_module(prefix + ".constructive_control")
            runtime = importlib.import_module(prefix + ".template_runtime")
            routing = importlib.import_module("flab2bp.layout.routing_domain")
            frozen = json.loads((package / "template-policy.json").read_text())
            for name, digest in frozen["source_sha256"].items():
                assert hashlib.sha256((package / name).read_bytes()).hexdigest() == digest
            report["frozen_rule_sha256"] = frozen["rule_sha256"]
            data = json.loads((package / "joint-frontier-input.json").read_text())["problem"]
            problem = TypeAdapter(paths.TemplateProblem).validate_python(data)
            report["problem_sha256"] = hashlib.sha256(
                json.dumps(asdict(problem), sort_keys=True, default=str).encode()
            ).hexdigest()
            captured = []

            def capture(actual, _budget):
                assert actual == problem, "Captured input differs from actual frozen control"
                captured.append(actual)
                raise work.ExperimentRefusal(
                    "DIAGNOSTIC_CAPTURE", "unchanged complete-domain input captured"
                )

            budget = work.WorkBudget(started + policy["wall_seconds_including_preparation"])
            session = runtime.TemplateRun(budget, "captured", args.output / "capture")
            with (
                patch.object(runtime, "select", capture),
                patch.object(
                    routing, "_route_all", side_effect=AssertionError("global router forbidden")
                ),
                contextlib.redirect_stdout(io.StringIO()),
            ):
                capture_result = control.run(
                    "three-output", reuse=True, capacity_first=True, template=session
                )
            assert len(captured) == 1 and capture_result["outcome"] == "DIAGNOSTIC_CAPTURE"
            report["actual_frozen_problem_equality"] = True
            checkpoint("captured")
            try:
                selected = solve(problem, paths, work, policy, report, checkpoint)
            except work.ExperimentRefusal as refusal:
                raise DiagnosticLimit(
                    f"diagnostic geometry work: {refusal.reason}: {refusal.detail}"
                ) from refusal
            signal.setitimer(signal.ITIMER_REAL, 0)
            report["feasibility_elapsed_seconds"] = time.monotonic() - started
            if selected is not None:
                report["audit"] = {"status": "pending", "diagnostic_only": True}
                checkpoint("auditing")
                signal.setitimer(signal.ITIMER_REAL, policy["audit_wall_seconds"])

                def supplied(actual, _budget):
                    assert actual == problem
                    return selected

                audit_budget = work.WorkBudget(time.monotonic() + policy["audit_wall_seconds"])
                session = runtime.TemplateRun(audit_budget, "captured", args.output / "audit")
                try:
                    with (
                        patch.object(runtime, "select", supplied),
                        patch.object(
                            routing,
                            "_route_all",
                            side_effect=AssertionError("global router forbidden"),
                        ),
                        contextlib.redirect_stdout(io.StringIO()),
                    ):
                        audited = control.run(
                            "three-output", reuse=True, capacity_first=True, template=session
                        )
                    report["audit"] = {"diagnostic_only": True, "result": audited}
                except DiagnosticLimit as refusal:
                    report["audit"] = {
                        "diagnostic_only": True,
                        "status": "UNKNOWN",
                        "reason": str(refusal),
                    }
    except DiagnosticLimit as refusal:
        report["outcome"] = "UNKNOWN"
        report["reason"] = str(refusal)
    except Exception as failure:
        report["outcome"] = "DIAGNOSTIC_ERROR"
        report["reason"] = repr(failure)
        raise
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        report["elapsed_seconds"] = time.monotonic() - started
        (args.output / "result.json").write_text(json.dumps(report, indent=2, default=str))
        print(
            json.dumps(
                {
                    k: v
                    for k, v in report.items()
                    if k not in ("cuts", "rounds", "selected_points", "audit", "policy")
                },
                default=str,
            )
        )


if __name__ == "__main__":
    main()
