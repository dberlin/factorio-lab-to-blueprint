import importlib,json,time,hashlib
from pathlib import Path
from dataclasses import asdict
from itertools import combinations
from unittest.mock import patch
from pydantic import TypeAdapter
from flab2bp.layout import routing_domain
r=Path.cwd();name='2026-09-09-cadical-occupancy';d=r/'.superpowers/sdd'/name;out=r/'.superpowers/sdd/2026-09-09-cadical-progress/selection-verification';out.mkdir(exist_ok=True)
paths=importlib.import_module(name+'.template_paths');work=importlib.import_module(name+'.template_budget');runtime=importlib.import_module(name+'.template_runtime');control=importlib.import_module(name+'.constructive_control');oracle=importlib.import_module('2026-09-09-cadical-feasibility.probe')
data=json.loads((r/'.superpowers/sdd/2026-09-09-joint-domain-templates/joint-frontier-input.json').read_text())['problem'];problem=TypeAdapter(paths.TemplateProblem).validate_python(data);captured=[]
def capture(actual,budget,stats,checkpoint):
 assert actual==problem;captured.append(actual);raise work.ExperimentRefusal('DIAGNOSTIC_CAPTURE','saved selection verification, no solver invoked')
session=runtime.TemplateRun(work.WorkBudget(time.monotonic()+30),'captured',out/'capture')
with patch.object(runtime,'select',capture),patch.object(routing_domain,'_route_all',side_effect=AssertionError('global router forbidden')):
 result=control.run('three-output',reuse=True,capacity_first=True,template=session)
assert len(captured)==1 and result['outcome']=='DIAGNOSTIC_CAPTURE'
checkpoint=json.loads((d/'template-cases/three-output/captured/solver-progress.json').read_text());assert checkpoint['phase']=='geometry-complete';ids=checkpoint['stats']['selected_candidate_ids'];budget=work.WorkBudget(time.monotonic()+30);domains=paths.domains(problem,budget);fixed_index=paths._FixedIndex(problem,budget);fixed_cells=[set(oracle.expand(p.points)) for p in problem.fixed_paths];selected=[];points={}
for domain in domains:
 geometry=domain._decode(ids[str(domain.obligation.ordinal)],budget);expanded=oracle.expand(geometry.path.points);assert paths._path_error(geometry,budget) is None;assert fixed_index.error(geometry,budget) is None;assert oracle.static_valid(geometry,expanded,problem,fixed_cells);selected.append((geometry,set(expanded)));points[domain.obligation.ordinal]=geometry.path.points
for (a,acells),(b,bcells) in combinations(selected,2):
 assert paths._compatible(a,b,budget);assert not oracle.conflict(a.path,acells,b.path,bcells)
report={'outcome':'INDEPENDENT_COMPLETE_GEOMETRY_WITNESS','diagnostic_only':True,'solver_rerun':False,'actual_control_problem_equality':True,'problem_sha256':hashlib.sha256(json.dumps(asdict(problem),sort_keys=True,default=str).encode()).hexdigest(),'selected_obligations':len(selected),'independent_selected_pairs':len(selected)*(len(selected)-1)//2,'static_and_dynamic_geometry_agree':True,'original_budget_gate':'UNKNOWN; no construction/audit completion','no_function_profile':True};(out/'report.json').write_text(json.dumps(report,indent=2));(out/'selected-points.json').write_text(json.dumps(points,indent=2));print(json.dumps(report))
