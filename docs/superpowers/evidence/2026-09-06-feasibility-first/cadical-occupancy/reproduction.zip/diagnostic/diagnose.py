"""Observational replay: retain existing phase/counters, never profile functions."""

from __future__ import annotations

import argparse
import importlib
import json
import os
import subprocess
import sys
import time
import zipfile
from dataclasses import asdict
from pathlib import Path
from unittest.mock import patch

from pydantic import BaseModel

PACKAGE = "2026-09-09-cadical-original-budget"


class Command(BaseModel):
    project: Path
    archive: Path
    output: Path
    child: bool = False


def child(args: Command) -> None:
    sys.path.insert(0, str(args.output / "extracted"))
    runtime = importlib.import_module(PACKAGE + ".template_runtime")
    backend = importlib.import_module(PACKAGE + ".template_cadical")
    experiment = importlib.import_module(PACKAGE + ".template_experiment")
    original_select = runtime.select
    original_limited = backend.Cadical195.solve_limited
    current_stats = None
    last_round = -1

    def checkpoint(phase: str, returned: bool | None = None) -> None:
        payload = {
            "phase": phase,
            "stats": asdict(current_stats) if current_stats is not None else None,
            "native_return": returned,
        }
        temporary = args.output / "solver-progress.tmp"
        temporary.write_text(json.dumps(payload, indent=2))
        temporary.replace(args.output / "solver-progress.json")

    def select(problem, budget, stats):
        nonlocal current_stats
        current_stats = stats
        checkpoint("preparation")
        try:
            result = original_select(problem, budget, stats)
            checkpoint("geometry-complete")
            return result
        finally:
            checkpoint("selector-exit")

    def limited(solver):
        nonlocal last_round
        assert current_stats is not None
        checkpoint("native-call")
        if current_stats.rounds != last_round:
            with (args.output / "rounds.jsonl").open("a") as stream:
                stream.write(json.dumps(asdict(current_stats)) + "\n")
            last_round = current_stats.rounds
        result = original_limited(solver)
        checkpoint("checking-model" if result is True else "native-return", result)
        return result

    sys.argv = ["template_experiment", "run", "three-output"]
    with (
        patch.object(runtime, "select", select),
        patch.object(backend.Cadical195, "solve_limited", limited),
    ):
        experiment.main()


def main() -> None:
    parser = argparse.ArgumentParser()
    _ = parser.add_argument("project", type=Path)
    _ = parser.add_argument("archive", type=Path)
    _ = parser.add_argument("output", type=Path)
    _ = parser.add_argument("--child", action="store_true")
    args = Command.model_validate(vars(parser.parse_args()))
    if args.child:
        child(args)
        return
    args.output.mkdir(parents=True, exist_ok=False)
    extract = args.output / "extracted"
    with zipfile.ZipFile(args.archive) as archive:
        for name in archive.namelist():
            if name.startswith(PACKAGE + "/") and not name.startswith(
                PACKAGE + "/template-cases/three-output/"
            ):
                archive.extract(name, extract)
    environment = dict(os.environ)
    environment["PYTHONPATH"] = str(
        args.project / ".superpowers/sdd/2026-09-09-cadical-feasibility/deps"
    )
    command = [
        sys.executable,
        str(Path(__file__).resolve()),
        str(args.project),
        str(args.archive),
        str(args.output),
        "--child",
    ]
    started = time.monotonic()
    deadline = started + 30
    killed = False
    progress_path = extract / PACKAGE / "template-cases/three-output/progress.json"
    with (
        (args.output / "stdout.txt").open("w") as stdout,
        (args.output / "stderr.txt").open("w") as stderr,
    ):
        process = subprocess.Popen(command, env=environment, stdout=stdout, stderr=stderr)
        while process.poll() is None:
            try:
                state = json.loads(progress_path.read_text())
                deadline = state["deadline"]
            except FileNotFoundError, json.JSONDecodeError:
                pass
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                killed = True
                process.terminate()
                try:
                    _ = process.wait(timeout=0.2)
                except subprocess.TimeoutExpired:
                    process.kill()
                break
            time.sleep(min(0.02, remaining))
        code = process.wait()
    result = {
        "exit": code,
        "hard_deadline_terminated": killed,
        "original_budget_seconds": 30,
        "diagnostic_only": True,
        "function_profile_created": False,
    }
    (args.output / "supervisor.json").write_text(json.dumps(result, indent=2))
    print(json.dumps(result))


if __name__ == "__main__":
    main()
