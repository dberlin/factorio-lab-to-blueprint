"""Construct the frozen original control; preserve every captured obligation."""

from __future__ import annotations

import hashlib
import json
import sys
import time
from collections import defaultdict, deque
from dataclasses import asdict
from fractions import Fraction
from pathlib import Path
from unittest.mock import patch

from pydantic import TypeAdapter

from flab2bp import pipeline
from flab2bp.dsp import codec
from flab2bp.lab.data import load_vendored
from flab2bp.lab.flow import canonicalize_dataset
from flab2bp.lab.techs import belt_rules_for_url
from flab2bp.layout import finalize, freeform, markers, validate
from flab2bp.layout import routing_domain as rd
from flab2bp.layout.base import Placement
from flab2bp.layout.slots import assign_sorter_slots
from flab2bp.spec import BuildSpec

from .constructive_composition import POLICY, ConstructionRefusal, Constructor, Terminal
from .run_experiment import Case
from .transport_first import Inventory, TransportDemand, capture_inventory

ROOT = Path(__file__).resolve().parent
Node = tuple[str, int, str]


def assign_rates(spec: BuildSpec, inventory: Inventory) -> dict[int, Fraction]:
    """Exact feasible flow on the captured adjacency, including external shares.

    Supply belongs to machine-strip/item pools, not independently to every output
    port. This preserves a producer whose output is split between export and use.
    Zero-flow edges remain physical obligations; no captured connection is dropped.
    """
    graph: dict[Node, dict[Node, Fraction]] = defaultdict(dict)
    original_capacity: dict[tuple[Node, Node], Fraction] = {}
    root: Node = ("root", 0, "")
    end: Node = ("end", 0, "")
    adapted = rd._adapt(spec)

    def add(a: Node, b: Node, capacity: Fraction) -> None:
        if b in graph[a]:
            raise ConstructionRefusal(
                f"parallel physical pool edges need explicit allocation: {a} -> {b}"
            )
        graph[a][b] = capacity
        graph[b][a] = Fraction()
        original_capacity[a, b] = capacity

    supply_total = Fraction()
    demand_total = Fraction()
    for index, strip in enumerate(inventory.strips):
        group = adapted[strip.group_key]
        for item, per_machine in group.outputs.items():
            rate = per_machine * strip.machines
            add(root, ("producer", index, item), rate)
            supply_total += rate
        for item, per_machine in group.inputs.items():
            rate = per_machine * strip.machines
            add(("consumer", index, item), end, rate)
            demand_total += rate
    for item, rate in spec.external_inputs.items():
        add(root, ("external", 0, item), rate)
        supply_total += rate
    for item in set(spec.outputs) | set(spec.surplus_outputs):
        rate = spec.outputs.get(item, Fraction()) + spec.surplus_outputs.get(item, Fraction())
        add(("export", 0, item), end, rate)
        demand_total += rate
    assert supply_total == demand_total
    edges: dict[int, tuple[Node, Node]] = {}
    for demand in inventory.demands:
        source = (
            ("producer", demand.source.strip, demand.item)
            if demand.source
            else ("external", 0, demand.item)
        )
        sink = (
            ("consumer", demand.sink.strip, demand.item)
            if demand.sink
            else ("export", 0, demand.item)
        )
        add(source, sink, spec.lane_capacity)
        edges[demand.ordinal] = source, sink
    delivered = Fraction()
    while True:
        previous: dict[Node, Node | None] = {root: None}
        queue: deque[Node] = deque([root])
        while queue and end not in previous:
            node = queue.popleft()
            for neighbour, capacity in graph[node].items():
                if capacity > 0 and neighbour not in previous:
                    previous[neighbour] = node
                    queue.append(neighbour)
        if end not in previous:
            break
        walk: list[tuple[Node, Node]] = []
        node = end
        while node != root:
            parent = previous[node]
            assert parent is not None
            walk.append((parent, node))
            node = parent
        amount = min(graph[a][b] for a, b in walk)
        for a, b in walk:
            graph[a][b] -= amount
            graph[b][a] += amount
        delivered += amount
    if delivered != demand_total:
        raise ConstructionRefusal(
            f"captured adjacency cannot carry exact original rates: {delivered}/{demand_total}"
        )
    return {ordinal: original_capacity[a, b] - graph[a][b] for ordinal, (a, b) in edges.items()}


def run(name: str) -> None:
    case = next(
        row
        for row in TypeAdapter(list[Case]).validate_json(
            (ROOT / "frozen/manifest.json").read_text()
        )
        if row.name == name
    )
    raw = (ROOT / "frozen" / f"{name}.json").read_bytes()
    assert hashlib.sha256(raw).hexdigest() == case.spec_sha256
    spec = BuildSpec.model_validate_json(raw)
    rules = belt_rules_for_url(case.url, canonicalize_dataset(load_vendored()))
    output = ROOT / "constructive-cases" / name
    output.mkdir(parents=True, exist_ok=True)
    result: dict[str, object] = {
        "case": case.name,
        "spec_sha256": case.spec_sha256,
        "budget_s": case.budget_s,
        "original_factory_gate": False,
        "global_router_calls": 0,
    }
    started = time.monotonic()
    constructor = Constructor(spec, rules)

    def cancelled() -> bool:
        return time.monotonic() >= started + case.budget_s

    try:
        inventory = capture_inventory(spec, rules, started + case.budget_s)
        flights_required = sum(d.role != "output" for d in inventory.demands)
        flights_available = constructor.canvas.levels - 3
        result.update(
            {
                "obligations": len(inventory.demands),
                "flights_required": flights_required,
                "flights_available": flights_available,
                "held_out": case.held_out,
            }
        )
        if flights_required > flights_available:
            raise ConstructionRefusal(
                f"fixed one-level-per-flight construction needs {flights_required} "
                f"flight levels; original technology provides {flights_available}"
            )
        rates = assign_rates(spec, inventory)
        result["assigned_rates"] = {str(k): str(v) for k, v in rates.items()}
        source_families: dict[int, list[TransportDemand]] = defaultdict(list)
        sink_families: dict[int, list[TransportDemand]] = defaultdict(list)
        for demand in inventory.demands:
            if demand.source:
                source_families[demand.source.belt].append(demand)
            if demand.sink:
                sink_families[demand.sink.belt].append(demand)
        adapted = rd._adapt(spec)
        source_nodes: dict[int, list[int]] = defaultdict(list)
        for belt, family in source_families.items():
            if len(family) > 1:
                source = family[0].source
                assert source is not None
                source_nodes[source.strip].append(belt)
        # Five strips per bank is the admitted witness's fixed bank capacity.
        banks = [
            list(range(i, min(i + 5, len(inventory.strips))))
            for i in range(0, len(inventory.strips), 5)
        ]
        origins: dict[int, tuple[int, int]] = {}
        bank_widths: list[int] = []
        x = 10
        for bank in banks:
            width = max(freeform._box(inventory.strips[i])[0] + 8 for i in bank)
            bank_widths.append(width)
            y = 10
            for i in bank:
                origins[i] = (x, y)
                y += freeform._box(inventory.strips[i])[1] + 6 + 4 * len(source_nodes[i])
            x += width + 24
        middle_x = 10 + bank_widths[0] + 12
        physical: dict[int, rd._Port] = {}
        for index, strip in enumerate(inventory.strips):
            group = adapted[strip.group_key]
            ox, oy = origins[index]
            ins, outs, _, fixed = rd._emit_strip(
                constructor.canvas,
                strip,
                ox + inventory.modules[index].origin[0],
                oy + inventory.modules[index].origin[1],
                constructor.belt_id,
                constructor.belt_model,
                {item: rate * group.count for item, rate in group.outputs.items()},
                group.inputs,
                group.outputs,
                owner_strip=index,
            )
            if fixed:
                raise ConstructionRefusal(
                    "fixed piler transition is outside this interface witness"
                )
            physical.update({p.belt: p for p in (*ins.values(), *outs.values())})
        # Capture and construction use identical emission order and strip variants.
        for demand in inventory.demands:
            for endpoint in (demand.source, demand.sink):
                if endpoint is not None:
                    port = physical[endpoint.belt]
                    ox, oy = origins[endpoint.strip]
                    assert (port.x, port.y, port.z) == (
                        ox + endpoint.x,
                        oy + endpoint.y,
                        endpoint.z,
                    )
        sources: dict[int, Terminal] = {}
        sinks: dict[int, Terminal] = {}
        for belt, family in source_families.items():
            port = physical[belt]
            if len(family) == 1:
                sources[family[0].ordinal] = Terminal(port, (1, 0))
                continue
            if len(family) > 3:
                raise ConstructionRefusal("source family exceeds compiled three-branch interface")
            endpoint = family[0].source
            assert endpoint is not None
            rank = source_nodes[endpoint.strip].index(belt)
            ox, oy = origins[endpoint.strip]
            node = constructor.splitter(
                port.x + 4,
                oy + inventory.modules[endpoint.strip].height + 2 + 4 * rank,
                family[0].item,
            )
            inlet = constructor.dock(node, (-1, 0), feed=True)
            constructor.flight(
                Terminal(port, (1, 0)),
                inlet,
                family[0].item,
                sum((rates[d.ordinal] for d in family), Fraction()),
                1 + rank,
                port.x + 2 + 2 * rank,
                "local-source",
            )
            for demand, direction in zip(family, ((1, 0), (0, 1), (0, -1)), strict=False):
                sources[demand.ordinal] = constructor.dock(node, direction, feed=False)
        for belt, family in sink_families.items():
            port = physical[belt]
            if len(family) == 1:
                sinks[family[0].ordinal] = Terminal(port, (-1, 0))
                continue
            if len(family) > 3:
                raise ConstructionRefusal("sink family exceeds compiled three-feed interface")
            node = constructor.splitter(port.x - 6, port.y, family[0].item)
            outlet = constructor.dock(node, (1, 0), feed=False)
            constructor.connect(
                outlet.port,
                port,
                [(outlet.port.x, outlet.port.y, 0), (port.x, port.y, 0)],
                family[0].item,
                sum((rates[d.ordinal] for d in family), Fraction()),
                "local-merge",
            )
            for demand, direction in zip(family, ((-1, 0), (0, 1), (0, -1)), strict=False):
                sinks[demand.ordinal] = constructor.dock(node, direction, feed=True)
        flight_index = 0
        external_index = 0
        right_edge = max(p.x for p in physical.values()) + 6
        for demand in inventory.demands:
            if cancelled():
                raise rd._PreparationDeadline
            if demand.role == "output":
                port = sources[demand.ordinal].port
                target = constructor.belt((right_edge, port.y, 0), demand.item)
                constructor.connect(
                    port,
                    target,
                    [(port.x, port.y, 0), (right_edge, port.y, 0)],
                    demand.item,
                    rates[demand.ordinal],
                    "output",
                )
                continue
            source = sources.get(demand.ordinal)
            if source is None:
                root = constructor.belt((0, -4 - 3 * external_index, 0), demand.item)
                external_index += 1
                source = Terminal(root, (1, 0))
            constructor.flight(
                source,
                sinks[demand.ordinal],
                demand.item,
                rates[demand.ordinal],
                3 + flight_index,
                middle_x,
                demand.role,
            )
            flight_index += 1
        constructor.canvas.limit = rd._core_bounds(constructor.canvas)
        demand_box = (
            10,
            10,
            right_edge,
            max(oy + inventory.modules[i].height for i, (_, oy) in origins.items()),
        )
        sites = rd._power_plan(constructor.canvas, demand_box, policy=POLICY, cancelled=cancelled)
        constructor.canvas.keep_out.clear()
        rd._place_power(constructor.canvas, sites)
        placement = Placement(buildings=assign_sorter_slots(constructor.canvas.buildings))
        placement = finalize.finalize_placement(placement, POLICY, cancelled=cancelled)
        report = validate.judge_placement(
            placement, spec, ids=pipeline._id_map(spec), expect_power=True, belt_rules=rules
        )
        (output / "report.json").write_text(json.dumps(asdict(report), indent=2, default=str))
        result.update(
            {
                "checks_run": len(report.checks_run),
                "errors": len(report.errors),
                "skipped": report.skipped,
                "area": placement.area,
                "bounds": placement.bounds,
            }
        )
        if report.errors or report.skipped or set(report.checks_run) != set(validate.CHECKS):
            result["outcome"] = "original-spec-refused"
            return
        blueprint = codec.encode(markers.mark_external_belts(placement, spec))
        decoded = codec.decode(blueprint)
        assert len(decoded.buildings) == len(placement.buildings)
        (output / "blueprint.txt").write_text(blueprint)
        result.update(
            {
                "outcome": "original-clean" if not cancelled() else "budget-refused",
                "original_factory_gate": not cancelled(),
                "buildings": len(decoded.buildings),
            }
        )
    except (
        ConstructionRefusal,
        rd._Unseatable,
        rd._PreparationDeadline,
        finalize.ProjectionRefusal,
        finalize.ProjectionCancelled,
    ) as failure:
        result.update({"outcome": "constructive-control-refused", "reason": str(failure)})
    finally:
        result.update(
            {
                "elapsed_s": time.monotonic() - started,
                "constructed_links": len(constructor.links),
                "junctions": constructor.junctions,
            }
        )
        (output / "links.json").write_text(
            json.dumps([asdict(link) for link in constructor.links], indent=2, default=str)
        )
        (output / "result.json").write_text(json.dumps(result, indent=2, default=str))
        print(json.dumps(result, default=str), flush=True)


if __name__ == "__main__":
    with patch.object(
        rd, "_route_all", side_effect=AssertionError("global router is forbidden")
    ) as router:
        run(sys.argv[1])
        assert router.call_count == 0
