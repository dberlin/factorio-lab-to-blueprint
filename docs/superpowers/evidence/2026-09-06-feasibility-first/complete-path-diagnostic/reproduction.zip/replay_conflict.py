"""Throwaway exhaustive conditional-domain replay with an independent cell oracle."""

from __future__ import annotations

import argparse
import hashlib
import importlib
import itertools
import json
import sys
import tempfile
import time
import zipfile
from collections import Counter
from dataclasses import asdict
from fractions import Fraction
from pathlib import Path


def expand(points):
    cells = set()
    for a, b in zip(points, points[1:], strict=False):
        length = sum(abs(x - y) for x, y in zip(a, b, strict=True))
        assert sum(x != y for x, y in zip(a, b, strict=True)) == 1
        for step in range(length + 1):
            cells.add(tuple(a[i] + (b[i] - a[i]) * step // length for i in range(3)))
    return cells


def incidence(a, b, cell):
    if a.item != b.item:
        return False
    for ea, role_a in ((a.source, "source"), (a.sink, "sink")):
        for eb, role_b in ((b.source, "source"), (b.sink, "sink")):
            if ea.cell != cell or eb.cell != cell:
                continue
            if ea.port_id == eb.port_id:
                if role_a != role_b and ea.outward == tuple(-x for x in eb.outward):
                    return True
            elif (
                ea.junction_id is not None
                and ea.junction_id == eb.junction_id
                and ea.outward != eb.outward
            ):
                return True
    return False


def independent(a, acells, b, bcells):
    for ea in (a.source, a.sink):
        for eb in (b.source, b.sink):
            if ea.port_id == eb.port_id and (ea.cell != eb.cell or not incidence(a, b, ea.cell)):
                return False
    return all(incidence(a, b, cell) for cell in acells & bcells)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("archive", type=Path)
    parser.add_argument("profile", type=Path)
    args = parser.parse_args()
    data = json.loads((args.profile / "problem.json").read_text())
    profile = json.loads((args.profile / "profile.json").read_text())
    with tempfile.TemporaryDirectory(prefix="template-conflict-") as temporary:
        with zipfile.ZipFile(args.archive) as archive:
            archive.extractall(temporary)
        sys.path.insert(0, temporary)
        name = "2026-09-08-transport-first"
        paths = importlib.import_module(name + ".template_paths")
        work = importlib.import_module(name + ".template_budget")

        def endpoint(e):
            return paths.Endpoint(
                tuple(e["cell"]), tuple(e["outward"]), e["port_id"], e["junction_id"]
            )

        def fixed(p):
            return paths.FixedPath(
                tuple(tuple(c) for c in p["points"]),
                endpoint(p["source"]),
                endpoint(p["sink"]),
                p["item"],
            )

        problem = paths.TemplateProblem(
            tuple(
                paths.Obligation(
                    o["ordinal"],
                    o["item"],
                    Fraction(o["rate"]),
                    endpoint(o["source"]),
                    endpoint(o["sink"]),
                )
                for o in data["obligations"]
            ),
            frozenset(tuple(c) for c in data["blocked"]),
            tuple(fixed(p) for p in data["fixed_paths"]),
            tuple(data["x_tracks"]),
            tuple(data["y_tracks"]),
            tuple(data["levels"]),
            tuple(endpoint(e) for e in data["owned_endpoints"]),
        )
        budget = work.WorkBudget(time.monotonic() + 30)
        domains = {d.obligation.ordinal: d for d in paths.domains(problem, budget)}
        index = paths._FixedIndex(problem, budget)
        target = domains[13]
        selected = {
            int(i): domains[int(i)]._decode(ci, budget)
            for i, ci in profile["terminal"]["selected"].items()
        }
        source_order = list(selected)
        selected_cells = {i: expand(g.path.points) for i, g in selected.items()}
        masks = {}
        static_errors = {}
        blockers = Counter()
        independent_checks = 0
        paths_by_id = {}
        started = time.monotonic()
        for candidate_id in target._ids(budget):
            geometry = target._decode(candidate_id, budget)
            error = paths._path_error(geometry, budget) or index.error(geometry, budget)
            if error is not None:
                static_errors[candidate_id] = error
                continue
            cells = expand(geometry.path.points)
            mask = 0
            for bit, ordinal in enumerate(source_order):
                actual = paths._compatible(geometry, selected[ordinal], budget)
                oracle = independent(
                    geometry.path, cells, selected[ordinal].path, selected_cells[ordinal]
                )
                assert actual == oracle, (candidate_id, ordinal, actual, oracle)
                independent_checks += 1
                if not actual:
                    mask |= 1 << bit
                    blockers[ordinal] += 1
            masks[candidate_id] = mask
            paths_by_id[candidate_id] = geometry.path.points
        assert len(masks) + len(static_errors) == target.count
        survivors = [ci for ci, mask in masks.items() if mask == 0]
        without_stone = ((1 << len(source_order)) - 1) ^ (1 << source_order.index(22))
        prefix_survivors = [ci for ci, mask in masks.items() if not mask & without_stone]
        repeated_prefix_decodes = sum(
            max(0, row["decodes"] - 1)
            for row in profile.get("hydrogen_prefix_decodes", ())
            if masks.get(row["candidate_id"], 0) & without_stone
        )
        attempted_stone = []
        for snapshot in profile["assignment_snapshots"]:
            if snapshot["trying_obligation"] != 22:
                continue
            stone = domains[22]._decode(snapshot["candidate"], budget)
            stone_cells = expand(stone.path.points)
            admitted = []
            for candidate_id in prefix_survivors:
                hydrogen = target._decode(candidate_id, budget)
                actual = paths._compatible(hydrogen, stone, budget)
                oracle = independent(
                    hydrogen.path, expand(hydrogen.path.points), stone.path, stone_cells
                )
                assert actual == oracle
                independent_checks += 1
                if actual:
                    admitted.append(candidate_id)
            attempted_stone.append(
                {"stone_candidate": snapshot["candidate"], "hydrogen_survivors": admitted}
            )
        minimum = None
        for size in range(1, len(source_order) + 1):
            for bits in itertools.combinations(range(len(source_order)), size):
                mask = sum(1 << bit for bit in bits)
                if all(value & mask for value in masks.values()):
                    minimum = (bits, mask)
                    break
            if minimum is not None:
                break
        bits, minimal_mask = minimum if minimum is not None else ((), 0)
        core = [source_order[bit] for bit in bits]
        deletion_witnesses = {}
        for bit in bits:
            remaining = minimal_mask ^ (1 << bit)
            candidate_id = next(ci for ci, value in masks.items() if not value & remaining)
            deletion_witnesses[source_order[bit]] = {
                "candidate_id": candidate_id,
                "points": paths_by_id[candidate_id],
                "compatible_with_other_core_members": True,
            }
        result = {
            "scope": "exhaustive conditional diagnosis; not global template-family feasibility",
            "target_obligation": 13,
            "target_item": target.obligation.item,
            "domain_count": target.count,
            "static_invalid": len(static_errors),
            "static_valid": len(masks),
            "compatible_with_seven_choice_prefix": len(prefix_survivors),
            "compatible_with_eight_choice_prefix": len(survivors),
            "prefix_survivor_ids": prefix_survivors,
            "survivor_example": {"candidate_id": survivors[0], "points": paths_by_id[survivors[0]]}
            if survivors
            else None,
            "independent_pair_checks": independent_checks,
            "production_oracle_disagreements": 0,
            "blocking_counts": dict(blockers),
            "smallest_core_ordinals": core,
            "core_assignments": {str(i): profile["terminal"]["selected"][str(i)] for i in core},
            "core_paths": {str(i): asdict(selected[i].path) for i in core},
            "core_deletion_witnesses": deletion_witnesses,
            "stone_obligation_22_needed_in_core": 22 in core,
            "attempted_stone_choices": attempted_stone,
            "repeated_decodes_of_candidates_blocked_by_unchanged_prefix": repeated_prefix_decodes,
            "static_errors": static_errors,
            "mask_histogram": dict(Counter(masks.values())),
            "mask_bit_order": source_order,
            "work": budget.counts,
            "elapsed_s": time.monotonic() - started,
            "profile_sha256": hashlib.sha256(
                (args.profile / "profile.json").read_bytes()
            ).hexdigest(),
        }
        (args.profile / "conflict-replay.json").write_text(
            json.dumps(result, indent=2, default=str)
        )
        print(
            json.dumps(
                {
                    key: value
                    for key, value in result.items()
                    if key
                    not in {
                        "core_paths",
                        "core_deletion_witnesses",
                        "static_errors",
                        "mask_histogram",
                    }
                },
                default=str,
            )
        )


if __name__ == "__main__":
    main()
