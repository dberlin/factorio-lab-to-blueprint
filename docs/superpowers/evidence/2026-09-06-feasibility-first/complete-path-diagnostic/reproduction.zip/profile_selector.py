"""Throwaway diagnostic: observe the frozen selector without changing decisions."""

from __future__ import annotations

import argparse
import hashlib
import importlib
import json
import sys
import tempfile
import time
import zipfile
from collections import Counter, defaultdict
from dataclasses import asdict
from pathlib import Path
from unittest.mock import patch


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("archive", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    prefix = "2026-09-08-transport-first"
    with tempfile.TemporaryDirectory(prefix="template-profile-") as temporary:
        with zipfile.ZipFile(args.archive) as bundle:
            bundle.extractall(temporary)
        package = Path(temporary) / prefix
        sys.path.insert(0, temporary)
        paths = importlib.import_module(prefix + ".template_paths")
        runtime = importlib.import_module(prefix + ".template_runtime")
        experiment = importlib.import_module(prefix + ".template_experiment")
        routing = importlib.import_module("flab2bp.layout.routing_domain")
        policy_bytes = (package / "template-policy.json").read_bytes()
        policy = json.loads(policy_bytes)
        for name, digest in policy["source_sha256"].items():
            assert hashlib.sha256((package / name).read_bytes()).hexdigest() == digest
        reference = json.loads((package / "template-cases/three-output/result.json").read_text())
        calls = Counter()
        predicates = Counter()
        timings: dict[str, float] = defaultdict(float)
        decoded = Counter()
        canonical = Counter()
        hydrogen_prefix_decodes = Counter()
        by_obligation = defaultdict(Counter)
        errors = Counter()
        conflicts = Counter()
        pair_seen = Counter()
        geometry_pairs = Counter()
        segment_seen = Counter()
        segment_cost = Counter()
        segment_first_cost = {}
        segment_completed = Counter()
        self_seen = Counter()
        self_cost = Counter()
        snapshots = []
        terminal = {}
        domain_rows = []
        phase = ["setup"]
        current = [None]
        assignment = [-1]
        selected_seen = set()
        originals = {
            "select": paths.select,
            "decode": paths.Domain._decode,
            "self": paths._path_error,
            "static": paths._FixedIndex.error,
            "hits": paths._FixedIndex._hits,
            "pair": paths._PairCache.check,
        }

        def measured(label, budget, operation):
            before = budget.counts.get("predicates", 0)
            started = time.perf_counter()
            calls[label] += 1
            try:
                return operation()
            finally:
                predicates[label] += budget.counts.get("predicates", 0) - before
                timings[label] += time.perf_counter() - started

        def decode(domain, candidate_id, budget):
            ordinal = domain.obligation.ordinal
            current[0] = ordinal
            decoded[ordinal, candidate_id] += 1
            by_obligation[ordinal]["decodes"] += 1
            caller = sys._getframe(1)
            local = caller.f_locals
            selected = local.get("selected", {})
            if ordinal == 13 and len(selected) >= 7:
                prefix_key = tuple((di, ci) for di, (ci, _) in list(selected.items())[:7])
                hydrogen_prefix_decodes[prefix_key, candidate_id] += 1
            if assignment[0] != budget.counts.get("assignments", 0):
                assignment[0] = budget.counts.get("assignments", 0)
                snapshots.append(
                    {
                        "assignment": assignment[0],
                        "trying_obligation": ordinal,
                        "candidate": candidate_id,
                        "selected": {str(di): ci for di, (ci, _) in selected.items()},
                        "predicates": budget.counts.get("predicates", 0),
                    }
                )
            selected_seen.add(tuple((di, ci) for di, (ci, _) in selected.items()))
            value = measured(
                "decode", budget, lambda: originals["decode"](domain, candidate_id, budget)
            )
            canonical[ordinal, value.path] += 1
            return value

        def self_error(geometry, budget):
            key = geometry.path
            self_seen[key] += 1
            before = budget.counts.get("predicates", 0)
            label = "self:" + phase[0]
            try:
                value = measured(label, budget, lambda: originals["self"](geometry, budget))
                if value is not None:
                    errors[label, current[0], value] += 1
                    by_obligation[current[0]]["self_rejected"] += 1
                return value
            finally:
                self_cost[key] += budget.counts.get("predicates", 0) - before

        def static_error(index, geometry, budget, *, ignore_owner=None):
            label = "static:" + phase[0]
            value = measured(
                label,
                budget,
                lambda: originals["static"](index, geometry, budget, ignore_owner=ignore_owner),
            )
            if value is not None:
                errors[label, current[0], value] += 1
                by_obligation[current[0]]["static_rejected"] += 1
            elif phase[0] == "search":
                by_obligation[current[0]]["static_passed"] += 1
            return value

        def hits(index, segment, budget):
            key = (segment.lo, segment.hi)
            segment_seen[key] += 1
            iterator = originals["hits"](index, segment, budget)
            cost = 0
            try:
                while True:
                    before = budget.counts.get("predicates", 0)
                    try:
                        value = next(iterator)
                    except StopIteration:
                        segment_completed[key] += 1
                        return
                    finally:
                        cost += budget.counts.get("predicates", 0) - before
                    yield value
            finally:
                segment_cost[key] += cost
                segment_first_cost.setdefault(key, cost)
                iterator.close()

        def pair(cache, a, ga, b, gb, budget):
            first, second = sorted((a, b))
            key = (first, second)
            pair_seen[key] += 1
            geometry_key = (ga.path, gb.path)
            geometry_pairs[geometry_key] += 1
            slot = ((first * 1_000_003) ^ second) % paths._PAIR_CACHE_ENTRIES
            hit = cache.first[slot] == first and cache.second[slot] == second
            calls["pair_cache_hit" if hit else "pair_cache_miss"] += 1
            label = "pair_hit" if hit else "pair_miss"
            before = budget.counts.get("predicates", 0)
            value = measured(label, budget, lambda: originals["pair"](cache, a, ga, b, gb, budget))
            if not hit and pair_seen[key] > 1:
                calls["pair_repeated_miss_predicates"] += (
                    budget.counts.get("predicates", 0) - before
                )
                calls["pair_cache_repeated_miss"] += 1
            if not value:
                conflicts[
                    ga.path.source.port_id,
                    ga.path.sink.port_id,
                    gb.path.source.port_id,
                    gb.path.sink.port_id,
                ] += 1
                by_obligation[current[0]]["pair_rejected"] += 1
            return value

        def select(problem, budget):
            phase[0] = "search"
            data = {
                "obligations": [asdict(o) for o in problem.obligations],
                "blocked": sorted(problem.blocked),
                "fixed_paths": [asdict(p) for p in problem.fixed_paths],
                "x_tracks": problem.x_tracks,
                "y_tracks": problem.y_tracks,
                "levels": problem.levels,
                "owned_endpoints": [asdict(e) for e in problem.owned_endpoints],
            }
            (args.output / "problem.json").write_text(json.dumps(data, default=str))
            started = time.perf_counter()
            try:
                return originals["select"](problem, budget)
            except BaseException as error:
                tb = error.__traceback__
                while tb is not None:
                    if tb.tb_frame.f_code is originals["select"].__code__:
                        values = tb.tb_frame.f_locals
                        ds = values["ds"]
                        live = values.get("live", ())
                        chosen = values.get("selected", {})
                        terminal.update(
                            {
                                "selected": {
                                    str(ds[i].obligation.ordinal): ci
                                    for i, (ci, _) in chosen.items()
                                },
                                "selected_paths": {
                                    str(ds[i].obligation.ordinal): geometry.path.points
                                    for i, (_, geometry) in chosen.items()
                                },
                                "frames": [
                                    {"domain": f.domain, "active": f.active, "mark": f.mark}
                                    for f in values.get("frames", ())
                                ],
                                "trail_size": len(values.get("trail", ())),
                                "first_obstruction": values.get("first_obstruction"),
                            }
                        )
                        for i, domain in enumerate(ds):
                            domain_rows.append(
                                {
                                    "ordinal": domain.obligation.ordinal,
                                    "item": domain.obligation.item,
                                    "source": asdict(domain.obligation.source),
                                    "sink": asdict(domain.obligation.sink),
                                    "count": domain.count,
                                    "live_upper": live[i].upper,
                                    "static_known": sum(v.bit_count() for v in live[i].known),
                                    "static_bad": sum(v.bit_count() for v in live[i].bad),
                                    "selected": i in chosen,
                                }
                            )
                    tb = tb.tb_next
                raise
            finally:
                timings["selector_wall"] = time.perf_counter() - started

        with (
            patch.object(runtime, "select", select),
            patch.object(paths.Domain, "_decode", decode),
            patch.object(paths, "_path_error", self_error),
            patch.object(paths._FixedIndex, "error", static_error),
            patch.object(paths._FixedIndex, "_hits", hits),
            patch.object(paths._PairCache, "check", pair),
            patch.object(
                routing, "_route_all", side_effect=AssertionError("global router forbidden")
            ) as router,
        ):
            result = experiment.execute("three-output", "GEOMETRY_ONLY")
            assert router.call_count == 0
        assert (package / "template-policy.json").read_bytes() == policy_bytes
        same = result["outcome"] == reference["outcome"] and result["work"] == reference["work"]
        accounted = sum(value for label, value in predicates.items() if label != "decode")
        report = {
            "scope": "throwaway observational diagnostic; no new acceptance policy",
            "same_frozen_outcome_and_counters": same,
            "policy_sha256": hashlib.sha256(policy_bytes).hexdigest(),
            "result": result,
            "calls": dict(calls),
            "predicates": dict(predicates),
            "unattributed_predicates": result["work"].get("predicates", 0) - accounted,
            "timings_s_inclusive": dict(timings),
            "decoded_calls": sum(decoded.values()),
            "unique_candidate_ids": len(decoded),
            "unique_decoded_paths": len(canonical),
            "self_check_calls": sum(self_seen.values()),
            "unique_self_checked_paths": len(self_seen),
            "self_predicates_on_repeated_paths": sum(
                self_cost[k] - self_cost[k] / self_seen[k] for k in self_seen
            ),
            "segment_queries": sum(segment_seen.values()),
            "unique_segments": len(segment_seen),
            "segment_query_predicates": sum(segment_cost.values()),
            "segment_predicates_after_first_query": sum(
                segment_cost[k] - segment_first_cost[k] for k in segment_seen
            ),
            "segment_completed_queries": sum(segment_completed.values()),
            "unique_pair_ids": len(pair_seen),
            "unique_geometry_pairs": len(geometry_pairs),
            "search_states_observed": len(selected_seen),
            "assignment_snapshots": snapshots,
            "terminal": terminal,
            "domains": domain_rows,
            "per_obligation": {str(k): dict(v) for k, v in by_obligation.items()},
            "hydrogen_prefix_decodes": [
                {"prefix": key[0], "candidate_id": key[1], "decodes": count}
                for key, count in hydrogen_prefix_decodes.items()
            ],
            "top_errors": [
                {"stage": k[0], "obligation": k[1], "error": k[2], "count": v}
                for k, v in errors.most_common(30)
            ],
            "top_conflicts": [{"ports": k, "count": v} for k, v in conflicts.most_common(30)],
            "top_segments": [
                {
                    "segment": k,
                    "queries": segment_seen[k],
                    "completed": segment_completed[k],
                    "predicates": v,
                }
                for k, v in segment_cost.most_common(30)
            ],
        }
        (args.output / "profile.json").write_text(json.dumps(report, indent=2, default=str))
        print(
            json.dumps(
                {
                    key: report[key]
                    for key in (
                        "same_frozen_outcome_and_counters",
                        "calls",
                        "predicates",
                        "unattributed_predicates",
                        "timings_s_inclusive",
                        "decoded_calls",
                        "unique_candidate_ids",
                        "unique_decoded_paths",
                        "segment_queries",
                        "unique_segments",
                        "segment_query_predicates",
                        "segment_predicates_after_first_query",
                        "search_states_observed",
                        "terminal",
                    )
                },
                default=str,
            )
        )
        if not same:
            raise SystemExit("instrumentation did not reach identical frozen stopping counters")


if __name__ == "__main__":
    main()
