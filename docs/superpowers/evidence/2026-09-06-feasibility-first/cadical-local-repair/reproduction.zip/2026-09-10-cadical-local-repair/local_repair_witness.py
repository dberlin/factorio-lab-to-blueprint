"""Disposable native SAT and canonical geometry proofs for local repair."""

from __future__ import annotations

import json
import time
from fractions import Fraction
from itertools import product

from pysat.solvers import Cadical195

from .local_repair import Ledger, LocalCompiler, core_release, repair
from .template_budget import ExperimentRefusal, WorkBudget, WorkLimits
from .template_paths import Endpoint, Obligation, TemplateProblem, _compatible, domains


def problem_for(*, shared: bool = False, wall: bool = False) -> TemplateProblem:
    source = Endpoint((0, 0, 3), (1, 0), 1, 99 if shared else None)
    peer = (
        Endpoint((0, 0, 3), (0, 1), 3, 99)
        if shared
        else Endpoint((1 if wall else 10, -10, 3), (0, 1), 3)
    )
    return TemplateProblem(
        (
            Obligation(0, "iron", Fraction(1), source, Endpoint((20, 0, 3), (-1, 0), 2)),
            Obligation(
                1, "iron", Fraction(1), peer, Endpoint((1 if wall else 10, 10, 3), (0, -1), 4)
            ),
        ),
        frozenset(),
        (),
        (),
        (),
        (3, 5),
    )


def run() -> dict[str, int | bool]:
    boundary_cases = mutual_cases = 0
    for shared in (False, True):
        budget = WorkBudget(time.monotonic() + 60)
        ds = domains(problem_for(shared=shared), budget)
        geometry = [[d._decode(candidate, budget) for candidate in range(d.count)] for d in ds]
        for held_candidate in (0, 1, ds[1].count - 1):
            with Cadical195() as solver:
                ledger = Ledger()
                compiler = LocalCompiler(
                    solver, (ds[0],), {1: geometry[1][held_candidate]}, budget, ledger
                )
                compiler.boundary()
                activation = next(iter(compiler.activations))
                for candidate, path in enumerate(geometry[0]):
                    combo, level = divmod(candidate, len(ds[0].levels))
                    choices = [compiler.factors.xy[0][combo], compiler.factors.height[0][level]]
                    assert solver.solve(assumptions=[activation, *choices]) == _compatible(
                        path, geometry[1][held_candidate], budget
                    )
                    assert solver.solve(assumptions=[-activation, *choices])
                    boundary_cases += 1
                previous = ledger.collision_cuts
                compiler.boundary()
                assert ledger.collision_cuts == previous
        with Cadical195() as solver:
            ledger = Ledger()
            compiler = LocalCompiler(solver, ds, {}, budget, ledger)
            compiler.mutual()
            for ca, cb in product(range(ds[0].count), range(ds[1].count)):
                a, pa = divmod(ca, len(ds[0].levels))
                b, pb = divmod(cb, len(ds[1].levels))
                assumptions = [
                    compiler.factors.xy[0][a],
                    compiler.factors.height[0][pa],
                    compiler.factors.xy[1][b],
                    compiler.factors.height[1][pb],
                ]
                assert solver.solve(assumptions=assumptions) == _compatible(
                    geometry[0][ca], geometry[1][cb], budget
                )
                mutual_cases += 1

    # A retained path occupies every possible exit from the other source.
    # Exact local UNSAT must release it, rebuild its full domain, then find geometry.
    problem = problem_for(wall=True)
    budget = WorkBudget(time.monotonic() + 60)
    ledger = Ledger()
    selected = repair(problem, [0, 0], [1], budget, ledger)
    assert ledger.released == [[1]] and ledger.rebuilds == 2
    assert ledger.native_calls >= 2 and selected[1] != 0
    assert core_release({11: 3, 12: 4}, None, budget) == [3, 4]
    assert core_release({11: 3, 12: 4}, [], budget) == [3, 4]
    try:
        core_release({11: 3}, [12], budget)
    except AssertionError:
        pass
    else:
        raise AssertionError("foreign assumption core accepted")

    # Unrestricted genuine UNSAT is not confused with a held-boundary refusal.
    from dataclasses import replace

    blocked = replace(problem, blocked=frozenset({(1, 0, 3)}))
    try:
        repair(blocked, [0, 0], [], WorkBudget(time.monotonic() + 60), Ledger())
    except ExperimentRefusal as error:
        assert error.reason == "LOCAL_DOMAIN_UNSAT"
    else:
        raise AssertionError("unavoidable static obstruction accepted")

    exhausted = WorkBudget(time.monotonic() + 60, WorkLimits(predicates=0))
    try:
        repair(problem, [0, 0], [1], exhausted, Ledger())
    except ExperimentRefusal as error:
        assert error.reason == "POLICY_BOUND"
    else:
        raise AssertionError("uncharged repair construction")
    return {
        "boundary_candidate_projections": boundary_cases,
        "mutual_candidate_projections": mutual_cases,
        "inactive_boundary_preserves_every_choice": True,
        "actual_geometric_core_widening": True,
        "full_domain_unsat_preserved": True,
        "zero_allowance_refuses": True,
    }


if __name__ == "__main__":
    print(json.dumps(run(), sort_keys=True))
