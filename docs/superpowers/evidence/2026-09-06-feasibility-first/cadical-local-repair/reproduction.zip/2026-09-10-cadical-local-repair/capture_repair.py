"""Throwaway capture of the neighborhood incumbent; not an original gate."""

from __future__ import annotations

import hashlib
import json
import time
from dataclasses import asdict
from pathlib import Path
from unittest.mock import patch

from pydantic import BaseModel, TypeAdapter

from . import template_cadical as selector
from .family_cnf import FactorCNF
from .neighborhood import Neighborhood
from .template_budget import ExperimentRefusal, WorkBudget, WorkKind
from .template_paths import TemplateProblem

ROOT = Path(__file__).parent
BASELINE = ROOT.parent / "2026-09-09-cadical-neighborhood"
PROBLEM = ROOT.parent / "2026-09-09-cadical-interface-static/problem.json"


class Incumbent(BaseModel):
    selected: list[int]
    retained: list[int]
    conflicts: list[tuple[int, int]]
    work: dict[WorkKind, int]


class Capture(BaseModel):
    scope: str = "Saved-problem diagnostic; no original-gate or rate acceptance claim"
    problem_sha256: str
    source_sha256: dict[str, str]
    outcome: str
    reason: str | None
    incumbents: list[Incumbent]
    final_work: dict[WorkKind, int]


def capture() -> Capture:
    hashes = {f.name: hashlib.sha256(f.read_bytes()).hexdigest() for f in BASELINE.glob("*.py")}
    assert all(
        hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest
        for name, digest in hashes.items()
    )
    problem = TypeAdapter(TemplateProblem).validate_json(PROBLEM.read_text())
    snapshots: list[Incumbent] = []

    class CapturedNeighborhood(Neighborhood):
        def consider(
            self, selected: list[int], conflicts: list[tuple[int, int]], factors: FactorCNF
        ) -> None:
            before = self.best_conflicts
            super().consider(selected, conflicts, factors)
            if self.best_conflicts != before:
                snapshots.append(
                    Incumbent(
                        selected=list(selected),
                        retained=sorted(self.retained),
                        conflicts=list(conflicts),
                        work=dict(self.budget.counts),
                    )
                )

    budget = WorkBudget(time.monotonic() + 60)
    stats = selector.SolveStats()
    outcome, reason = "GEOMETRY_COMPLETE", None
    try:
        with patch.object(selector, "Neighborhood", CapturedNeighborhood):
            selector.select(problem, budget, stats)
    except ExperimentRefusal as error:
        outcome, reason = error.reason, error.detail
    assert hashes == {
        f.name: hashlib.sha256(f.read_bytes()).hexdigest() for f in BASELINE.glob("*.py")
    }
    result = Capture(
        problem_sha256=hashlib.sha256(PROBLEM.read_bytes()).hexdigest(),
        source_sha256=hashes,
        outcome=outcome,
        reason=reason,
        incumbents=snapshots,
        final_work=dict(budget.counts),
    )
    (ROOT / "capture.json").write_text(result.model_dump_json(indent=2) + "\n")
    (ROOT / "capture-stats.json").write_text(json.dumps(asdict(stats), indent=2) + "\n")
    return result


if __name__ == "__main__":
    result = capture()
    print(
        json.dumps(
            {
                "outcome": result.outcome,
                "incumbents": len(result.incumbents),
                "best_conflicts": len(result.incumbents[-1].conflicts),
                "retained": len(result.incumbents[-1].retained),
                "paths": len(result.incumbents[-1].selected),
                "work": result.final_work,
            }
        )
    )
