"""Independently audit the captured incumbent and every retained pair."""

import hashlib
import json
import time
from pathlib import Path

from pydantic import TypeAdapter

from .capture_repair import PROBLEM, Capture
from .local_repair import audit
from .template_budget import WorkBudget
from .template_paths import TemplateProblem, domains

ROOT = Path(__file__).parent


def run() -> dict[str, int | bool]:
    capture = Capture.model_validate_json((ROOT / "capture.json").read_text())
    assert hashlib.sha256(PROBLEM.read_bytes()).hexdigest() == capture.problem_sha256
    problem = TypeAdapter(TemplateProblem).validate_json(PROBLEM.read_text())
    best = capture.incumbents[-1]
    budget = WorkBudget(time.monotonic() + 60)
    ds = domains(problem, budget)
    actual = audit(problem, ds, best.selected, budget)
    assert actual == best.conflicts
    held = set(best.retained)
    assert all(not (i in held and j in held) for i, j in actual)
    assert len(best.retained) == len(held)
    result = {
        "paths": len(ds),
        "canonical_conflicts": len(actual),
        "retained": len(held),
        "free": len(ds) - len(held),
        "canonical_graph_agrees": True,
        "all_paths_self_and_static_valid": True,
        "retained_pairwise_compatible": True,
    }
    (ROOT / "capture-audit.json").write_text(
        json.dumps({"result": result, "work": budget.counts}, indent=2) + "\n"
    )
    return result


if __name__ == "__main__":
    print(json.dumps(run(), sort_keys=True))
