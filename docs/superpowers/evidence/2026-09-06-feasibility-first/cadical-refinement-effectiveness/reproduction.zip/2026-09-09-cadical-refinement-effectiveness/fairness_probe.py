"""Optimistic diagnostic: oldest unresolved collisions first, same exact cuts.
Complete-graph scheduling work is recorded separately, not original acceptance.
"""
import ast
import importlib
import inspect
import json
import time
from dataclasses import asdict
from itertools import combinations
from pathlib import Path

from pydantic import TypeAdapter

ROOT = Path(__file__).parent
NAME = '2026-09-09-cadical-canonical-cuts'
module = importlib.import_module(NAME + '.template_cadical')
paths = importlib.import_module(NAME + '.template_paths')
problem = TypeAdapter(paths.TemplateProblem).validate_json(
    (ROOT.parent / '2026-09-09-cadical-interface-static/problem.json').read_text())
ages: dict[tuple[int, int], int] = {}
models = []
analysis_work: dict[str, int] = {}

def ordered_pairs(occupied, geometries):
    diagnostic = module.WorkBudget(time.monotonic() + 60)
    pairs = list(combinations(range(len(occupied)), 2))
    edges = set()
    for i, j in pairs:
        diagnostic.charge('predicates')
        if any(not paths._owned(geometries[i].path, geometries[j].path, cell, diagnostic)
               for cell in occupied[i] & occupied[j]):
            edges.add((i, j))
    for pair in pairs:
        ages[pair] = ages.get(pair, 0) + 1 if pair in edges else 0
    models.append({'round': len(models) + 1, 'conflicts': len(edges),
                   'maximum_conflict_age': max(ages.values(), default=0)})
    for key, value in diagnostic.counts.items():
        analysis_work[key] = analysis_work.get(key, 0) + value
    return sorted(pairs, key=lambda pair: (-ages[pair], pair))

module.__dict__['_ordered_pairs'] = ordered_pairs
source = inspect.getsource(module.select)
needle = 'for i, j in combinations(range(len(ds)), 2):'
assert source.count(needle) == 1
source = source.replace(needle, 'for i, j in _ordered_pairs(occupied, geometries):')
exec(compile(ast.parse(source), '<fair-refinement-counterfactual>', 'exec'), module.__dict__)
budget = module.WorkBudget(time.monotonic() + 60)
stats = module.SolveStats()
try:
    module.select(problem, budget, stats)
    outcome, reason = 'GEOMETRY_COMPLETE', None
except module.ExperimentRefusal as error:
    outcome, reason = error.reason, error.detail
report = {'scope': 'optimistic diagnostic; scheduling work external, never acceptance',
          'policy': 'descending consecutive collision age, canonical pair tie-break',
          'outcome': outcome, 'reason': reason, 'solver_work': budget.counts,
          'external_graph_work': analysis_work, 'stats': asdict(stats), 'models': models}
(ROOT / 'fairness-counterfactual.json').write_text(json.dumps(report, indent=2))
print(json.dumps({k:v for k,v in report.items() if k not in ['stats','models']}))
print('rounds', stats.rounds, 'cuts', stats.collision_cuts, 'conflicts', [r['conflicts'] for r in models])
