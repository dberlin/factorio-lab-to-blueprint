"""Throwaway diagnostic: capture immutable selector transitions, not acceptance."""
import ast
import hashlib
import importlib
import inspect
import json
import time
from dataclasses import asdict
from pathlib import Path

from pydantic import TypeAdapter

ROOT = Path(__file__).parent
NAME = '2026-09-09-cadical-canonical-cuts'
module = importlib.import_module(NAME + '.template_cadical')
paths = importlib.import_module(NAME + '.template_paths')
source_root = ROOT.parent / NAME
before = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in source_root.glob('*.py')}
problem = TypeAdapter(paths.TemplateProblem).validate_json(
    (ROOT.parent / '2026-09-09-cadical-interface-static/problem.json').read_text()
)
models = []
families = []

def capture_model(selected, ds, stats, budget):
    models.append({'round': stats.rounds, 'selected': list(selected),
                   'predicates': budget.counts.get('predicates', 0),
                   'cuts_before': stats.collision_cuts})
    if len(models) == 1:
        (ROOT / 'domains.json').write_text(json.dumps([
            {'ordinal': d.obligation.ordinal, 'levels': d.levels,
             'xy_count': len(d.lengths), 'shapes': d.shapes} for d in ds]))

def capture_family(i, j, family):
    families.append({'round': len(models), 'left': i, 'right': j,
                     'family': asdict(family)})

module.__dict__['_capture_model'] = capture_model
module.__dict__['_capture_family'] = capture_family
lines = []
inserted = 0
for line in inspect.getsource(module.select).splitlines():
    lines.append(line)
    indent = line[:len(line) - len(line.lstrip())]
    if line.strip() == 'selected = factors.select(model)':
        lines.append(indent + '_capture_model(selected, ds, stats, budget)')
        inserted += 1
    if line.strip().startswith('family = primitive_indexes[i].family('):
        lines.append(indent + '_capture_family(i, j, family)')
        inserted += 1
assert inserted == 2
exec(compile(ast.parse('\n'.join(lines)), '<refinement-capture>', 'exec'), module.__dict__)
budget = module.WorkBudget(time.monotonic() + 60)
stats = module.SolveStats()
try:
    module.select(problem, budget, stats)
    outcome, reason = 'GEOMETRY_COMPLETE', None
except module.ExperimentRefusal as error:
    outcome, reason = error.reason, error.detail
finally:
    after = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in source_root.glob('*.py')}
    assert before == after
    (ROOT / 'transitions.json').write_text(json.dumps({'models': models, 'families': families}))
report = {'scope': 'diagnostic only; no acceptance claim', 'revision': NAME,
          'outcome': outcome, 'reason': reason, 'models': len(models),
          'captured_families': len(families), 'work': budget.counts,
          'stats': asdict(stats), 'source_hashes': before}
(ROOT / 'capture-report.json').write_text(json.dumps(report, indent=2))
print(json.dumps({key: report[key] for key in ['outcome', 'reason', 'models', 'captured_families', 'work']}))
