"""Optimistic diagnostic ONLY: precomputed legal-height proposal as SAT phase hints.
Proposal generation is outside this replay. No gate or end-to-end claim is valid.
"""
import ast
import importlib
import inspect
import json
import sys
import time
from dataclasses import asdict
from pathlib import Path

from pydantic import TypeAdapter

ROOT = Path(__file__).parent
NAME = '2026-09-09-cadical-canonical-cuts'
module = importlib.import_module(NAME + '.template_cadical')
paths = importlib.import_module(NAME + '.template_paths')
problem = TypeAdapter(paths.TemplateProblem).validate_json(
    (ROOT.parent / '2026-09-09-cadical-interface-static/problem.json').read_text())
proposal = json.loads((ROOT / 'height-counterfactual.json').read_text())
models = []
assume = '--assume' in sys.argv

def guide(solver, factors):
    phases = []
    for i, ci in enumerate(proposal['selected']):
        xy, z = divmod(ci, len(factors.height[i]))
        phases.extend(v if k == xy else -v for k, v in enumerate(factors.xy[i]))
        phases.extend(v if k == z else -v for k, v in enumerate(factors.height[i]))
    if assume:
        module.__dict__['_proposal_assumptions'] = [v for v in phases if v > 0]
    else:
        solver.set_phases(phases)

def capture(selected, stats):
    models.append({'round': stats.rounds, 'selected': list(selected)})

module.__dict__['_guide'] = guide
module.__dict__['_capture'] = capture
lines = []
inserted = 0
for line in inspect.getsource(module.select).splitlines():
    indent = line[:len(line) - len(line.lstrip())]
    if line.strip() == 'stats.preparation_seconds = time.monotonic() - stats.started':
        lines.append(indent + '_guide(solver, factors)')
        inserted += 1
    if assume and line.strip() == 'status = solver.solve_limited()':
        line = indent + 'status = solver.solve_limited(assumptions=_proposal_assumptions if stats.rounds == 1 else [])'
    lines.append(line)
    if line.strip() == 'selected = factors.select(model)':
        lines.append(indent + '_capture(selected, stats)')
        inserted += 1
assert inserted == 2
exec(compile(ast.parse('\n'.join(lines)), '<phase-counterfactual>', 'exec'), module.__dict__)
budget = module.WorkBudget(time.monotonic() + 60)
stats = module.SolveStats()
try:
    module.select(problem, budget, stats)
    outcome, reason = 'GEOMETRY_COMPLETE', None
except module.ExperimentRefusal as error:
    outcome, reason = error.reason, error.detail
report = {'scope': 'optimistic diagnostic; externally generated proposal, not acceptance',
          'proposal_method': 'first-round-only assumptions' if assume else 'phase hints',
          'outcome': outcome, 'reason': reason, 'work_excluding_proposal': budget.counts,
          'stats': asdict(stats), 'models': models,
          'first_model_matches_proposal': models[0]['selected'] == proposal['selected']}
filename = 'assumption-counterfactual.json' if assume else 'phase-counterfactual.json'
(ROOT / filename).write_text(json.dumps(report, indent=2))
print(json.dumps({k:v for k,v in report.items() if k not in ['models','stats']}))
print('rounds', stats.rounds, 'cuts', stats.collision_cuts, 'families', stats.families)
