"""Offline proof census: two exact primitive relations can forbid all heights."""
import importlib
import json
import time
from collections import Counter
from itertools import combinations
from pathlib import Path

from pydantic import TypeAdapter

ROOT = Path(__file__).parent
NAME = '2026-09-09-cadical-canonical-cuts'
paths = importlib.import_module(NAME + '.template_paths')
geom = importlib.import_module(NAME + '.family_geometry')
cadical = importlib.import_module(NAME + '.template_cadical')
problem = TypeAdapter(paths.TemplateProblem).validate_json(
    (ROOT.parent / '2026-09-09-cadical-interface-static/problem.json').read_text())
preparation = cadical.WorkBudget(time.monotonic() + 60)
ds = paths.domains(problem, preparation)
indexes = [geom.PrimitiveIndex(d, preparation) for d in ds]
t = json.loads((ROOT / 'transitions.json').read_text())
cache = {}
rows = []
for event in t['families']:
    i, j = event['left'], event['right']
    ids = t['models'][event['round'] - 1]['selected']
    ca, a = divmod(ids[i], len(ds[i].levels))
    cb, b = divmod(ids[j], len(ds[j].levels))
    key = i, ca, j, cb
    if key not in cache:
        # Each pair is an independent diagnostic oracle, not reset solver accounting.
        budget = cadical.WorkBudget(time.monotonic() + 60)
        left, right = indexes[i], indexes[j]
        owners = left.owners(right, budget)
        nl, nr = len(ds[i].levels), len(ds[j].levels)
        full = (1 << (nl * nr)) - 1
        relations = []
        for ai in left.combos[ca]:
            for bi in right.combos[cb]:
                rects = geom.relation(left.primitives[ai], right.primitives[bi],
                                      ds[i].levels, ds[j].levels, owners, budget)
                bits = 0
                for lo, hi, start, end in rects:
                    for z in range(lo, hi + 1):
                        bits |= ((1 << (end - start + 1)) - 1) << (z * nr + start)
                if bits:
                    relations.append((ai, bi, bits, len(rects)))
        union = 0
        for relation in relations:
            union |= relation[2]
        proof = None
        for x, y in combinations(relations, 2):
            if x[2] != full and y[2] != full and x[2] | y[2] == full:
                lm = left.masks[x[0]] & left.masks[y[0]]
                rm = right.masks[x[1]] & right.masks[y[1]]
                assert lm & (1 << ca) and rm & (1 << cb)
                proof = {'left_primitives': [x[0], y[0]], 'right_primitives': [x[1], y[1]],
                         'kinds': [left.primitives[x[0]].kind + right.primitives[x[1]].kind,
                                   left.primitives[y[0]].kind + right.primitives[y[1]].kind],
                         'height_pairs_per_relation': [x[2].bit_count(), y[2].bit_count()],
                         'separate_rectangle_count': x[3] + y[3],
                         'combined_rectangle_count': 1,
                         'left_mask': lm, 'right_mask': rm,
                         'covered_xy_pairs': lm.bit_count() * rm.bit_count()}
                break
        cache[key] = {'pair': [i, j], 'xy': [ca, cb], 'all_heights_forbidden': union == full,
                      'single_full_relation': any(r[2] == full for r in relations),
                      'two_relation_proof': proof, 'relation_work': budget.counts}
    row = cache[key]
    rows.append({'round': event['round'], 'pair': [i, j], 'xy': [ca, cb],
                 'all_heights_forbidden': row['all_heights_forbidden'],
                 'single_full_relation': row['single_full_relation'],
                 'two_relation_closure': row['two_relation_proof'] is not None})
summary = {'scope': 'solver-free exact relation-closure census, not acceptance',
           'events': len(rows), 'unique_xy_pairs': len(cache),
           'all_height_forbidden_events': sum(r['all_heights_forbidden'] for r in rows),
           'single_relation_full_events': sum(r['single_full_relation'] for r in rows),
           'two_relation_closure_events': sum(r['two_relation_closure'] for r in rows),
           'two_relation_unique_xy_pairs': sum(r['two_relation_proof'] is not None for r in cache.values()),
           'by_round': dict(Counter(r['round'] for r in rows if r['two_relation_closure'])),
           'proof_kind_pairs': dict(Counter('/'.join(r['two_relation_proof']['kinds']) for r in cache.values() if r['two_relation_proof'])),
           'preparation_work': preparation.counts}
(ROOT / 'closure-proofs.json').write_text(json.dumps(list(cache.values())))
(ROOT / 'closure-events.json').write_text(json.dumps(rows))
(ROOT / 'closure-summary.json').write_text(json.dumps(summary, indent=2))
print(json.dumps(summary))
