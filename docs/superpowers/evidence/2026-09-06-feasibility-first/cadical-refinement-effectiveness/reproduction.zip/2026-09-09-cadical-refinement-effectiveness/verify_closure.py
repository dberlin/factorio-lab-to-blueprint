"""Independent cell-expansion proof of captured two-relation height contradictions."""
import importlib
import json
import time
from pathlib import Path

from pydantic import TypeAdapter

ROOT = Path(__file__).parent
NAME = '2026-09-09-cadical-canonical-cuts'
paths = importlib.import_module(NAME + '.template_paths')
geom = importlib.import_module(NAME + '.family_geometry')
cadical = importlib.import_module(NAME + '.template_cadical')
problem = TypeAdapter(paths.TemplateProblem).validate_json(
    (ROOT.parent / '2026-09-09-cadical-interface-static/problem.json').read_text())
budget = cadical.WorkBudget(time.monotonic() + 60)
ds = paths.domains(problem, budget)
indexes = [geom.PrimitiveIndex(d, budget) for d in ds]
proofs = json.loads((ROOT / 'closure-proofs.json').read_text())
comparisons = verified = 0
for record in proofs:
    proof = record['two_relation_proof']
    if proof is None:
        continue
    i, j = record['pair']
    left, right = indexes[i], indexes[j]
    owners = left.owners(right, budget)
    for index, key, ids in [(left, 'left_mask', proof['left_primitives']),
                            (right, 'right_mask', proof['right_primitives'])]:
        mask = proof[key]
        while mask:
            bit = mask & -mask
            combo = bit.bit_length() - 1
            assert all(pid in index.combos[combo] for pid in ids)
            mask ^= bit
    expanded = []
    for index, ids in [(left, proof['left_primitives']), (right, proof['right_primitives'])]:
        by_height = []
        for height in index.domain.levels:
            raw = []
            for pid in ids:
                segment = index.primitives[pid].at(height, budget)
                raw.append(set(cadical.cells((segment.lo, segment.hi))))
            by_height.append(raw)
        expanded.append(by_height)
    for a in expanded[0]:
        for b in expanded[1]:
            assert (a[0] & b[0]) - owners or (a[1] & b[1]) - owners
            comparisons += 1
    verified += 1
report = {'method': 'independent raw cell expansion; no relation() calls',
          'verified_two_relation_proofs': verified, 'height_pair_comparisons': comparisons,
          'membership_intersections_verified': True, 'false_exclusions': 0}
(ROOT / 'closure-verification.json').write_text(json.dumps(report, indent=2))
print(json.dumps(report))
