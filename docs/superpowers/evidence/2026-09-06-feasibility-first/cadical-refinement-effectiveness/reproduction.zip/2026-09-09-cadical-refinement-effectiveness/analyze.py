"""Offline expanded-geometry analysis of saved models; never gate acceptance."""
import importlib
import json
import time
from collections import Counter
from itertools import combinations
from pathlib import Path

from pydantic import TypeAdapter

ROOT = Path(__file__).parent
NAME = '2026-09-09-cadical-canonical-cuts'
paths = importlib.import_module(NAME + '.template_paths')
cadical = importlib.import_module(NAME + '.template_cadical')
data = json.loads((ROOT / 'transitions.json').read_text())
problem = TypeAdapter(paths.TemplateProblem).validate_json(
    (ROOT.parent / '2026-09-09-cadical-interface-static/problem.json').read_text()
)
ds = paths.domains(problem, cadical.WorkBudget(time.monotonic() + 60))
rows = []
graphs = []
previous = set()
previous_ids = None
learned = []
seen_pairs = set()
for entry in data['models']:
    # Each saved snapshot has a fresh diagnostic allowance, not a solver run.
    budget = cadical.WorkBudget(time.monotonic() + 60)
    ids = entry['selected']
    geo = [d._decode(ci, budget) for d, ci in zip(ds, ids, strict=True)]
    occupied = []
    for g in geo:
        seq = list(cadical.cells(g.path.points))
        budget.charge('audit_cells', len(seq))
        occupied.append(set(seq))
    edges = set()
    witnesses = {}
    for i, j in combinations(range(len(ds)), 2):
        budget.charge('predicates')
        cell = next((cell for cell in sorted(occupied[i] & occupied[j])
                     if not paths._owned(geo[i].path, geo[j].path, cell, budget)), None)
        if cell is not None:
            edges.add((i, j))
            witnesses[f'{i},{j}'] = cell
    # Every previously learned primitive family must be satisfied by this model.
    for event in learned:
        i, j, f = event['left'], event['right'], event['family']
        ca, a = divmod(ids[i], len(ds[i].levels))
        cb, b = divmod(ids[j], len(ds[j].levels))
        assert not (f['left_mask'] & (1 << ca) and f['right_mask'] & (1 << cb)
                    and any(lo <= a <= hi and start <= b <= end
                            for lo, hi, start, end in f['rectangles']))
    events = [f for f in data['families'] if f['round'] == entry['round']]
    batch = {(f['left'], f['right']) for f in events}
    assert batch <= edges
    degrees = Counter(v for edge in edges for v in edge)
    batch_vertices = {v for edge in batch for v in edge}
    changed_xy = changed_z = height_only = 0
    if previous_ids is not None:
        for d, old, new in zip(ds, previous_ids, ids, strict=True):
            ox, oz = divmod(old, len(d.levels))
            nx, nz = divmod(new, len(d.levels))
            changed_xy += ox != nx
            changed_z += oz != nz
            height_only += ox == nx and oz != nz
    prior_batch = {(f['left'], f['right']) for f in learned if f['round'] == entry['round'] - 1}
    row = {'round': entry['round'], 'edges': len(edges), 'conflicted_paths': len(degrees),
           'maximum_degree': max(degrees.values(), default=0), 'batch_pairs': len(batch),
           'batch_covers_edges': sum(i in batch_vertices or j in batch_vertices for i, j in edges),
           'prior_batch_still_conflicting': len(edges & prior_batch),
           'ever_learned_pairs_still_conflicting': len(edges & seen_pairs),
           'persistent_edges': len(edges & previous), 'new_edges': len(edges - previous),
           'changed_xy': changed_xy, 'changed_height': changed_z, 'height_only': height_only,
           'height_counts': dict(Counter(ds[i].levels[ci % len(ds[i].levels)] for i, ci in enumerate(ids))),
           'predicates_before': entry['predicates'], 'cuts_before': entry['cuts_before'],
           'graph_diagnostic_work': budget.counts}
    rows.append(row)
    graphs.append({'round': entry['round'], 'edges': sorted(edges), 'cells': witnesses})
    learned.extend(events)
    seen_pairs.update(batch)
    previous, previous_ids = edges, ids
pair_counts = Counter((f['left'], f['right']) for f in data['families'])
summary = {'scope': 'offline diagnostic; complete saved-model conflict graphs, not acceptance',
           'rounds': rows, 'captured_families': len(data['families']),
           'unique_learned_domain_pairs': len(pair_counts),
           'repeated_pair_learning_events': sum(c - 1 for c in pair_counts.values()),
           'most_relearned_pairs': [(list(pair), n) for pair, n in pair_counts.most_common(10)],
           'all_prior_families_satisfied': True}
(ROOT / 'graphs.json').write_text(json.dumps(graphs))
(ROOT / 'analysis.json').write_text(json.dumps(summary, indent=2))
print('round edges batch persistent new XY-change height-only prior-batch-still-bad heights')
for r in rows:
    print(r['round'], r['edges'], r['batch_pairs'], r['persistent_edges'], r['new_edges'],
          r['changed_xy'], r['height_only'], r['prior_batch_still_conflicting'], r['height_counts'])
print('pair learning:', summary['unique_learned_domain_pairs'], summary['repeated_pair_learning_events'])
