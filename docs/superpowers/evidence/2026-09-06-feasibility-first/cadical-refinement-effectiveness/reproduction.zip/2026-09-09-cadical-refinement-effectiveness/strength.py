"""Offline exact-witness strength census; no solver or frozen-source changes."""
import importlib
import json
import time
from collections import Counter
from pathlib import Path

from pydantic import TypeAdapter

ROOT = Path(__file__).parent
NAME = '2026-09-09-cadical-canonical-cuts'
paths = importlib.import_module(NAME + '.template_paths')
geom = importlib.import_module(NAME + '.family_geometry')
cadical = importlib.import_module(NAME + '.template_cadical')
problem = TypeAdapter(paths.TemplateProblem).validate_json(
    (ROOT.parent / '2026-09-09-cadical-interface-static/problem.json').read_text())
budget = cadical.WorkBudget(time.monotonic() + 60)
ds = paths.domains(problem, budget)
indexes = [geom.PrimitiveIndex(d, budget) for d in ds]
t = json.loads((ROOT / 'transitions.json').read_text())
rows = []
for event in t['families']:
    i, j = event['left'], event['right']
    ids = t['models'][event['round'] - 1]['selected']
    ca, a = divmod(ids[i], len(ds[i].levels))
    cb, b = divmod(ids[j], len(ds[j].levels))
    left, right = indexes[i], indexes[j]
    owners = left.owners(right, budget)
    first = left.witness(right, ca, cb, a, b, owners, budget)
    assert first is not None
    first_kind = left.primitives[first[0]].kind + right.primitives[first[1]].kind
    # Look for a simultaneously violated fixed/fixed relation, exact at every height.
    fixed = []
    for ai in left.combos[ca]:
        ap = left.primitives[ai]
        if ap.kind != 'G':
            continue
        for bi in right.combos[cb]:
            bp = right.primitives[bi]
            if bp.kind == 'G' and geom._forbidden(ap.at(ds[i].levels[a], budget),
                                                  bp.at(ds[j].levels[b], budget), owners, budget):
                fixed.append((ai, bi))
    rows.append({'round': event['round'], 'pair': [i, j], 'first_kind': first_kind,
                 'rectangles': len(event['family']['rectangles']),
                 'forbidden_height_pairs': sum((hi-lo+1)*(end-start+1)
                   for lo,hi,start,end in event['family']['rectangles']),
                 'fixed_fixed_witnesses_available': len(fixed)})
report = {'scope': 'offline exact witness census, not acceptance', 'events': rows,
          'first_kinds': dict(Counter(r['first_kind'] for r in rows)),
          'missed_fixed_fixed': sum(r['first_kind'] != 'GG' and bool(r['fixed_fixed_witnesses_available']) for r in rows),
          'work': budget.counts}
(ROOT / 'strength.json').write_text(json.dumps(report, indent=2))
print(json.dumps({k:v for k,v in report.items() if k!='events'}))
print('height-pair cardinalities',dict(Counter(r['forbidden_height_pairs'] for r in rows)))
