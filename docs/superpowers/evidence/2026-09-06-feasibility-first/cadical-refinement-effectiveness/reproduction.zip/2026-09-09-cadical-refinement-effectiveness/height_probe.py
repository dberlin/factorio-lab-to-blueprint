"""Solver-free counterfactual: fixed original XYs, exact legal heights only."""
import importlib
import json
import time
from collections import Counter
from itertools import combinations
from pathlib import Path

from pydantic import TypeAdapter

ROOT = Path(__file__).parent
NAME = '2026-09-09-cadical-canonical-cuts'
paths = importlib.import_module(NAME + '.template_paths')
cadical = importlib.import_module(NAME + '.template_cadical')
problem = TypeAdapter(paths.TemplateProblem).validate_json(
    (ROOT.parent / '2026-09-09-cadical-interface-static/problem.json').read_text()
)
initial = json.loads((ROOT / 'transitions.json').read_text())['models'][0]['selected']
initial_edges = json.loads((ROOT / 'graphs.json').read_text())[0]['edges']
budget = cadical.WorkBudget(time.monotonic() + 60)
ds = paths.domains(problem, budget)
fixed = paths._FixedIndex(problem, budget)
options = []
for d, original in zip(ds, initial, strict=True):
    xy = original // len(d.levels)
    valid = {}
    for z in range(len(d.levels)):
        g = d._decode(xy * len(d.levels) + z, budget)
        if paths._path_error(g, budget) or fixed.error(g, budget) is not None:
            continue
        cells = list(cadical.cells(g.path.points))
        budget.charge('audit_cells', len(cells))
        valid[z] = (g, set(cells))
    assert valid
    options.append(valid)
preparation_work = dict(budget.counts)

def collision(i, zi, j, zj):
    budget.charge('predicates')
    a, acells = options[i][zi]
    b, bcells = options[j][zj]
    return any(not paths._owned(a.path, b.path, cell, budget) for cell in acells & bcells)

# One predeclared policy, not a sweep: descending initial conflict degree;
# fewest conflicts against placed paths, then lowest legal height.
degree = Counter(v for edge in initial_edges for v in edge)
order = sorted(range(len(ds)), key=lambda i: (-degree[i], i))
selected = {}
for i in order:
    selected[i] = min(options[i], key=lambda zi: (
        sum(collision(i, zi, j, zj) for j, zj in selected.items()), ds[i].levels[zi]))
residual = [(i, j) for i, j in combinations(range(len(ds)), 2)
            if collision(i, selected[i], j, selected[j])]
# Independent canonical audit of every pair, not just the observed conflicts.
for i, j in combinations(range(len(ds)), 2):
    assert (not paths._compatible(options[i][selected[i]][0], options[j][selected[j]][0], budget)) == ((i, j) in residual)
result = {'scope': 'solver-free fixed-XY diagnostic; not original gate acceptance',
          'policy': 'descending initial degree; min placed conflicts then lowest legal height',
          'initial_edges': len(initial_edges), 'residual_edges': len(residual),
          'residual_pairs': residual, 'selected': [
              initial[i] // len(ds[i].levels) * len(ds[i].levels) + selected[i] for i in range(len(ds))],
          'height_counts': dict(Counter(ds[i].levels[z] for i, z in selected.items())),
          'unary_legal_height_counts': dict(Counter(len(v) for v in options)),
          'xy_routes_unchanged': True, 'canonical_all_pair_audit_matches': True,
          'preparation_work': preparation_work, 'total_diagnostic_work': dict(budget.counts)}
# Classify remaining collisions: can any legal height pair fix them with these XYs?
unavoidable = []
for i, j in residual:
    if all(collision(i, zi, j, zj) for zi in options[i] for zj in options[j]):
        unavoidable.append((i, j))
result['unavoidable_fixed_xy_pairs'] = unavoidable
result['total_diagnostic_work'] = dict(budget.counts)
(ROOT / 'height-counterfactual.json').write_text(json.dumps(result, indent=2))
print(json.dumps({k:v for k,v in result.items() if k not in ['selected', 'residual_pairs']}))
