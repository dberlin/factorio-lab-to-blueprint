"""Throwaway eager local geometry diagnostic; no production acceptance claim."""

from __future__ import annotations

import hashlib
import json
import time
from collections.abc import Iterator
from dataclasses import dataclass
from itertools import combinations
from pathlib import Path

from pydantic import BaseModel, Field, TypeAdapter
from pysat.solvers import Cadical195

from .capture_repair import PROBLEM, Capture
from .compact_boundary import ForbiddenChoices, height_runs, rejected_candidates, static_rows, words
from .family_cnf import FactorCNF, negative
from .family_geometry import Family, Primitive, PrimitiveIndex, _bound, relation
from .template_budget import ExperimentRefusal, WorkBudget, WorkKind
from .template_cadical import (
    CONFLICTS_PER_CALL,
    DECISIONS_PER_CALL,
    MAXIMUM_CLAUSES,
    MAXIMUM_COLLISION_CUTS,
    MAXIMUM_ROUNDS,
    CellIndex,
    DomainIndex,
    _identity_conflict,
    cells,
    entry_rejections,
    exclude_static_middles,
    members,
)
from .template_paths import (
    Cell,
    Domain,
    FixedPath,
    TemplateProblem,
    _compatible,
    _FixedIndex,
    _Geometry,
    _intersection,
    _owned,
    _path_error,
    _Segment,
    domains,
)

ROOT = Path(__file__).parent


class Ledger(BaseModel):
    stage: str = "initialization"
    clauses: int = 0
    collision_cuts: int = 0
    boundary_relations: int = 0
    boundary_cuts: int = 0
    boundary_domains_complete: int = 0
    static_rejected_candidates: int = 0
    static_domains_complete: int = 0
    boundary_raw_rectangles: int = 0
    boundary_groups: int = 0
    mutual_relations: int = 0
    mutual_pairs_complete: int = 0
    unary_candidates_complete: int = 0
    unary_rejections: int = 0
    broadphase_probes: int = 0
    native_calls: int = 0
    rebuilds: int = 0
    released: list[list[int]] = Field(default_factory=list)
    phases: list[dict[WorkKind, int]] = Field(default_factory=list)
    phase_names: list[str] = Field(default_factory=list)

    def phase(self, name: str, budget: WorkBudget) -> None:
        self.stage = name
        self.phase_names.append(name)
        self.phases.append(dict(budget.counts))


@dataclass(frozen=True)
class Descriptor:
    primitive: Primitive
    mask: int
    bounds: _Segment


def envelope(primitive: Primitive, levels: tuple[int, ...], budget: WorkBudget) -> _Segment:
    first, last = primitive.at(levels[0], budget), primitive.at(levels[-1], budget)
    budget.charge("predicates", 6)
    return _Segment(
        (min(first.lo[0], last.lo[0]), min(first.lo[1], last.lo[1]), min(first.lo[2], last.lo[2])),
        (max(first.hi[0], last.hi[0]), max(first.hi[1], last.hi[1]), max(first.hi[2], last.hi[2])),
    )


class Descriptors:
    def __init__(self, entries: list[Descriptor], budget: WorkBudget) -> None:
        budget.charge("predicates", len(entries) * max(1, len(entries).bit_length()))
        self.entries = sorted(entries, key=lambda entry: entry.bounds.lo[0])
        budget.charge("predicates", len(entries))
        self.starts = tuple(entry.bounds.lo[0] for entry in self.entries)

    def overlapping(
        self, bounds: _Segment, budget: WorkBudget, ledger: Ledger
    ) -> Iterator[Descriptor]:
        end = _bound(self.starts, bounds.hi[0], True, budget)
        for i in range(end):
            budget.charge("predicates")
            ledger.broadphase_probes += 1
            entry = self.entries[i]
            if _intersection(bounds, entry.bounds, budget) is not None:
                yield entry


def pair_owners(left: FixedPath, right: FixedPath, budget: WorkBudget) -> frozenset[Cell]:
    owners: set[Cell] = set()
    for endpoint in (left.source, left.sink):
        budget.charge("predicates")
        if _owned(left, right, endpoint.cell, budget):
            owners.add(endpoint.cell)
    return frozenset(owners)


def core_release(
    activations: dict[int, int], core: list[int] | None, budget: WorkBudget
) -> list[int]:
    """Literal -> retained domain. No core conservatively widens all holds."""
    budget.charge("predicates", len(activations))
    if not core:
        return list(activations.values())
    released: set[int] = set()
    for literal in core:
        budget.charge("predicates")
        if literal not in activations:
            raise AssertionError("core contains a non-retention assumption")
        released.add(activations[literal])
    budget.charge("predicates", len(released) * max(1, len(released).bit_length()))
    return sorted(released)


class LocalCompiler:
    def __init__(
        self,
        solver: Cadical195,
        free: tuple[Domain, ...],
        held: dict[int, _Geometry],
        budget: WorkBudget,
        ledger: Ledger,
    ) -> None:
        self.solver = solver
        self.free = free
        self.held = held
        self.budget = budget
        self.ledger = ledger
        self.starting_cuts = ledger.collision_cuts
        self.boundary_count = 0
        self.boundary_seen: set[tuple[int, ...]] = set()
        self.factors = FactorCNF(
            free, self.add_clause, budget, MAXIMUM_COLLISION_CUTS - ledger.collision_cuts
        )
        literals = self.factors.allocate(len(held))
        budget.charge("predicates", len(held))
        self.activations = dict(zip(literals, held, strict=True))
        self.by_domain = {domain: literal for literal, domain in self.activations.items()}
        self.indexes = [PrimitiveIndex(domain, budget) for domain in free]
        self.descriptors = [
            Descriptors(
                [
                    Descriptor(primitive, mask, envelope(primitive, index.domain.levels, budget))
                    for primitive, mask in zip(index.primitives, index.masks, strict=True)
                ],
                budget,
            )
            for index in self.indexes
        ]
        self.legal_rows: list[list[int]] = []
        self.live_xy: list[int] = []
        for domain in free:
            budget.charge("predicates", len(domain.levels) + max(1, len(domain.lengths) // 64 + 1))
            mask = (1 << len(domain.lengths)) - 1
            self.legal_rows.append([mask] * len(domain.levels))
            self.live_xy.append(mask)

    def prepare_static(self, problem: TemplateProblem) -> None:
        self.ledger.phase("exact-static-exclusions", self.budget)
        indexes = [CellIndex(domain, self.budget) for domain in self.free]
        domain_index = DomainIndex(indexes, self.budget)
        fixed_cells: list[set[Cell]] = []
        for path in problem.fixed_paths:
            occupied = set(cells(path.points))
            self.budget.charge("audit_cells", len(occupied))
            fixed_cells.append(occupied)
        rejected = entry_rejections(problem, indexes, fixed_cells, self.budget)
        exclude_static_middles(problem, indexes, domain_index, fixed_cells, rejected, self.budget)
        for local, (domain, mask) in enumerate(zip(self.free, rejected, strict=True)):
            self.budget.charge("candidates", domain.count)
            self.budget.charge("predicates", words(mask))
            self.ledger.static_rejected_candidates += mask.bit_count()
            for candidate in rejected_candidates(mask, self.budget):
                self.factors.exclude(local, candidate)
            rows = static_rows(mask, len(domain.lengths), len(domain.levels), self.budget)
            self.legal_rows[local] = rows
            live = 0
            for row in rows:
                self.budget.charge("predicates", words(row))
                live |= row
            self.live_xy[local] = live
            self.ledger.static_domains_complete += 1

    def add_clause(self, clause: list[int]) -> None:
        self.budget.check()
        if self.ledger.clauses >= MAXIMUM_CLAUSES:
            raise ExperimentRefusal("POLICY_BOUND", "CaDiCaL cumulative local clause cap")
        self.solver.add_clause(clause)
        self.ledger.clauses += 1

    def forbid_boundary(self, local: int, mask: int, lo: int, hi: int, activation: int) -> None:
        guard = self.factors.guard(local, mask)
        thresholds = self.factors.thresholds[local]
        clause = self.factors.simplify(
            [-activation, negative(guard), negative(thresholds[lo]), thresholds[hi + 1]]
        )
        if clause is None:
            raise AssertionError("nonempty boundary interval became tautological")
        self.budget.charge("predicates", 1 + len(clause))
        if clause in self.boundary_seen:
            return
        if self.ledger.collision_cuts >= MAXIMUM_COLLISION_CUTS:
            raise ExperimentRefusal("POLICY_BOUND", "CaDiCaL cumulative collision prohibition cap")
        self.add_clause(list(clause))
        self.boundary_seen.add(clause)
        self.boundary_count += 1
        self.ledger.collision_cuts += 1
        self.ledger.boundary_cuts += 1

    def boundary(self) -> None:
        self.ledger.phase("retained-boundary", self.budget)
        fixed: dict[int, Descriptors] = {}
        for domain, geometry in self.held.items():
            self.budget.charge("predicates", len(geometry.segments))
            fixed[domain] = Descriptors(
                [
                    Descriptor(Primitive("G", segment.lo, segment.hi), 1, segment)
                    for segment in geometry.segments
                ],
                self.budget,
            )
        for local, (index, descriptors) in enumerate(
            zip(self.indexes, self.descriptors, strict=True)
        ):
            for domain, geometry in self.held.items():
                self.budget.charge("predicates")
                owners = pair_owners(index.representative, geometry.path, self.budget)
                if _identity_conflict(index.representative, geometry.path, self.budget):
                    self.add_clause([-self.by_domain[domain]])
                    continue
                choices = ForbiddenChoices(
                    self.legal_rows[local], len(index.domain.lengths), self.budget
                )
                for left in descriptors.entries:
                    self.budget.charge("predicates", words(left.mask))
                    mask = left.mask & self.live_xy[local]
                    if not mask:
                        continue
                    heights = 0
                    for right in fixed[domain].overlapping(left.bounds, self.budget, self.ledger):
                        self.ledger.boundary_relations += 1
                        rectangles = relation(
                            left.primitive,
                            right.primitive,
                            index.domain.levels,
                            (0,),
                            owners,
                            self.budget,
                        )
                        for lo, hi, _, _ in rectangles:
                            self.budget.charge(
                                "predicates", 5 * max(1, len(index.domain.levels) // 64 + 1)
                            )
                            heights |= ((1 << (hi - lo + 1)) - 1) << lo
                            self.ledger.boundary_raw_rectangles += 1
                    choices.add(mask, heights)
                groups = choices.groups()
                self.ledger.boundary_groups += len(groups)
                for heights, mask in groups.items():
                    for lo, hi in height_runs(heights, self.budget):
                        self.forbid_boundary(local, mask, lo, hi, self.by_domain[domain])
            self.ledger.boundary_domains_complete += 1

    def mutual(self) -> None:
        self.ledger.phase("free-free", self.budget)
        self.factors.maximum_rectangles = MAXIMUM_COLLISION_CUTS - self.ledger.collision_cuts
        for i, j in combinations(range(len(self.free)), 2):
            self.budget.charge("predicates")
            left_index, right_index = self.indexes[i], self.indexes[j]
            if _identity_conflict(
                left_index.representative, right_index.representative, self.budget
            ):
                self.add_clause([])
                continue
            owners = left_index.owners(right_index, self.budget)
            for left in self.descriptors[i].entries:
                for right in self.descriptors[j].overlapping(left.bounds, self.budget, self.ledger):
                    self.ledger.mutual_relations += 1
                    rectangles = relation(
                        left.primitive,
                        right.primitive,
                        self.free[i].levels,
                        self.free[j].levels,
                        owners,
                        self.budget,
                    )
                    if rectangles:
                        try:
                            self.factors.forbid(i, j, Family(left.mask, right.mask, rectangles))
                        finally:
                            self.ledger.collision_cuts = (
                                self.starting_cuts + self.boundary_count + self.factors.rectangles
                            )
            self.ledger.mutual_pairs_complete += 1

    def unary(self, fixed: _FixedIndex) -> None:
        self.ledger.phase("self-static-legality", self.budget)
        for local, domain in enumerate(self.free):
            for height, allowed in enumerate(self.legal_rows[local]):
                for combo in members(allowed):
                    self.budget.charge("predicates", 4 * words(allowed))
                    candidate = combo * len(domain.levels) + height
                    geometry = domain._decode(candidate, self.budget)
                    if _path_error(geometry, self.budget) or fixed.error(geometry, self.budget):
                        self.factors.exclude(local, candidate)
                        self.ledger.unary_rejections += 1
                    self.ledger.unary_candidates_complete += 1


def audit(
    problem: TemplateProblem, ds: tuple[Domain, ...], selected: list[int], budget: WorkBudget
) -> list[tuple[int, int]]:
    if len(selected) != len(ds) or any(
        not 0 <= candidate < d.count for d, candidate in zip(ds, selected, strict=True)
    ):
        raise AssertionError("selection lies outside full original domains")
    fixed = _FixedIndex(problem, budget)
    geometry = [d._decode(candidate, budget) for d, candidate in zip(ds, selected, strict=True)]
    for path in geometry:
        assert _path_error(path, budget) is None
        assert fixed.error(path, budget) is None
    return [
        (i, j)
        for i, j in combinations(range(len(ds)), 2)
        if not _compatible(geometry[i], geometry[j], budget)
    ]


def repair(
    problem: TemplateProblem,
    selected: list[int],
    retained: list[int],
    budget: WorkBudget,
    ledger: Ledger,
) -> list[int]:
    ledger.phase("domains-and-retained-audit", budget)
    ds = domains(problem, budget)
    if len(selected) != len(ds) or any(
        not 0 <= candidate < d.count for d, candidate in zip(ds, selected, strict=True)
    ):
        raise AssertionError("invalid captured selection")
    if len(set(retained)) != len(retained) or any(not 0 <= i < len(ds) for i in retained):
        raise AssertionError("invalid retained domain list")
    fixed = _FixedIndex(problem, budget)
    held = {i: ds[i]._decode(selected[i], budget) for i in retained}
    for path in held.values():
        assert _path_error(path, budget) is None and fixed.error(path, budget) is None
    assert all(_compatible(a, b, budget) for a, b in combinations(held.values(), 2))
    while True:
        budget.charge("predicates", len(ds))
        free_ids = [i for i in range(len(ds)) if i not in held]
        free = tuple(ds[i] for i in free_ids)
        ledger.rebuilds += 1
        ledger.phase("factor-and-primitive-construction", budget)
        release: list[int] = []
        with Cadical195(use_timer=True) as solver:
            solver.configure({"seed": 0})
            compiler = LocalCompiler(solver, free, held, budget, ledger)
            compiler.prepare_static(problem)
            compiler.boundary()
            compiler.mutual()
            compiler.unary(fixed)
            ledger.phase("complete-local-solve", budget)
            budget.charge("predicates", len(compiler.activations))
            assumptions = list(compiler.activations)
            status = None
            while status is None:
                if ledger.native_calls >= MAXIMUM_ROUNDS:
                    raise ExperimentRefusal("POLICY_BOUND", "local native-call allowance exhausted")
                budget.charge("assignments")
                budget.charge("predicates", len(assumptions))
                solver.conf_budget(CONFLICTS_PER_CALL)
                solver.dec_budget(DECISIONS_PER_CALL)
                ledger.native_calls += 1
                status = solver.solve_limited(assumptions=assumptions)
                budget.check()
            if status:
                model = solver.get_model()
                if model is None:
                    raise AssertionError("SAT without a model")
                result = list(selected)
                for i, candidate in zip(free_ids, compiler.factors.select(model), strict=True):
                    result[i] = candidate
                ledger.phase("independent-whole-selection-audit", budget)
                assert not audit(problem, ds, result, budget)
                return result
            if not assumptions:
                raise ExperimentRefusal(
                    "LOCAL_DOMAIN_UNSAT",
                    "complete unrestricted original template domains are UNSAT",
                )
            release = core_release(compiler.activations, solver.get_core(), budget)
        if not release:
            raise AssertionError("restricted UNSAT failed to widen")
        ledger.released.append(release)
        for i in release:
            budget.charge("predicates")
            del held[i]


if __name__ == "__main__":
    capture = Capture.model_validate_json((ROOT / "capture.json").read_text())
    assert hashlib.sha256(PROBLEM.read_bytes()).hexdigest() == capture.problem_sha256
    best = capture.incumbents[-1]
    started = time.monotonic()
    budget = WorkBudget(started + 60)
    ledger = Ledger()
    problem = TypeAdapter(TemplateProblem).validate_json(PROBLEM.read_text())
    outcome, reason = "GEOMETRY_COMPLETE_LOCAL_DIAGNOSTIC", None
    selected: list[int] | None = None
    try:
        selected = repair(problem, best.selected, best.retained, budget, ledger)
    except ExperimentRefusal as error:
        outcome, reason = error.reason, error.detail
    result = {
        "scope": "Optimistic local-only diagnostic; capture cost excluded, not original gate",
        "outcome": outcome,
        "reason": reason,
        "elapsed_s": time.monotonic() - started,
        "budget_s": 60,
        "work": budget.counts,
        "initial_paths": len(best.selected),
        "initial_retained": len(best.retained),
        "initial_conflicts": len(best.conflicts),
        "ledger": ledger.model_dump(),
        "selected": selected,
        "original_factory_gate": False,
    }
    (ROOT / "local-result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(
        json.dumps(
            {key: value for key, value in result.items() if key not in ("ledger", "selected")}
        )
    )
    print(ledger.model_dump_json())
