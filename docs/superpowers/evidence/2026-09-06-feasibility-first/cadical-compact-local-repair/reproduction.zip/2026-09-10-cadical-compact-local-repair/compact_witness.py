"""Disposable set, static-filter and activation projection proofs."""

from __future__ import annotations

import json
import random
import time
from dataclasses import replace

from pysat.solvers import Cadical195

from .compact_boundary import ForbiddenChoices, height_runs, static_rows
from .local_repair import Ledger, LocalCompiler
from .local_repair_witness import problem_for
from .template_budget import ExperimentRefusal, WorkBudget, WorkLimits
from .template_paths import _compatible, _FixedIndex, domains


def run() -> dict[str, int | bool]:
    rng = random.Random(19)
    set_cases = 0
    for count, levels in ((7, 5), (130, 66)):
        for _ in range(32):
            budget = WorkBudget(time.monotonic() + 60)
            rejected = rng.getrandbits(count * levels)
            legal = static_rows(rejected, count, levels, budget)
            expected = [0] * count
            choices = ForbiddenChoices(legal, count, budget)
            for _ in range(8):
                mask, heights = rng.getrandbits(count), rng.getrandbits(levels)
                choices.add(mask, heights)
                for combo in range(count):
                    if mask & (1 << combo):
                        expected[combo] |= heights
            groups = choices.groups()
            actual = [0] * count
            seen = 0
            for heights, mask in groups.items():
                assert not seen & mask
                seen |= mask
                reconstructed = 0
                for lo, hi in height_runs(heights, budget):
                    reconstructed |= ((1 << (hi - lo + 1)) - 1) << lo
                assert reconstructed == heights
                for combo in range(count):
                    if mask & (1 << combo):
                        actual[combo] = heights
            for combo in range(count):
                allowed = ((1 << levels) - 1) & ~(rejected >> (combo * levels))
                assert actual[combo] == expected[combo] & allowed
            set_cases += 1

    projections = 0
    for shared in (False, True):
        problem = problem_for(shared=shared)
        problem = replace(
            problem,
            blocked=frozenset({(8, 0, 3), (6, 0, 5), problem.obligations[0].source.cell}),
            owned_endpoints=(problem.obligations[0].source,),
        )
        budget = WorkBudget(time.monotonic() + 60)
        ds = domains(problem, budget)
        geometry = [ds[0]._decode(candidate, budget) for candidate in range(ds[0].count)]
        held = {10: ds[1]._decode(0, budget), 20: ds[1]._decode(1, budget)}
        fixed = _FixedIndex(problem, budget)
        with Cadical195() as solver:
            ledger = Ledger()
            compiler = LocalCompiler(solver, (ds[0],), held, budget, ledger)
            compiler.prepare_static(problem)
            compiler.boundary()
            for active in range(4):
                activations = [
                    literal if active & (1 << k) else -literal
                    for k, literal in enumerate(compiler.activations)
                ]
                for candidate, path in enumerate(geometry):
                    combo, height = divmod(candidate, len(ds[0].levels))
                    permitted = fixed.error(path, budget) is None and all(
                        not active & (1 << k) or _compatible(path, peer, budget)
                        for k, peer in enumerate(held.values())
                    )
                    assumptions = [
                        *activations,
                        compiler.factors.xy[0][combo],
                        compiler.factors.height[0][height],
                    ]
                    assert solver.solve(assumptions=assumptions) == permitted
                    projections += 1
    try:
        ForbiddenChoices([1], 1, WorkBudget(time.monotonic() + 60, WorkLimits(predicates=0)))
    except ExperimentRefusal as error:
        assert error.reason == "POLICY_BOUND"
    else:
        raise AssertionError("compact construction escapes accounting")
    return {
        "set_equivalence_cases": set_cases,
        "static_and_independent_activation_projections": projections,
        "cross_word_masks": True,
        "merged_intervals_exact": True,
        "zero_work_refuses": True,
    }


if __name__ == "__main__":
    print(json.dumps(run(), sort_keys=True))
