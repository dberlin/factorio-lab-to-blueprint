"""Charged exact union of retained-boundary exclusions, before CNF emission."""

from __future__ import annotations

from collections.abc import Iterator

from .template_budget import WorkBudget


def words(mask: int) -> int:
    return max(1, (mask.bit_length() + 63) // 64)


def static_rows(rejected: int, combos: int, levels: int, budget: WorkBudget) -> list[int]:
    """Transpose original combo-major exclusions into legal XY masks per height."""
    budget.charge("predicates", levels + words(rejected))
    rows = [0] * levels
    height_mask = (1 << levels) - 1
    size = (combos * levels + 7) // 8
    budget.charge("predicates", size)
    encoded = rejected.to_bytes(size, "little")
    buffer = available = position = 0
    for combo in range(combos):
        while available < levels:
            budget.charge("predicates", 3 * words(buffer))
            buffer |= encoded[position] << available
            position += 1
            available += 8
        budget.charge("predicates", 3 * words(buffer))
        allowed = height_mask & ~buffer
        buffer >>= levels
        available -= levels
        bit = 1 << combo
        while allowed:
            budget.charge("predicates", 4 * words(allowed) + 2 * words(bit))
            lowest = allowed & -allowed
            rows[lowest.bit_length() - 1] |= bit
            allowed ^= lowest
    if buffer:
        raise AssertionError("static mask exceeds original candidate domain")
    return rows


def rejected_candidates(mask: int, budget: WorkBudget) -> Iterator[int]:
    """Walk fixed-size bytes rather than repeatedly shifting a full domain mask."""
    size = (mask.bit_length() + 7) // 8
    budget.charge("predicates", size + words(mask))
    for byte, value in enumerate(mask.to_bytes(size, "little")):
        while value:
            budget.charge("predicates", 5)
            lowest = value & -value
            yield byte * 8 + lowest.bit_length() - 1
            value ^= lowest


class ForbiddenChoices:
    def __init__(self, legal_rows: list[int], combos: int, budget: WorkBudget) -> None:
        budget.charge("predicates", len(legal_rows) + max(1, (combos + 63) // 64))
        self.budget = budget
        self.legal = legal_rows
        self.rows = [0] * len(legal_rows)
        self.full = (1 << combos) - 1
        self.width = max(1, (combos + 63) // 64)

    def add(self, mask: int, heights: int) -> None:
        while heights:
            self.budget.charge("predicates", 4 * words(heights) + 3 * self.width)
            lowest = heights & -heights
            height = lowest.bit_length() - 1
            self.rows[height] |= mask & self.legal[height]
            heights ^= lowest

    def groups(self) -> dict[int, int]:
        """Disjoint XY membership groups with identical nonempty height sets."""
        self.budget.charge("predicates", self.width)
        groups = {0: self.full}
        for height, row in enumerate(self.rows):
            self.budget.charge("predicates")
            if not row:
                continue
            next_groups: dict[int, int] = {}
            bit = 1 << height
            for heights, mask in groups.items():
                self.budget.charge("predicates", 4 * self.width + words(heights) + 4)
                inside, outside = mask & row, mask & ~row
                if outside:
                    next_groups[heights] = outside
                if inside:
                    next_groups[heights | bit] = inside
            groups = next_groups
        groups.pop(0, None)
        return groups


def height_runs(mask: int, budget: WorkBudget) -> Iterator[tuple[int, int]]:
    while mask:
        budget.charge("predicates", 7 * words(mask))
        lo = (mask & -mask).bit_length() - 1
        shifted = mask >> lo
        length = (shifted ^ (shifted + 1)).bit_length() - 1
        hi = lo + length - 1
        yield lo, hi
        mask &= ~(((1 << length) - 1) << lo)
