"""Throwaway independent feasibility probe; never modifies frozen selector sources."""

from __future__ import annotations

import argparse
import contextlib
import hashlib
import importlib
import io
import json
import signal
import sys
import tempfile
import time
import zipfile
from collections import defaultdict
from dataclasses import asdict, replace
from itertools import combinations
from pathlib import Path
from unittest.mock import patch

import pysat
from pydantic import TypeAdapter
from pysat.card import CardEnc, EncType
from pysat.solvers import Cadical195


class DiagnosticLimit(RuntimeError):
    pass


def cancel_alarm():
    # The one-shot alarm may already be pending when finalization disarms it.
    # Consume that deadline exception here so it cannot prevent evidence flush.
    try:
        signal.setitimer(signal.ITIMER_REAL, 0)
    except DiagnosticLimit:
        signal.setitimer(signal.ITIMER_REAL, 0)


def expand(points):
    result = [points[0]]
    for a, b in zip(points, points[1:], strict=False):
        axes = [i for i in range(3) if a[i] != b[i]]
        assert len(axes) == 1
        axis = axes[0]
        step = 1 if b[axis] > a[axis] else -1
        for value in range(a[axis] + step, b[axis] + step, step):
            point = list(a)
            point[axis] = value
            result.append(tuple(point))
    return result


def share(a, b, cell):
    if a.item != b.item:
        return False
    for ea, sa in ((a.source, True), (a.sink, False)):
        for eb, sb in ((b.source, True), (b.sink, False)):
            if ea.cell != cell or eb.cell != cell:
                continue
            if ea.port_id == eb.port_id:
                if sa != sb and ea.outward == (-eb.outward[0], -eb.outward[1]):
                    return True
            elif (
                ea.junction_id is not None
                and ea.junction_id == eb.junction_id
                and ea.outward != eb.outward
            ):
                return True
    return False


def port_conflict(a, b):
    return any(
        ea.port_id == eb.port_id and (ea.cell != eb.cell or not share(a, b, ea.cell))
        for ea in (a.source, a.sink)
        for eb in (b.source, b.sink)
    )


def conflict(a, acells, b, bcells):
    return port_conflict(a, b) or any(not share(a, b, cell) for cell in acells & bcells)


def static_valid(geometry, cells, problem, fixed_cells):
    path = geometry.path
    if len(cells) != len(set(cells)):
        return False
    if (
        path.points[0] != path.source.cell
        or path.points[-1] != path.sink.cell
        or path.source.port_id == path.sink.port_id
    ):
        return False
    for endpoint, near in ((path.source, path.points[1]), (path.sink, path.points[-2])):
        dx, dy = endpoint.outward
        if (dx, dy) not in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            return False
        if (
            near[2] != endpoint.cell[2]
            or (near[0] - endpoint.cell[0]) * dx + (near[1] - endpoint.cell[1]) * dy <= 0
        ):
            return False
    occupied = set(cells)
    owned = {e.cell for e in (path.source, path.sink) if e in problem.owned_endpoints}
    if (occupied - owned) & problem.blocked:
        return False
    return not any(
        conflict(path, occupied, fixed, f_cells)
        for fixed, f_cells in zip(problem.fixed_paths, fixed_cells, strict=True)
    )


def solve(problem, paths, work, policy, report, checkpoint):
    deadline = report["started_monotonic"] + policy["wall_seconds_including_preparation"]
    budget = work.WorkBudget(
        deadline,
        replace(
            work.WorkLimits(),
            predicates=policy["diagnostic_predicate_limit"],
            candidates=policy["diagnostic_candidate_limit"],
        ),
    )
    report["geometry_work"] = budget.counts
    domains = paths.domains(problem, budget)
    index = paths._FixedIndex(problem, budget)
    fixed_cells = [set(expand(p.points)) for p in problem.fixed_paths]
    choices = []
    postings = defaultdict(lambda: defaultdict(list))
    report["domains"] = []
    expanded = 0
    for di, domain in enumerate(domains):
        unique = {}
        candidates = []
        rejected = duplicates = 0
        for ci in domain._ids(budget):
            geometry = domain._decode(ci, budget)
            # Exact duplicate geometry has the same endpoints/item within this domain.
            key = geometry.path.points
            if key in unique:
                duplicates += 1
                continue
            cells = expand(key)
            expanded += len(cells)
            if expanded > policy["maximum_expanded_candidate_cells"]:
                raise DiagnosticLimit("expanded candidate cell allowance")
            actual = (
                paths._path_error(geometry, budget) is None
                and index.error(geometry, budget) is None
            )
            independent = static_valid(geometry, cells, problem, fixed_cells)
            if actual != independent:
                raise AssertionError(
                    (
                        "static geometry disagreement",
                        domain.obligation.ordinal,
                        ci,
                        actual,
                        independent,
                    )
                )
            if not actual:
                rejected += 1
                continue
            representative = len(candidates)
            unique[key] = representative
            candidates.append((ci, geometry))
            for cell in cells:
                postings[cell][di].append(representative)
        choices.append(candidates)
        report["domains"].append(
            {
                "ordinal": domain.obligation.ordinal,
                "enumerated": domain.count,
                "static_rejected": rejected,
                "exact_duplicates": duplicates,
                "retained": len(candidates),
            }
        )
        report["expanded_candidate_cells"] = expanded
        checkpoint("preparation")
    report["complete_domain_enumeration"] = True
    if any(not candidates for candidates in choices):
        report["outcome"] = "FROZEN_FAMILY_INFEASIBLE"
        report["reason"] = "A fully enumerated domain has no statically legal candidate."
        return None
    for i, j in combinations(range(len(domains)), 2):
        if port_conflict(choices[i][0][1].path, choices[j][0][1].path):
            report["outcome"] = "FROZEN_FAMILY_INFEASIBLE"
            report["reason"] = (
                "Two obligations have inconsistent immutable physical port identities."
            )
            report["port_conflict_ordinals"] = [
                domains[i].obligation.ordinal,
                domains[j].obligation.ordinal,
            ]
            return None
    candidate_count = sum(map(len, choices))
    variables = []
    next_id = 1
    for candidates in choices:
        variables.append(list(range(next_id, next_id + len(candidates))))
        next_id += len(candidates)
    # Reserve every candidate ID before the first auxiliary is allocated.
    # One monotone high-water mark is shared by domain and collision encodings.
    top_id = candidate_count
    solver = Cadical195(use_timer=True)
    solver.configure({"seed": policy["solver_random_seed"]})
    report["candidate_variables"] = candidate_count
    report["auxiliary_variables"] = 0
    report["solver_variables"] = candidate_count
    report["clauses_added"] = 0
    report["encoding_seconds"] = 0.0
    report["clause_addition_seconds"] = 0.0
    report["solver_seconds"] = 0.0

    def add_cardinality(literals, exactly_one=False):
        nonlocal top_id
        budget.check()
        encoding_started = time.monotonic()
        encode = CardEnc.equals if exactly_one else CardEnc.atmost
        encoded = encode(lits=literals, bound=1, top_id=top_id, encoding=EncType.seqcounter)
        top_id = max(top_id, encoded.nv)
        report["solver_variables"] = top_id
        report["auxiliary_variables"] = top_id - candidate_count
        report["encoding_seconds"] += time.monotonic() - encoding_started
        addition_started = time.monotonic()
        try:
            for index, clause in enumerate(encoded.clauses):
                if index % 1024 == 0:
                    budget.check()
                solver.add_clause(clause)
                report["clauses_added"] += 1
        finally:
            report["clause_addition_seconds"] += time.monotonic() - addition_started
        budget.check()

    for variables_for_domain in variables:
        add_cardinality(variables_for_domain, exactly_one=True)
    report["complete_domain_encoding"] = True
    cuts = set()
    report["rounds"] = []
    report["native_calls"] = []
    report["cuts"] = []
    report["domain_clauses"] = report["clauses_added"]
    report["preparation_seconds"] = time.monotonic() - report["started_monotonic"]
    for iteration in range(policy["maximum_rounds"]):
        budget.check()
        # Cadical195 has no PySAT interrupt implementation. These finite
        # conflict/decision budgets allow cooperative deadline checks, not a
        # wall-time guarantee: the parent process MUST enforce the hard deadline.
        # Replenishing a local budget continues this same live solver; it never
        # restarts the diagnostic or extends its absolute deadline/round bound.
        round_info = {
            "round": iteration,
            "status": "UNKNOWN",
            "wall_seconds": 0.0,
            "cuts_before": len(cuts),
            "clauses_before": report["clauses_added"],
            "auxiliary_variables_before": report["auxiliary_variables"],
            "native_calls": 0,
        }
        report["rounds"].append(round_info)
        status = None
        while status is None:
            budget.check()
            solver.conf_budget(policy["conflicts_per_call"])
            solver.dec_budget(policy["decisions_per_call"])
            call_info = {
                "call": len(report["native_calls"]),
                "round": iteration,
                "status": "UNKNOWN",
                "wall_seconds": 0.0,
                "native_call_pending": True,
            }
            report["native_calls"].append(call_info)
            round_info["native_calls"] += 1
            checkpoint("solving")
            call_started = time.monotonic()
            try:
                status = solver.solve_limited()
            finally:
                duration = time.monotonic() - call_started
                call_info["wall_seconds"] = duration
                round_info["wall_seconds"] += duration
                report["solver_seconds"] += duration
            status_name = "SAT" if status is True else "UNSAT" if status is False else "UNKNOWN"
            call_info.update(status=status_name, native_call_pending=False)
            round_info.update(status=status_name, cumulative_stats=solver.accum_stats())
            checkpoint("solving")
            budget.check()
        if status is False:
            assert report["complete_domain_enumeration"]
            assert report["complete_domain_encoding"]
            report["outcome"] = "FROZEN_FAMILY_INFEASIBLE"
            report["reason"] = (
                "CaDiCaL proved the fully enumerated exact-domain relaxation "
                "with sound collision exclusions infeasible."
            )
            return None
        if status is not True:
            raise AssertionError(("Unexpected CaDiCaL status", status))
        assignment = solver.get_model()
        if assignment is None:
            raise DiagnosticLimit("CaDiCaL SAT returned no model")
        positive = {literal for literal in assignment if literal > 0}
        selected_rows = [[ci for ci, var in enumerate(row) if var in positive] for row in variables]
        if any(len(row) != 1 for row in selected_rows):
            raise AssertionError("CaDiCaL model does not select exactly one candidate per domain")
        selected = [row[0] for row in selected_rows]
        selected_geometries = [
            candidates[ci][1] for candidates, ci in zip(choices, selected, strict=True)
        ]
        selected_cells = [set(expand(g.path.points)) for g in selected_geometries]
        new_cuts = 0
        for i, j in combinations(range(len(domains)), 2):
            budget.check()
            a, b = selected_geometries[i], selected_geometries[j]
            bad_cells = sorted(
                cell
                for cell in selected_cells[i] & selected_cells[j]
                if not share(a.path, b.path, cell)
            )
            assert paths._compatible(a, b, budget) == (not bad_cells)
            if not bad_cells:
                continue
            # One exact shared-cell exclusion also removes all other candidates
            # with the same unavoidable resource conflict, not just this pair.
            cell = bad_cells[0]
            occupants = postings[cell]
            can_share = any(
                share(choices[x][0][1].path, choices[y][0][1].path, cell)
                for x, y in combinations(occupants, 2)
            )
            owners = (i, j) if can_share else tuple(sorted(occupants))
            key = (cell, owners)
            if key in cuts:
                # A cut already added in this same round may cover many pairs.
                continue
            if len(cuts) == policy["maximum_collision_cuts"]:
                raise DiagnosticLimit("collision cut allowance")
            add_cardinality([variables[di][ci] for di in owners for ci in occupants[di]])
            cuts.add(key)
            new_cuts += 1
            report["cuts"].append(
                {
                    "cell": cell,
                    "ordinals": [domains[di].obligation.ordinal for di in owners],
                    "candidate_terms": sum(len(occupants[di]) for di in owners),
                }
            )
        if new_cuts:
            continue
        # With no new cut, an invalid relaxed witness would be a model bug.
        assert all(
            not conflict(a.path, selected_cells[i], b.path, selected_cells[j])
            for i, a in enumerate(selected_geometries)
            for j, b in enumerate(selected_geometries)
            if i < j
        )
        budget.check()
        report["outcome"] = "COMPLETE_TEMPLATE_GEOMETRY_WITNESS"
        report["selected_candidate_ids"] = {
            domain.obligation.ordinal: candidates[ci][0]
            for domain, candidates, ci in zip(domains, choices, selected, strict=True)
        }
        report["selected_points"] = {
            domain.obligation.ordinal: geometry.path.points
            for domain, geometry in zip(domains, selected_geometries, strict=True)
        }
        report["independent_selected_pairs"] = len(domains) * (len(domains) - 1) // 2
        return report["selected_points"]
    raise DiagnosticLimit("solver round allowance")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("archive", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    policy_source = Path(__file__).with_name("diagnostic-policy.json")
    policy = json.loads(policy_source.read_text())
    started = time.monotonic()
    report = {
        "outcome": "UNKNOWN",
        "diagnostic_only": True,
        "policy": policy,
        "policy_sha256": hashlib.sha256(policy_source.read_bytes()).hexdigest(),
        "python_sat_version": pysat.__version__,
        "cadical_binding": "pysat.solvers.Cadical195",
        "cadical_version": "1.9.5",
        "cadical_version_source": "Installed binding class documentation",
        "probe_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "deadline_requires_process_supervisor": True,
        "native_interrupt_supported": False,
        "archive_sha256": hashlib.sha256(args.archive.read_bytes()).hexdigest(),
        "started_monotonic": started,
    }

    def checkpoint(phase):
        report["phase"] = phase
        report["elapsed_seconds"] = time.monotonic() - started
        progress = args.output / "progress.json"
        pending = args.output / "progress.json.tmp"
        pending.write_text(json.dumps(report, indent=2, default=str))
        pending.replace(progress)

    def expired(_signal, _frame):
        raise DiagnosticLimit("absolute diagnostic deadline")

    signal.signal(signal.SIGALRM, expired)
    signal.setitimer(
        signal.ITIMER_REAL,
        max(0.000001, started + policy["wall_seconds_including_preparation"] - time.monotonic()),
    )
    try:
        checkpoint("starting")
        with tempfile.TemporaryDirectory(prefix="independent-template-") as temporary:
            with zipfile.ZipFile(args.archive) as archive:
                archive.extractall(temporary)
            prefix = "2026-09-09-joint-domain-templates"
            sys.path.insert(0, temporary)
            package = Path(temporary) / prefix
            paths = importlib.import_module(prefix + ".template_paths")
            work = importlib.import_module(prefix + ".template_budget")
            control = importlib.import_module(prefix + ".constructive_control")
            runtime = importlib.import_module(prefix + ".template_runtime")
            routing = importlib.import_module("flab2bp.layout.routing_domain")
            frozen = json.loads((package / "template-policy.json").read_text())
            for name, digest in frozen["source_sha256"].items():
                assert hashlib.sha256((package / name).read_bytes()).hexdigest() == digest
            report["frozen_rule_sha256"] = frozen["rule_sha256"]
            data = json.loads((package / "joint-frontier-input.json").read_text())["problem"]
            problem = TypeAdapter(paths.TemplateProblem).validate_python(data)
            report["problem_sha256"] = hashlib.sha256(
                json.dumps(asdict(problem), sort_keys=True, default=str).encode()
            ).hexdigest()
            captured = []

            def capture(actual, _budget):
                assert actual == problem, "Captured input differs from actual frozen control"
                captured.append(actual)
                raise work.ExperimentRefusal(
                    "DIAGNOSTIC_CAPTURE", "unchanged complete-domain input captured"
                )

            budget = work.WorkBudget(started + policy["wall_seconds_including_preparation"])
            session = runtime.TemplateRun(budget, "captured", args.output / "capture")
            with (
                patch.object(runtime, "select", capture),
                patch.object(
                    routing, "_route_all", side_effect=AssertionError("global router forbidden")
                ),
                contextlib.redirect_stdout(io.StringIO()),
            ):
                capture_result = control.run(
                    "three-output", reuse=True, capacity_first=True, template=session
                )
            assert len(captured) == 1 and capture_result["outcome"] == "DIAGNOSTIC_CAPTURE"
            report["actual_frozen_problem_equality"] = True
            checkpoint("captured")
            try:
                selected = solve(problem, paths, work, policy, report, checkpoint)
            except work.ExperimentRefusal as refusal:
                raise DiagnosticLimit(
                    f"diagnostic geometry work: {refusal.reason}: {refusal.detail}"
                ) from refusal
            signal.setitimer(signal.ITIMER_REAL, 0)
            report["feasibility_elapsed_seconds"] = time.monotonic() - started
            if selected is not None:
                report["audit"] = {"status": "pending", "diagnostic_only": True}
                report["audit_started_monotonic"] = time.monotonic()
                checkpoint("auditing")
                audit_deadline = report["audit_started_monotonic"] + policy["audit_wall_seconds"]
                signal.setitimer(
                    signal.ITIMER_REAL, max(0.000001, audit_deadline - time.monotonic())
                )

                def supplied(actual, _budget):
                    assert actual == problem
                    return selected

                audit_budget = work.WorkBudget(audit_deadline)
                session = runtime.TemplateRun(audit_budget, "captured", args.output / "audit")
                try:
                    with (
                        patch.object(runtime, "select", supplied),
                        patch.object(
                            routing,
                            "_route_all",
                            side_effect=AssertionError("global router forbidden"),
                        ),
                        contextlib.redirect_stdout(io.StringIO()),
                    ):
                        audited = control.run(
                            "three-output", reuse=True, capacity_first=True, template=session
                        )
                    report["audit"] = {"diagnostic_only": True, "result": audited}
                except DiagnosticLimit as refusal:
                    report["audit"] = {
                        "diagnostic_only": True,
                        "status": "UNKNOWN",
                        "reason": str(refusal),
                    }
    except DiagnosticLimit as refusal:
        report["outcome"] = "UNKNOWN"
        report["reason"] = str(refusal)
    except Exception as failure:
        report["outcome"] = "DIAGNOSTIC_ERROR"
        report["reason"] = repr(failure)
        raise
    finally:
        cancel_alarm()
        report["elapsed_seconds"] = time.monotonic() - started
        (args.output / "result.json").write_text(json.dumps(report, indent=2, default=str))
        print(
            json.dumps(
                {
                    k: v
                    for k, v in report.items()
                    if k
                    not in ("cuts", "rounds", "native_calls", "selected_points", "audit", "policy")
                },
                default=str,
            )
        )


if __name__ == "__main__":
    main()
