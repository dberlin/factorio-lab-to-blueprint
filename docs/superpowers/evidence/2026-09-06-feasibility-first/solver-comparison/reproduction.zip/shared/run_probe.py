"""Hard process deadlines for finite diagnostic solvers, including native calls."""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import time
from pathlib import Path


def load(path):
    try:
        return json.loads(path.read_text())
    except FileNotFoundError, json.JSONDecodeError:
        return None


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("project", type=Path)
    parser.add_argument("probe", type=Path)
    parser.add_argument("archive", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    policy = json.loads((args.probe / "diagnostic-policy.json").read_text())
    environment = dict(os.environ)
    environment["PYTHONPATH"] = str(args.probe / "deps") + os.pathsep + str(args.project / "src")
    command = [
        str(args.project / ".venv/bin/python"),
        str(args.probe / "probe.py"),
        str(args.archive),
        str(args.output),
    ]
    started = time.monotonic()
    killed = None
    deadline = started + 30
    phase = "bootstrap"
    checkpoint = None
    with (
        (args.output / "stdout.txt").open("w") as stdout,
        (args.output / "stderr.txt").open("w") as stderr,
    ):
        process = subprocess.Popen(
            command, cwd=args.project, env=environment, stdout=stdout, stderr=stderr
        )
        while process.poll() is None:
            latest = load(args.output / "progress.json")
            if latest is not None:
                checkpoint = latest
                if latest.get("phase") == "auditing":
                    phase = "audit"
                    audit_started = latest.get(
                        "audit_started_monotonic",
                        latest["started_monotonic"] + latest["elapsed_seconds"],
                    )
                    deadline = audit_started + policy["audit_wall_seconds"]
                else:
                    phase = "feasibility"
                    deadline = (
                        latest["started_monotonic"] + policy["wall_seconds_including_preparation"]
                    )
            if time.monotonic() >= deadline:
                killed = phase + " hard process deadline"
                process.terminate()
                try:
                    process.wait(timeout=0.2)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait()
                break
            time.sleep(min(0.05, max(0.001, deadline - time.monotonic())))
        exit_code = process.wait()
    result = load(args.output / "result.json")
    recovered = result is None
    if recovered:
        empty_result: dict[str, object] = {"outcome": "UNKNOWN", "diagnostic_only": True}
        result = checkpoint or empty_result
        if phase == "audit" and result.get("outcome") == "COMPLETE_TEMPLATE_GEOMETRY_WITNESS":
            result["audit"] = {
                "diagnostic_only": True,
                "status": "UNKNOWN",
                "reason": killed or "probe exited before final evidence",
            }
        else:
            result["outcome"] = "UNKNOWN"
            result["reason"] = killed or "probe exited before final evidence; inspect stderr"
        result["recovered_from_checkpoint"] = True
    summary = {
        "command": command,
        "exit": exit_code,
        "elapsed_seconds_including_bootstrap": time.monotonic() - started,
        "terminated_at_deadline": killed,
        "deadline_phase": phase,
        "recovered_from_checkpoint": recovered,
        "outcome": result["outcome"],
    }
    (args.output / "effective-result.json").write_text(json.dumps(result, indent=2))
    (args.output / "supervisor.json").write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary))


if __name__ == "__main__":
    main()
