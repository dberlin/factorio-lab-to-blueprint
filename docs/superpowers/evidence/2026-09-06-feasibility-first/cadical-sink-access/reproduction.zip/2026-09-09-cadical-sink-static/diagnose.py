import importlib,time,json
from pathlib import Path
from dataclasses import asdict
from unittest.mock import patch
from pydantic import TypeAdapter
n="2026-09-09-cadical-sink-access"
runtime=importlib.import_module(n+".template_runtime");control=importlib.import_module(n+".constructive_control");work=importlib.import_module(n+".template_budget");paths=importlib.import_module(n+".template_paths");sat=importlib.import_module(n+".template_cadical")
out=Path(".superpowers/sdd/2026-09-09-cadical-sink-static")
problems=[]
def capture(problem,*args):
 problems.append(problem);(out/"problem.json").write_bytes(TypeAdapter(paths.TemplateProblem).dump_json(problem));raise work.ExperimentRefusal("DIAGNOSTIC_CAPTURE","no solver invoked")
budget=work.WorkBudget(time.monotonic()+60)
with patch.object(runtime,"select",capture):control.run("unsprayed-mall",reuse=True,capacity_first=True,template=runtime.TemplateRun(budget,"captured",out/"capture"))
problem=problems[0];ds=paths.domains(problem,budget);fixed=[set(sat.cells(p.points)) for p in problem.fixed_paths];records=[]
for di,d in enumerate(ds):
 g=d._decode(0,budget);occ=set(sat.cells(g.path.points));owned={e.cell for e in (g.path.source,g.path.sink) if e in problem.owned_endpoints};bad=(occ-owned)&problem.blocked
 for f,occupied in zip(problem.fixed_paths,fixed):
  bad.update(c for c in occ&occupied if not paths._owned(g.path,f,c,budget))
 if not bad:continue
 index=sat.CellIndex(d,budget)
 for cell in sorted(bad):
  mask=index.occupants(cell,budget)
  if mask.bit_count()==d.count:
   records.append({"domain":di,"obligation":asdict(d.obligation),"cell":cell,"candidates":d.count,"blocked":cell in problem.blocked,"fixed_paths":[asdict(f) for f,cells in zip(problem.fixed_paths,fixed) if cell in cells]});break
(out/"contradictions.json").write_text(json.dumps(records,default=str,indent=2));print(json.dumps({"domains":len(ds),"contradictions":records},default=str))
