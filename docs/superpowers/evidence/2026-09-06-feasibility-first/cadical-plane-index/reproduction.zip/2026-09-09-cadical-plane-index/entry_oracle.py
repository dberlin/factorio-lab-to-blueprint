"""Expanded actual-adapter/riser oracle; experiment evidence, not a benchmark."""

from __future__ import annotations

import json
import time
from dataclasses import replace
from fractions import Fraction

from .template_budget import WorkBudget
from .template_cadical import CellIndex, entry_rejections
from .template_paths import (
    Endpoint,
    FixedPath,
    Obligation,
    TemplateProblem,
    _adapter,
    _owned,
    domains,
)
from .template_paths_witness import _expand


def run() -> dict[str, int | bool]:
    checked = excluded = retained = 0
    for source_z, sink_z in ((0, 0), (7, 3), (3, 7), (7, 7)):
        budget = WorkBudget(time.monotonic() + 60)
        source = Endpoint((0, 0, source_z), (1, 0), 1)
        sink = Endpoint((20, 12, sink_z), (-1, 0), 2)
        obligation = Obligation(0, "iron", Fraction(1), source, sink)
        base = TemplateProblem(
            (obligation,), frozenset(), (), (-4, 4, 16, 24), (-4, 4, 8, 16), (3, 5, 8)
        )
        domain = domains(base, budget)[0]
        index = CellIndex(domain, budget)
        owned_path = FixedPath(
            ((-2, 0, source_z), source.cell),
            Endpoint((-2, 0, source_z), (1, 0), 9),
            Endpoint(source.cell, (-1, 0), source.port_id),
            "iron",
        )
        foreign_path = replace(owned_path, item="copper")
        cases = [
            base,
            replace(base, blocked=frozenset({source.cell})),
            replace(base, blocked=frozenset({source.cell}), owned_endpoints=(source,)),
            replace(base, fixed_paths=(owned_path,)),
            replace(base, fixed_paths=(foreign_path,)),
        ]
        cases.extend(
            replace(base, blocked=frozenset({(x, y, z)}))
            for x, y in ((2, 0), (4, 0), (6, 0), (2, 2), (2, -2), (18, 12))
            for z in (0, 2, 3, 4, 5, 6, 7, 8)
        )
        for problem in cases:
            fixed_cells = [set(_expand(path.points)) for path in problem.fixed_paths]
            actual = entry_rejections(problem, [index], fixed_cells, budget)[0]
            expected = 0
            for ci in range(domain.count):
                combo, zi = divmod(ci, len(domain.levels))
                sa, rest = divmod(combo, 5 * len(domain.shapes))
                ta, _ = divmod(rest, len(domain.shapes))
                start, finish = _adapter(source, sa), _adapter(sink, ta)
                height = domain.levels[zi]
                occupied = set(_expand(start + ((*start[-1][:2], height),)))
                occupied.update(_expand(finish + ((*finish[-1][:2], height),)))
                representative = FixedPath((), source, sink, "iron")
                forbidden = any(
                    cell in problem.blocked
                    and not any(
                        endpoint.cell == cell and endpoint in problem.owned_endpoints
                        for endpoint in (source, sink)
                    )
                    or any(
                        cell in fixed and not _owned(representative, path, cell, budget)
                        for path, fixed in zip(problem.fixed_paths, fixed_cells, strict=True)
                    )
                    for cell in occupied
                )
                if forbidden:
                    expected |= 1 << ci
                checked += 1
            assert actual == expected, (source_z, sink_z, problem.blocked, problem.fixed_paths)
            excluded += actual.bit_count()
            retained += domain.count - actual.bit_count()
    assert excluded > 0 and retained > 0
    return {
        "candidate_exclusion_comparisons": checked,
        "excluded": excluded,
        "retained": retained,
        "expanded_adapter_and_riser_oracle": True,
        "nonconsecutive_heights_and_descending_risers": True,
        "body_ownership_and_foreign_fixed_occupants": True,
    }


if __name__ == "__main__":
    print(json.dumps(run(), sort_keys=True))
