"""Exact static-mask comparison against the original complete-path collider."""

from __future__ import annotations

import json
import time
from dataclasses import replace
from fractions import Fraction

from .template_budget import WorkBudget
from .template_cadical import CellIndex, DomainIndex, entry_rejections, exclude_static_middles
from .template_paths import Endpoint, FixedPath, Obligation, TemplateProblem, _FixedIndex, domains
from .template_paths_witness import _expand


def run() -> dict[str, int | bool]:
    checked = rejected_count = accepted_count = 0
    for source_z, sink_z in ((0, 0), (7, 3), (3, 7), (7, 7)):
        budget = WorkBudget(time.monotonic() + 60)
        source = Endpoint((0, 0, source_z), (1, 0), 1)
        sink = Endpoint((20, 12, sink_z), (-1, 0), 2)
        obligation = Obligation(0, "iron", Fraction(1), source, sink)
        base = TemplateProblem(
            (obligation,), frozenset(), (), (-4, 4, 16, 24), (-4, 4, 8, 16), (3, 5, 8)
        )
        domain = domains(base, budget)[0]
        indexes = [CellIndex(domain, budget)]
        domain_index = DomainIndex(indexes, budget)
        owned_path = FixedPath(
            ((-2, 0, source_z), source.cell),
            Endpoint((-2, 0, source_z), (1, 0), 9),
            Endpoint(source.cell, (-1, 0), source.port_id),
            "iron",
        )
        middle_path = FixedPath(
            ((4, 4, 3), (6, 4, 3)),
            Endpoint((4, 4, 3), (1, 0), 10),
            Endpoint((6, 4, 3), (-1, 0), 11),
            "copper",
        )
        cases = (
            base,
            replace(base, blocked=frozenset({source.cell})),
            replace(base, blocked=frozenset({source.cell}), owned_endpoints=(source,)),
            replace(base, fixed_paths=(owned_path,)),
            replace(base, fixed_paths=(replace(owned_path, item="copper"),)),
            replace(base, fixed_paths=(middle_path,)),
            replace(base, blocked=frozenset({(4, 4, 3), (10, 12, 5), (18, 12, 7)})),
            replace(base, blocked=frozenset({(2, 0, 4), (2, -2, 8)}), fixed_paths=(middle_path,)),
        )
        geometries = [domain._decode(ci, budget) for ci in range(domain.count)]
        for problem in cases:
            fixed_cells = [set(_expand(path.points)) for path in problem.fixed_paths]
            rejected = entry_rejections(problem, indexes, fixed_cells, budget)
            exclude_static_middles(problem, indexes, domain_index, fixed_cells, rejected, budget)
            reference = _FixedIndex(problem, budget)
            for ci, geometry in enumerate(geometries):
                expected = reference.error(geometry, budget) is not None
                actual = bool(rejected[0] & (1 << ci))
                assert actual == expected, (source_z, sink_z, ci, problem)
                checked += 1
                rejected_count += actual
                accepted_count += not actual
    assert rejected_count > 0 and accepted_count > 0
    return {
        "complete_static_comparisons": checked,
        "rejected": rejected_count,
        "retained": accepted_count,
        "exact_original_complete_path_collider": True,
        "owned_endpoints_and_foreign_occupants": True,
        "ascending_descending_and_nonconsecutive_heights": True,
    }


if __name__ == "__main__":
    print(json.dumps(run(), sort_keys=True))
