"""Exercise external cutoffs and launch exclusion without running the mall."""

from __future__ import annotations

import json
import sys
from pathlib import Path
from tempfile import TemporaryDirectory

from .diagnostic import DiagnosticPolicy, verify
from .supervise import ROOT, SupervisorPolicy, supervise


def main() -> None:
    policy = DiagnosticPolicy.model_validate_json((ROOT / "diagnostic-policy.json").read_text())
    verify(policy)
    results: dict[str, object] = {"frozen_preflight": "PASS"}
    with TemporaryDirectory(prefix="wall-budget-supervisor-") as temporary:
        root = Path(temporary)
        base = SupervisorPolicy(
            layout_budget_s=0.1, bootstrap_s=5, poll_s=0.005, maximum_rss_bytes=32 * 1024**2
        )
        rss = supervise(
            [sys.executable, "-c", "import time; allocation=bytearray(64*1024**2); time.sleep(2)"],
            root / "rss",
            base,
        )
        assert rss["termination"] == "RSS_LIMIT" and rss["outcome"] == "UNKNOWN"
        results["rss"] = rss
        deadline_output = root / "deadline"
        code = (
            "import json,time; from pathlib import Path; now=time.monotonic(); "
            f"Path({str(deadline_output / 'progress.json')!r}).write_text("
            "json.dumps(dict(case='synthetic',started_monotonic=now,"
            "deadline=now+0.1,budget_s=0.1))); time.sleep(2)"
        )
        deadline = supervise([sys.executable, "-c", code], deadline_output, base)
        assert deadline["termination"] == "LAYOUT_DEADLINE" and deadline["outcome"] == "UNKNOWN"
        results["deadline"] = deadline
        bootstrap = supervise(
            [sys.executable, "-c", "import time; time.sleep(2)"],
            root / "bootstrap",
            base.model_copy(update={"bootstrap_s": 0.1}),
        )
        assert bootstrap["termination"] == "BOOTSTRAP_DEADLINE"
        results["bootstrap"] = bootstrap
        success_output = root / "success"
        success = supervise(
            [
                sys.executable,
                "-c",
                "from pathlib import Path; "
                f"Path({str(success_output / 'result.json')!r}).write_text('{{}}')",
            ],
            success_output,
            base,
        )
        assert (
            success["exit"] == 0
            and success["termination"] is None
            and success["final_report_written"] is True
        )
        results["success"] = success
        try:
            supervise(
                [sys.executable, "-c", "raise AssertionError('must never launch')"],
                success_output,
                base,
            )
        except FileExistsError:
            results["repeat_launch"] = "REFUSED_BEFORE_SPAWN"
        else:
            raise AssertionError("repeat launch was not refused")
    (ROOT / "supervisor-witness.json").write_text(json.dumps(results, indent=2) + "\n")
    print(
        json.dumps(
            {
                "frozen_preflight": "PASS",
                "rss": "PASS",
                "layout_deadline": "PASS",
                "bootstrap_deadline": "PASS",
                "normal_exit": "PASS",
                "repeat_launch": "PASS",
            }
        )
    )


if __name__ == "__main__":
    main()
