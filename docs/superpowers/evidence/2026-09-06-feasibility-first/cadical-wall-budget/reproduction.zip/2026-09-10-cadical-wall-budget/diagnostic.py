"""Authorized one-run policy exception; unchanged frozen neighborhood algorithm."""

from __future__ import annotations

import hashlib
import json
import time
from dataclasses import asdict
from pathlib import Path
from typing import Literal
from unittest.mock import patch

from pydantic import BaseModel, ConfigDict

from flab2bp.layout import routing_domain as rd

from . import template_cadical as selector
from . import template_runtime as runtime
from .constructive_control import run
from .supervise import SupervisorPolicy
from .template_budget import ExperimentRefusal, WorkBudget, WorkLimits
from .template_experiment import FrozenPolicy, absolute_deadline, rule_hash
from .template_runtime import TemplateRun

ROOT = Path(__file__).parent
BASELINE = ROOT.parent / "2026-09-09-cadical-neighborhood"


class DiagnosticPolicy(SupervisorPolicy):
    model_config = ConfigDict(extra="forbid", frozen=True)
    scope: str
    case: Literal["unsprayed-mall"]
    topology: Literal["captured"]
    mode: Literal["GEOMETRY_ONLY"]
    permitted_runs: Literal[1]
    maximum_collision_cuts: int
    maximum_clauses: int
    work_limits: WorkLimits
    original_rule_sha256: str
    original_policy_sha256: str
    original_control_sha256: str
    spec_sha256: str
    source_sha256: dict[str, str]


class ControlResult(BaseModel):
    outcome: str
    checks_run: int | None = None


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify(policy: DiagnosticPolicy) -> None:
    frozen = FrozenPolicy.model_validate_json((BASELINE / "template-policy.json").read_text())
    assert sha(BASELINE / "template-policy.json") == policy.original_policy_sha256
    assert frozen.rule_sha256 == policy.original_rule_sha256 == rule_hash()
    assert frozen.source_sha256 == policy.source_sha256
    for name, digest in policy.source_sha256.items():
        assert sha(ROOT / name) == digest and sha(BASELINE / name) == digest
    assert sha(ROOT / "frozen/manifest.json") == frozen.manifest_sha256
    assert (
        sha(ROOT / "frozen/unsprayed-mall.json")
        == frozen.spec_sha256[policy.case]
        == policy.spec_sha256
    )
    for name, digest in frozen.admission_sha256.items():
        assert sha(BASELINE / "template-cases/admission" / name / "result.json") == digest
    control_path = BASELINE / "template-cases/three-output/result.json"
    assert sha(control_path) == policy.original_control_sha256
    control = ControlResult.model_validate_json(control_path.read_text())
    assert control.outcome == "VALIDATOR_COMPLETE_WITNESS"
    assert selector.MAXIMUM_CLAUSES == policy.maximum_clauses == 20_000_000
    assert policy.layout_budget_s == 60 and policy.maximum_collision_cuts == 200_000
    assert policy.work_limits == WorkLimits(predicates=100_000_000)


def main() -> None:
    policy_path = ROOT / "diagnostic-policy.json"
    policy = DiagnosticPolicy.model_validate_json(policy_path.read_text())
    verify(policy)
    output = ROOT / "run"
    output.mkdir(exist_ok=True)
    if (output / "progress.json").exists() or (output / "result.json").exists():
        raise RuntimeError("diagnostic execution already started; no retry is authorized")
    started = time.monotonic()
    budget = WorkBudget(started + policy.layout_budget_s, policy.work_limits)
    session = TemplateRun(budget, policy.topology, output / "captured", mode=policy.mode)
    progress = {
        "case": policy.case,
        "started_monotonic": started,
        "deadline": budget.deadline,
        "budget_s": policy.layout_budget_s,
    }
    temporary = output / "progress.tmp"
    temporary.write_text(json.dumps(progress))
    temporary.replace(output / "progress.json")
    attempt: dict[str, object]
    with (
        patch.object(
            rd, "_route_all", side_effect=AssertionError("global router forbidden")
        ) as router,
        patch.object(selector, "MAXIMUM_COLLISION_CUTS", policy.maximum_collision_cuts),
        patch.object(runtime, "MAXIMUM_COLLISION_CUTS", policy.maximum_collision_cuts),
    ):
        try:
            with absolute_deadline(budget):
                attempt = run(policy.case, reuse=True, capacity_first=True, template=session)
        except ExperimentRefusal as failure:
            attempt = {"outcome": failure.reason, "reason": failure.detail}
        assert router.call_count == 0
    finished = time.monotonic()
    result = {
        "scope": policy.scope,
        "case": policy.case,
        "mode": policy.mode,
        "topology": policy.topology,
        "outcome": attempt["outcome"],
        "reason": attempt.get("reason"),
        "elapsed_s": finished - started,
        "budget_s": policy.layout_budget_s,
        "within_deadline": finished <= budget.deadline,
        "work": budget.counts,
        "solver": asdict(session.solve_stats),
        "attempt": attempt,
        "original_factory_gate": False,
        "official_work_policy_acceptance": False,
        "global_router_calls": 0,
        "diagnostic_policy_sha256": sha(policy_path),
        "original_rule_sha256": policy.original_rule_sha256,
    }
    (output / "result.json").write_text(json.dumps(result, indent=2, default=str) + "\n")
    print(
        json.dumps(
            {key: value for key, value in result.items() if key not in ("attempt", "solver")}
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
