"""One-shot external wall/RSS supervision; never retries the diagnostic."""

from __future__ import annotations

import json
import os
import subprocess
import sys
import time
from pathlib import Path

from pydantic import BaseModel

ROOT = Path(__file__).parent


class SupervisorPolicy(BaseModel):
    layout_budget_s: float
    bootstrap_s: float
    poll_s: float
    maximum_rss_bytes: int


class Progress(BaseModel):
    case: str
    started_monotonic: float
    deadline: float
    budget_s: float


def rss_bytes(pid: int) -> int:
    try:
        text = Path(f"/proc/{pid}/status").read_text()
    except FileNotFoundError:
        return 0
    for line in text.splitlines():
        if line.startswith("VmRSS:"):
            return int(line.split()[1]) * 1024
    return 0


def supervise(command: list[str], output: Path, policy: SupervisorPolicy) -> dict[str, object]:
    output.mkdir(parents=True, exist_ok=True)
    # Exclusive creation prevents even an interrupted launch from being retried.
    with (output / "launch.json").open("x") as record:
        json.dump({"command": command, "policy": policy.model_dump()}, record, indent=2)
    started = time.monotonic()
    deadline = started + policy.bootstrap_s
    progress: Progress | None = None
    peak_rss = 0
    termination: str | None = None
    with (output / "stdout.txt").open("w") as stdout, (output / "stderr.txt").open("w") as stderr:
        child = subprocess.Popen(command, stdout=stdout, stderr=stderr)
        try:
            while child.poll() is None:
                peak_rss = max(peak_rss, rss_bytes(child.pid))
                if progress is None:
                    try:
                        raw = (output / "progress.json").read_text()
                        json.loads(raw)
                    except FileNotFoundError, json.JSONDecodeError:
                        pass
                    else:
                        progress = Progress.model_validate_json(raw)
                        if (
                            progress.budget_s != policy.layout_budget_s
                            or abs(
                                progress.deadline
                                - progress.started_monotonic
                                - policy.layout_budget_s
                            )
                            > 0.001
                        ):
                            raise AssertionError("child attempted to change its declared deadline")
                        deadline = progress.deadline
                remaining = deadline - time.monotonic()
                if peak_rss > policy.maximum_rss_bytes:
                    termination = "RSS_LIMIT"
                    break
                if remaining <= 0:
                    termination = "LAYOUT_DEADLINE" if progress else "BOOTSTRAP_DEADLINE"
                    break
                time.sleep(min(policy.poll_s, remaining))
        finally:
            if child.poll() is None:
                child.terminate()
                try:
                    child.wait(timeout=0.2)
                except subprocess.TimeoutExpired:
                    child.kill()
            code = child.wait()
    summary: dict[str, object] = {
        "command": command,
        "exit": code,
        "termination": termination,
        "peak_sampled_rss_bytes": peak_rss,
        "bootstrap_inclusive_seconds": time.monotonic() - started,
        "progress": progress.model_dump() if progress else None,
        "final_report_written": (output / "result.json").exists(),
        "official_acceptance": False,
    }
    if termination or code != 0 or not summary["final_report_written"]:
        summary["outcome"] = "UNKNOWN"
        summary["reason"] = "supervisor termination, nonzero exit or missing final report"
    (output / "supervisor.json").write_text(json.dumps(summary, indent=2) + "\n")
    return summary


if __name__ == "__main__":
    policy = SupervisorPolicy.model_validate_json((ROOT / "diagnostic-policy.json").read_text())
    os.environ["PYTHONPATH"] = os.pathsep.join(
        (str(ROOT.parent), str(ROOT.parent / "2026-09-09-cadical-feasibility/deps"))
    )
    result = supervise([sys.executable, "-m", f"{ROOT.name}.diagnostic"], ROOT / "run", policy)
    print(json.dumps(result))
