"""Sound full-height exclusions for two opposing riser/middle crossings."""

from __future__ import annotations

from .family_geometry import Family, Primitive, PrimitiveIndex
from .template_budget import WorkBudget
from .template_paths import Cell


def _direction(
    riser: Primitive,
    middle: Primitive,
    low: int,
    high: int,
    owners: frozenset[Cell],
    budget: WorkBudget,
) -> int:
    """Same-side anchors give opposite ordering constraints at the two crossings."""
    budget.charge("predicates", 8)
    x, y = riser.lo[:2]
    if not (middle.lo[0] <= x <= middle.hi[0] and middle.lo[1] <= y <= middle.hi[1]):
        return 0
    for owner in owners:
        budget.charge("predicates", 4)
        if owner[:2] == (x, y) and low <= owner[2] <= high:
            return 0
    if riser.endpoint_z <= low:
        return 1
    if riser.endpoint_z >= high:
        return -1
    return 0


def opposite_crossings(
    ra: Primitive,
    mb: Primitive,
    ma: Primitive,
    rb: Primitive,
    left_levels: tuple[int, ...],
    right_levels: tuple[int, ...],
    owners: frozenset[Cell],
    budget: WorkBudget,
) -> bool:
    budget.charge("predicates", 8)
    if not left_levels or not right_levels:
        return False
    if (ra.kind, mb.kind, ma.kind, rb.kind) != ("R", "M", "M", "R"):
        return False
    low = min(left_levels[0], right_levels[0])
    high = max(left_levels[-1], right_levels[-1])
    first = _direction(ra, mb, low, high, owners, budget)
    return first != 0 and first == _direction(rb, ma, low, high, owners, budget)


def joint_family(
    left: PrimitiveIndex,
    right: PrimitiveIndex,
    ca: int,
    cb: int,
    budget: WorkBudget,
) -> Family | None:
    """A sufficient exact proof, never an over-approximation of a failed search."""
    budget.charge("predicates", 4)
    la, lb = left.domain.levels, right.domain.levels
    if not la or not lb:
        return None
    low, high = min(la[0], lb[0]), max(la[-1], lb[-1])
    owners = left.owners(right, budget)
    first: list[tuple[int, int, int]] = []
    second: list[tuple[int, int, int]] = []
    for ai in left.combos[ca]:
        a = left.primitives[ai]
        for bi in right.combos[cb]:
            budget.charge("predicates", 2)
            b = right.primitives[bi]
            if a.kind == "R" and b.kind == "M":
                direction = _direction(a, b, low, high, owners, budget)
                if direction:
                    budget.charge("predicates")
                    first.append((ai, bi, direction))
            elif a.kind == "M" and b.kind == "R":
                direction = _direction(b, a, low, high, owners, budget)
                if direction:
                    budget.charge("predicates")
                    second.append((ai, bi, direction))
    for ai, bi, direction in first:
        for aj, bj, other_direction in second:
            budget.charge("predicates")
            if direction != other_direction:
                continue
            budget.charge(
                "predicates",
                4
                + (max(left.masks[ai].bit_length(), left.masks[aj].bit_length()) + 63) // 64
                + (max(right.masks[bi].bit_length(), right.masks[bj].bit_length()) + 63) // 64,
            )
            return Family(
                left.masks[ai] & left.masks[aj],
                right.masks[bi] & right.masks[bj],
                ((0, len(la) - 1, 0, len(lb) - 1),),
            )
    return None
