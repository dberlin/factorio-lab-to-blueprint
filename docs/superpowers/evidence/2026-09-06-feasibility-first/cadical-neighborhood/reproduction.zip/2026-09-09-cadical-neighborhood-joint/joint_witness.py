"""Independent geometry proves full-height exclusions and ownership boundaries."""

from __future__ import annotations

import json
import time
from pathlib import Path

from pydantic import BaseModel, TypeAdapter

from .family_geometry import Primitive, PrimitiveIndex
from .joint_conflicts import joint_family, opposite_crossings
from .template_budget import WorkBudget
from .template_cadical import cells
from .template_paths import Cell, TemplateProblem, _compatible, domains


class Proof(BaseModel):
    left_mask: int
    right_mask: int


class Sample(BaseModel):
    pair: tuple[int, int]
    xy: tuple[int, int]
    two_relation_proof: Proof | None


def run() -> dict[str, int | bool]:
    left_levels, right_levels = (3, 4, 7), (3, 5, 7)
    checks = 0
    for az, bz, owners, expected in [
        (0, 0, frozenset(), True),
        (10, 10, frozenset(), True),
        (0, 10, frozenset(), False),
        (5, 0, frozenset(), False),
        (0, 0, frozenset({(0, 0, 3)}), False),
        (0, 0, frozenset({(0, 0, 1)}), True),
    ]:
        budget = WorkBudget(time.monotonic() + 60)
        ra = Primitive("R", (0, 0, 0), (0, 0, 0), az)
        mb = Primitive("M", (-1, 0, 0), (1, 0, 0))
        ma = Primitive("M", (-1, 1, 0), (1, 1, 0))
        rb = Primitive("R", (0, 1, 0), (0, 1, 0), bz)
        assert (
            opposite_crossings(ra, mb, ma, rb, left_levels, right_levels, owners, budget)
            is expected
        )
        possible = False
        for a in left_levels:
            for b in right_levels:
                expanded: list[set[Cell]] = []
                for primitive, height in [(ra, a), (mb, b), (ma, a), (rb, b)]:
                    segment = primitive.at(height, budget)
                    expanded.append(set(cells((segment.lo, segment.hi))))
                forbidden = bool(
                    ((expanded[0] & expanded[1]) | (expanded[2] & expanded[3])) - owners
                )
                possible |= not forbidden
                if expected:
                    assert forbidden
                checks += 1
        assert possible is not expected

    root = Path(__file__).parent.parent
    problem = TypeAdapter(TemplateProblem).validate_json(
        (root / "2026-09-09-cadical-interface-static/problem.json").read_text()
    )
    budget = WorkBudget(time.monotonic() + 60)
    ds = domains(problem, budget)
    indexes = [PrimitiveIndex(d, budget) for d in ds]
    samples = TypeAdapter(list[Sample]).validate_json(
        (root / "2026-09-09-cadical-refinement-effectiveness/closure-proofs.json").read_text()
    )
    actual_proofs = actual_pairs = 0
    for sample in samples:
        if sample.two_relation_proof is None:
            continue
        budget = WorkBudget(time.monotonic() + 60)
        i, j = sample.pair
        ca, cb = sample.xy
        family = joint_family(indexes[i], indexes[j], ca, cb, budget)
        assert family is not None
        assert family.left_mask & (1 << ca) and family.right_mask & (1 << cb)
        assert family.rectangles == ((0, len(ds[i].levels) - 1, 0, len(ds[j].levels) - 1),)
        left = [ds[i]._decode(ca * len(ds[i].levels) + z, budget) for z in range(len(ds[i].levels))]
        right = [
            ds[j]._decode(cb * len(ds[j].levels) + z, budget) for z in range(len(ds[j].levels))
        ]
        for a in left:
            for b in right:
                assert not _compatible(a, b, budget)
                actual_pairs += 1
        actual_proofs += 1
    return {
        "boundary_height_pairs": checks,
        "actual_joint_proofs": actual_proofs,
        "actual_canonical_height_pairs": actual_pairs,
        "ownership_holes_and_opposite_anchor_sides_rejected": True,
    }


if __name__ == "__main__":
    print(json.dumps(run(), sort_keys=True))
