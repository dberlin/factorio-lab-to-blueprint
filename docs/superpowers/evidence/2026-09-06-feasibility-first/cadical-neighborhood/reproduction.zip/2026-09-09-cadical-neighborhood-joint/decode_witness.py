"""Independent exact-choice decoding and charged-work regression witness."""

from __future__ import annotations

import json
import random
import sys
import time
from collections.abc import Iterator
from fractions import Fraction
from importlib import import_module
from typing import cast, override

from pysat.solvers import Cadical195

from .family_cnf import FactorCNF
from .template_budget import WorkBudget
from .template_paths import Domain, Endpoint, Obligation

_BASELINE = "2026-09-09-cadical-primitive-preparation"


class _ObservedLiterals(list[int]):
    """Count actual iteration, independently of the implementation's charges."""

    def __init__(self, values: list[int]) -> None:
        super().__init__(values)
        self.visits: int = 0

    @override
    def __iter__(self) -> Iterator[int]:
        for value in super().__iter__():
            self.visits += 1
            yield value


def _reference(cnf: FactorCNF, model: list[int]) -> list[int]:
    # Independent pre-revision algorithm, including its actual scan charges.
    cnf.budget.charge("predicates", len(model))
    positive = {literal for literal in model if 0 < literal <= cnf.primary_variables}
    selected: list[int] = []
    for xy, height in zip(cnf.xy, cnf.height, strict=True):
        cnf.budget.charge("predicates", len(xy) + len(height))
        combos = [index for index, literal in enumerate(xy) if literal in positive]
        levels = [index for index, literal in enumerate(height) if literal in positive]
        if len(combos) != 1 or len(levels) != 1:
            raise AssertionError("SAT assignment violates exact semantic choices")
        selected.append(combos[0] * len(height) + levels[0])
    return selected


def _outcome(cnf: FactorCNF, model: list[int], *, reference: bool = False) -> list[int] | str:
    try:
        return _reference(cnf, model) if reference else cnf.select(model)
    except AssertionError as error:
        return str(error)


def _domains() -> tuple[Domain, ...]:
    sizes = ((1, 1), (2, 3), (19, 5), (100, 7), (101, 2), (257, 11), (500, 17), (1200, 23))
    return tuple(
        Domain(
            Obligation(
                index,
                "iron",
                Fraction(1),
                Endpoint((0, index, 0), (1, 0), index * 2),
                Endpoint((20, index, 0), (-1, 0), index * 2 + 1),
            ),
            tuple(3 * level for level in range(heights)),
            ((0, 0),),
            tuple(range(combos)),
            tuple(range(heights)),
        )
        for index, (combos, heights) in enumerate(sizes)
    )


def run(target: str | None = None) -> dict[str, int | bool]:
    """Pass the immutable baseline package name to observe the work rejection."""
    target_type = (
        FactorCNF
        if target is None
        else cast(type[FactorCNF], import_module(f"{target}.family_cnf").FactorCNF)
    )
    baseline_type = cast(type[FactorCNF], import_module(f"{_BASELINE}.family_cnf").FactorCNF)
    ds = _domains()
    budget = WorkBudget(time.monotonic() + 60)
    reference_budget = WorkBudget(time.monotonic() + 60)
    clauses: list[list[int]] = []
    reference_clauses: list[list[int]] = []
    cnf = target_type(ds, clauses.append, budget)
    reference_cnf = baseline_type(ds, reference_clauses.append, reference_budget)
    preparation = budget.counts.get("predicates", 0)
    reference_preparation = reference_budget.counts.get("predicates", 0)
    assert clauses == reference_clauses, "decoder preparation changed emitted clauses"
    assert (cnf.top_id, cnf.primary_variables, cnf.xy, cnf.height, cnf.thresholds) == (
        reference_cnf.top_id,
        reference_cnf.primary_variables,
        reference_cnf.xy,
        reference_cnf.height,
        reference_cnf.thresholds,
    ), "decoder preparation changed variable allocation"

    rng = random.Random(73)
    native_models: list[list[int]] = []
    expected_choices: list[list[int]] = []
    with Cadical195(bootstrap_with=clauses) as solver:
        for turn in range(10):
            expected: list[int] = []
            assumptions: list[int] = []
            for domain, (xy, heights) in enumerate(zip(cnf.xy, cnf.height, strict=True)):
                if turn < 2:
                    combo = 0 if turn == 0 else len(xy) - 1
                    height = 0 if turn == 0 else len(heights) - 1
                else:
                    combo = (turn * 37 + domain) % len(xy)
                    height = (turn * 5 + domain) % len(heights)
                assumptions.extend((xy[combo], heights[height]))
                expected.append(combo * len(heights) + height)
            assert solver.solve(assumptions=assumptions)
            model = solver.get_model()
            assert model is not None
            assert {abs(literal) for literal in model} == set(range(1, cnf.top_id + 1))
            if turn % 2:
                model.reverse()
            else:
                rng.shuffle(model)
            native_models.append(model)
            expected_choices.append(expected)

    comparisons = rejections = 0
    for model, expected in zip(native_models, expected_choices, strict=True):
        primary = [literal for literal in model if 0 < literal <= cnf.primary_variables]
        variants = (
            model,
            list(reversed(model)),
            model + primary + primary + [0, cnf.top_id + 17, -(cnf.top_id + 17)],
            [-literal if abs(literal) > cnf.primary_variables else literal for literal in model],
            model + [-literal for literal in primary],
        )
        for variant in variants:
            assert _outcome(reference_cnf, variant, reference=True) == expected
            assert _outcome(cnf, variant) == expected
            comparisons += 1

    model = native_models[-1]
    expected = expected_choices[-1]
    for domain, (xy, heights) in enumerate(zip(cnf.xy, cnf.height, strict=True)):
        combo, height = divmod(expected[domain], len(heights))
        for group, selected_index in ((xy, combo), (heights, height)):
            chosen = group[selected_index]
            malformed = [[-literal if literal == chosen else literal for literal in model]]
            if len(group) > 1:
                malformed.append(model + [group[(selected_index + 1) % len(group)]])
            for variant in malformed:
                rng.shuffle(variant)
                old = _outcome(reference_cnf, variant, reference=True)
                assert isinstance(old, str), "reference accepted missing or multiple choices"
                assert _outcome(cnf, variant) == old
                rejections += 1

    # Observe selector visits without changing values, allocation, or semantics.
    observed = [_ObservedLiterals(group) for groups in (cnf.xy, cnf.height) for group in groups]
    reference_observed = [
        _ObservedLiterals(group)
        for groups in (reference_cnf.xy, reference_cnf.height)
        for group in groups
    ]
    count = len(ds)
    cnf.xy[:] = observed[:count]
    cnf.height[:] = observed[count:]
    reference_cnf.xy[:] = reference_observed[:count]
    reference_cnf.height[:] = reference_observed[count:]
    before = budget.counts.get("predicates", 0)
    reference_before = reference_budget.counts.get("predicates", 0)
    model_visits = reference_model_visits = 0
    for model, expected in zip(native_models, expected_choices, strict=True):
        measured = _ObservedLiterals(model)
        reference_measured = _ObservedLiterals(model)
        assert cnf.select(measured) == expected
        assert _reference(reference_cnf, reference_measured) == expected
        model_visits += measured.visits
        reference_model_visits += reference_measured.visits
    decode_work = budget.counts.get("predicates", 0) - before
    reference_decode_work = reference_budget.counts.get("predicates", 0) - reference_before
    selector_visits = sum(group.visits for group in observed)
    reference_selector_visits = sum(group.visits for group in reference_observed)
    assert preparation + decode_work < reference_preparation + reference_decode_work, (
        "combined preparation and decoding work did not decrease",
        preparation + decode_work,
        reference_preparation + reference_decode_work,
    )
    assert model_visits == reference_model_visits == sum(map(len, native_models))
    assert selector_visits < reference_selector_visits, (
        "charged discount without removing selector scans"
    )
    return {
        "domains": len(ds),
        "native_models": len(native_models),
        "valid_model_comparisons": comparisons,
        "invalid_model_rejections": rejections,
        "clauses_unchanged": True,
        "variables_unchanged": True,
        "preparation_predicates": preparation,
        "reference_preparation_predicates": reference_preparation,
        "decode_predicates": decode_work,
        "reference_decode_predicates": reference_decode_work,
        "combined_predicates_saved": (
            reference_preparation + reference_decode_work - preparation - decode_work
        ),
        "model_literal_visits": model_visits,
        "reference_model_literal_visits": reference_model_visits,
        "selector_literal_visits": selector_visits,
        "reference_selector_literal_visits": reference_selector_visits,
    }


if __name__ == "__main__":
    print(json.dumps(run(sys.argv[1] if len(sys.argv) > 1 else None), sort_keys=True))
