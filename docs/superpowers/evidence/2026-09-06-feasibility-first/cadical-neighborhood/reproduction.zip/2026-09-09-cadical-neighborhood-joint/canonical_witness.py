"""Exact ordered clause, duplicate-cut and quota proof for canonical family assembly."""

from __future__ import annotations

import hashlib
import json
import time
from fractions import Fraction
from itertools import product
from pathlib import Path

from pydantic import BaseModel, TypeAdapter

from .family_cnf import FactorCNF, negative
from .family_geometry import Family
from .template_budget import ExperimentRefusal, WorkBudget
from .template_paths import Domain, Endpoint, Obligation, TemplateProblem, domains


class _ReferenceCNF(FactorCNF):
    """Independent pre-cut-construction encoder; other semantics are unchanged."""

    def forbid(self, left: int, right: int, family: Family) -> int:
        if left >= right:
            raise AssertionError("family domains must use canonical dense order")
        gl = self.guard(left, family.left_mask)
        gr = self.guard(right, family.right_mask)
        before = self.rectangles
        for a, b, c, d in family.rectangles:
            self.budget.charge("predicates")
            if not (0 <= a <= b < len(self.height[left]) and 0 <= c <= d < len(self.height[right])):
                raise AssertionError("family rectangle lies outside original legal heights")
            clause = self.simplify(
                [
                    negative(gl),
                    negative(gr),
                    negative(self.thresholds[left][a]),
                    self.thresholds[left][b + 1],
                    negative(self.thresholds[right][c]),
                    self.thresholds[right][d + 1],
                ]
            )
            if clause is None:
                raise AssertionError("forbidden rectangle produced a tautology")
            if clause in self.prohibitions:
                continue
            if self.rectangles >= self.maximum_rectangles:
                raise ExperimentRefusal("POLICY_BOUND", "CaDiCaL collision prohibition cap")
            self.add_clause(list(clause))
            self.prohibitions.add(clause)
            self.rectangles += 1
        return self.rectangles - before


class _Case(BaseModel):
    left: int
    right: int
    family: Family


class _Stream:
    def __init__(self) -> None:
        self.count = 0
        self.digest = hashlib.sha256()

    def emit(self, clause: list[int]) -> None:
        self.count += 1
        self.digest.update(json.dumps(clause, separators=(",", ":")).encode() + b"\n")

    def snapshot(self) -> tuple[int, str]:
        return self.count, self.digest.hexdigest()


def _pair(ds: tuple[Domain, ...]) -> tuple[FactorCNF, _ReferenceCNF, _Stream, _Stream]:
    actual_stream, reference_stream = _Stream(), _Stream()
    actual = FactorCNF(ds, actual_stream.emit, WorkBudget(time.monotonic() + 60))
    reference = _ReferenceCNF(ds, reference_stream.emit, WorkBudget(time.monotonic() + 60))
    assert actual_stream.snapshot() == reference_stream.snapshot()
    return actual, reference, actual_stream, reference_stream


def run() -> dict[str, int | str | bool]:
    root = Path(__file__).parent.parent
    problem = TypeAdapter(TemplateProblem).validate_json(
        (root / "2026-09-09-cadical-interface-static/problem.json").read_text()
    )
    ds = domains(problem, WorkBudget(time.monotonic() + 60))
    cases = TypeAdapter(list[_Case]).validate_json(
        (root / "2026-09-09-cadical-family-compiler-probe/families.json").read_text()
    )
    actual, reference, stream, before_stream = _pair(ds)
    start = actual.budget.counts["predicates"]
    before_start = reference.budget.counts["predicates"]
    for case in cases:
        assert actual.forbid(case.left, case.right, case.family) == reference.forbid(
            case.left, case.right, case.family
        )
        assert stream.snapshot() == before_stream.snapshot()
        assert actual.rectangles == reference.rectangles
        assert actual.top_id == reference.top_id
    actual_work = actual.budget.counts["predicates"] - start
    reference_work = reference.budget.counts["predicates"] - before_start
    last = cases[-1]
    assert actual.forbid(last.left, last.right, last.family) == 0
    assert reference.forbid(last.left, last.right, last.family) == 0
    assert stream.snapshot() == before_stream.snapshot()
    corpus_count, corpus_hash = stream.snapshot()

    small = tuple(
        Domain(
            Obligation(
                i,
                "iron",
                Fraction(1),
                Endpoint((0, i, 0), (1, 0), 2 * i),
                Endpoint((20, i, 0), (-1, 0), 2 * i + 1),
            ),
            tuple(range(3, 3 + n)),
            ((0, 0),),
            (1, 1, 1),
            tuple(range(n)),
        )
        for i, n in enumerate((3, 4))
    )
    intervals = tuple(
        (a, b, c, d) for a in range(3) for b in range(a, 3) for c in range(4) for d in range(c, 4)
    )
    edge_cases = 0
    for left_mask, right_mask, reverse in product((1, 3, 7), (1, 3, 7), (False, True)):
        new, old, new_stream, old_stream = _pair(small)
        for side in (1, 0) if reverse else (0, 1):
            mask = left_mask if side == 0 else right_mask
            assert new.guard(side, mask) == old.guard(side, mask)
        for rectangle in intervals:
            family = Family(left_mask, right_mask, (rectangle,))
            assert new.forbid(0, 1, family) == old.forbid(0, 1, family)
            assert new_stream.snapshot() == old_stream.snapshot()
            assert new.forbid(0, 1, family) == old.forbid(0, 1, family) == 0
            edge_cases += 1
    for implementation in (FactorCNF, _ReferenceCNF):
        limited = implementation(
            small, lambda clause: None, WorkBudget(time.monotonic() + 60), maximum_rectangles=1
        )
        first = Family(1, 1, ((0, 0, 0, 0),))
        assert limited.forbid(0, 1, first) == 1
        assert limited.forbid(0, 1, first) == 0
        try:
            limited.forbid(0, 1, Family(1, 1, ((1, 1, 1, 1),)))
        except ExperimentRefusal as refusal:
            assert refusal.reason == "POLICY_BOUND"
            assert limited.rectangles == 1
        else:
            raise AssertionError("collision prohibition quota was bypassed")
    assert actual_work < reference_work, (
        "canonical construction work did not decrease",
        actual_work,
        reference_work,
    )
    return {
        "actual_families": len(cases),
        "ordered_clauses": corpus_count,
        "ordered_sha256": corpus_hash,
        "edge_guard_interval_cases": edge_cases,
        "duplicate_and_quota_behavior_unchanged": True,
        "reference_predicates": reference_work,
        "actual_predicates": actual_work,
    }


if __name__ == "__main__":
    print(json.dumps(run(), sort_keys=True))
