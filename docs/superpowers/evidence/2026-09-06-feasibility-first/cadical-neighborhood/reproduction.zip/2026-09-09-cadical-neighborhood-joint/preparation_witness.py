"""Exact old/new primitive preparation on every original mall domain."""

from __future__ import annotations

import json
import time
from fractions import Fraction
from pathlib import Path

from pydantic import TypeAdapter

from .family_geometry import Primitive, PrimitiveIndex
from .template_budget import WorkBudget
from .template_paths import (
    Domain,
    Endpoint,
    FixedPath,
    Obligation,
    TemplateProblem,
    _adapter,
    _middle,
    _segment,
    domains,
)


class _ReferenceIndex:
    """Frozen pre-reuse constructor; intentionally independent of the new index."""

    def __init__(self, domain: Domain, budget: WorkBudget) -> None:
        self.domain = domain
        self.representative = FixedPath(
            (), domain.obligation.source, domain.obligation.sink, domain.obligation.item
        )
        self.primitives: list[Primitive] = []
        self.masks: list[int] = []
        self.combos: list[tuple[int, ...]] = []
        interned: dict[Primitive, int] = {}
        self.occurrences = 0
        for combo in range(len(domain.lengths)):
            budget.charge("predicates")
            sa, rest = divmod(combo, 5 * len(domain.shapes))
            ta, shape = divmod(rest, len(domain.shapes))
            start = _adapter(domain.obligation.source, sa)
            finish = _adapter(domain.obligation.sink, ta)
            middle = _middle((*start[-1][:2], 0), (*finish[-1][:2], 0), domain.shapes[shape])
            raw: list[Primitive] = []
            for adapter in (start, finish):
                for a, b in zip(adapter, adapter[1:], strict=False):
                    segment = _segment(a, b)
                    raw.append(Primitive("G", segment.lo, segment.hi))
                column = (*adapter[-1][:2], 0)
                raw.append(Primitive("R", column, column, adapter[-1][2]))
            for a, b in zip(middle, middle[1:], strict=False):
                segment = _segment(a, b)
                raw.append(Primitive("M", segment.lo, segment.hi))
            ids: list[int] = []
            bit = 1 << combo
            for primitive in raw:
                budget.charge("predicates", 2 + (combo // 64 + 1))
                self.occurrences += 1
                pid = interned.get(primitive)
                if pid is None:
                    pid = len(self.primitives)
                    interned[primitive] = pid
                    self.primitives.append(primitive)
                    self.masks.append(0)
                self.masks[pid] |= bit
                if pid not in ids:
                    ids.append(pid)
            self.combos.append(tuple(ids))


def run() -> dict[str, int | bool]:
    path = Path(__file__).parent.parent / "2026-09-09-cadical-interface-static/problem.json"
    problem = TypeAdapter(TemplateProblem).validate_json(path.read_text())
    reference_budget = WorkBudget(time.monotonic() + 60)
    actual_budget = WorkBudget(time.monotonic() + 60)
    domain_budget = WorkBudget(time.monotonic() + 60)
    original = domains(problem, domain_budget)
    descriptors = combinations = occurrences = 0

    def compare(domain: Domain) -> None:
        nonlocal descriptors, combinations, occurrences
        before = _ReferenceIndex(domain, reference_budget)
        after = PrimitiveIndex(domain, actual_budget)
        assert after.primitives == before.primitives, domain.obligation.ordinal
        assert after.masks == before.masks, domain.obligation.ordinal
        assert after.combos == before.combos, domain.obligation.ordinal
        assert after.occurrences == before.occurrences, domain.obligation.ordinal
        descriptors += len(after.primitives)
        combinations += len(after.combos)
        occurrences += after.occurrences

    for domain in original:
        compare(domain)
    reference_predicates = reference_budget.counts["predicates"]
    actual_predicates = actual_budget.counts["predicates"]
    # Coincident, overlapping and reversed adapters exercise interning across
    # source/sink sides; elevated ports retain descending-riser provenance.
    for source, sink in (
        (Endpoint((0, 0, 7), (1, 0), 1), Endpoint((0, 0, 7), (1, 0), 2)),
        (Endpoint((0, 0, 0), (1, 0), 1), Endpoint((2, 0, 0), (-1, 0), 2)),
        (Endpoint((0, 0, 7), (0, 1), 1), Endpoint((10, 4, 3), (0, -1), 2)),
        (Endpoint((0, 0, 3), (-1, 0), 1), Endpoint((0, 4, 9), (1, 0), 2)),
    ):
        case = TemplateProblem(
            (Obligation(0, "iron", Fraction(1), source, sink),),
            frozenset(),
            (),
            (-4, 0, 8, 24),
            (-4, 0, 8, 24),
            (3, 5, 8, 11),
        )
        compare(domains(case, domain_budget)[0])
    assert actual_predicates < reference_predicates, (actual_predicates, reference_predicates)
    return {
        "original_domains": len(original),
        "edge_domains": 4,
        "ordered_descriptors_masks_and_provenance_equal": True,
        "descriptors_including_edges": descriptors,
        "xy_combinations_including_edges": combinations,
        "occurrences_including_edges": occurrences,
        "original_reference_predicates": reference_predicates,
        "original_actual_predicates": actual_predicates,
    }


if __name__ == "__main__":
    print(json.dumps(run(), sort_keys=True))
