"""Actual SAT models prove compatible retention and safe assumption widening."""

from __future__ import annotations

import json
import time
from fractions import Fraction
from itertools import combinations

from pysat.solvers import Cadical195

from .family_cnf import FactorCNF
from .neighborhood import Neighborhood
from .template_budget import ExperimentRefusal, WorkBudget, WorkLimits
from .template_paths import Endpoint, Obligation, TemplateProblem, domains


def run() -> dict[str, int | bool]:
    budget = WorkBudget(time.monotonic() + 60)
    obligations = tuple(
        Obligation(
            i,
            f"item-{i}",
            Fraction(1),
            Endpoint((i * 30, 0, 3), (1, 0), i * 2),
            Endpoint((i * 30 + 10, 0, 3), (-1, 0), i * 2 + 1),
        )
        for i in range(4)
    )
    ds = domains(TemplateProblem(obligations, frozenset(), (), (), (), (3, 4)), budget)
    graph_cases = 0
    all_pairs = list(combinations(range(4), 2))
    with Cadical195() as solver:
        cnf = FactorCNF(ds, solver.add_clause, budget)
        for mask in range(1 << len(all_pairs)):
            edges = [pair for k, pair in enumerate(all_pairs) if mask & (1 << k)]
            neighborhood = Neighborhood(budget)
            neighborhood.consider([0] * 4, edges, cnf)
            held = set(neighborhood.retained)
            assert all(not (i in held and j in held) for i, j in edges)
            assert all(
                i in held or any((min(i, j), max(i, j)) in edges for j in held) for i in range(4)
            )
            assert solver.solve(assumptions=neighborhood.assumptions)
            model = solver.get_model()
            assert model is not None
            selected = cnf.select(model)
            assert all(selected[i] == 0 for i in held)
            graph_cases += 1

    with Cadical195() as solver:
        cnf = FactorCNF(ds, solver.add_clause, budget)
        neighborhood = Neighborhood(budget)
        neighborhood.consider([0] * 4, [(0, 1)], cnf)
        assert 0 in neighborhood.retained and 1 not in neighborhood.retained
        # A sound binary choice exclusion, conditional on the other path's XY.
        solver.add_clause([-cnf.xy[0][0], -cnf.xy[1][0]])
        assert solver.solve(assumptions=neighborhood.assumptions)
        model = solver.get_model()
        assert model is not None
        selected = cnf.select(model)
        assert selected[0] == selected[2] == selected[3] == 0
        assert selected[1] // len(ds[1].levels) != 0
        # Newly learned geometry requires releasing a formerly retained path.
        solver.add_clause([-cnf.xy[0][0]])
        assert not solver.solve(assumptions=neighborhood.assumptions)
        assert neighborhood.relax(solver.get_core()) == 1
        assert solver.solve(assumptions=neighborhood.assumptions)
        model = solver.get_model()
        assert model is not None and cnf.select(model)[0] // len(ds[0].levels) != 0
        # Equal/worse candidates must not silently reinstate a released hold.
        neighborhood.consider([0] * 4, [(0, 1), (1, 2)], cnf)
        assert solver.solve(assumptions=neighborhood.assumptions)
        assert neighborhood.relax(None) == 2
        assert not neighborhood.assumptions
        # Removing temporary holds preserves previously forbidden *conditional* choices.
        assert solver.solve(assumptions=[cnf.xy[1][0], cnf.height[1][0]])
        # Truly global UNSAT stays UNSAT after all temporary assumptions disappear.
        for literal in cnf.xy[2]:
            solver.add_clause([-literal])
        assert not solver.solve(assumptions=neighborhood.assumptions)

    exhausted = Neighborhood(WorkBudget(time.monotonic() + 60, WorkLimits(predicates=0)))
    try:
        exhausted.consider([0] * 4, [(0, 1)], cnf)
    except ExperimentRefusal as error:
        assert error.reason == "POLICY_BOUND"
    else:
        raise AssertionError("neighborhood construction escaped work accounting")
    return {
        "compatible_graph_cases": graph_cases,
        "native_retention_and_core_recovery": True,
        "no_unconditional_exclusion_from_holds": True,
        "global_unsat_preserved": True,
        "worse_incumbent_does_not_relock": True,
        "charged_construction": True,
    }


if __name__ == "__main__":
    print(json.dumps(run(), sort_keys=True))
