"""Ordered baseline equivalence, independent cells, and relation work reduction."""

from __future__ import annotations

import json
import sys
import time
from collections.abc import Callable
from itertools import product
from pathlib import Path
from typing import Literal, TypedDict, cast

from .family_geometry import Primitive, Rectangle, relation
from .template_budget import WorkBudget
from .template_paths import Cell, _intersection, _Segment

type Relation = Callable[
    [Primitive, Primitive, tuple[int, ...], tuple[int, ...], frozenset[Cell], WorkBudget],
    tuple[Rectangle, ...],
]


class PrimitiveData(TypedDict):
    kind: Literal["G", "M", "R"]
    lo: list[int]
    hi: list[int]
    endpoint_z: int


class CaseData(TypedDict):
    left: PrimitiveData
    right: PrimitiveData
    left_levels: list[int]
    right_levels: list[int]
    owners: list[list[int]]
    rectangles: list[list[int]]


def _bound(levels: tuple[int, ...], value: int, inclusive: bool, budget: WorkBudget) -> int:
    lo, hi = 0, len(levels)
    while lo < hi:
        budget.charge("predicates")
        mid = (lo + hi) // 2
        if levels[mid] < value or (inclusive and levels[mid] == value):
            lo = mid + 1
        else:
            hi = mid
    return lo


def _forbidden(a: _Segment, b: _Segment, owners: frozenset[Cell], budget: WorkBudget) -> bool:
    overlap = _intersection(a, b, budget)
    return overlap is not None and not (overlap.lo == overlap.hi and overlap.lo in owners)


def baseline(
    a: Primitive,
    b: Primitive,
    left_levels: tuple[int, ...],
    right_levels: tuple[int, ...],
    owners: frozenset[Cell],
    budget: WorkBudget,
) -> tuple[Rectangle, ...]:
    """Independent copy of the immutable primitive-preparation relation algorithm."""
    rectangles: list[Rectangle] = []
    previous: tuple[tuple[int, int], ...] = ()
    first_row = 0
    for p, height in enumerate(left_levels):
        bound = a.at(height, budget)
        constants = {bound.lo[2], bound.hi[2], b.endpoint_z if b.kind == "R" else b.lo[2]}
        constants.update(cell[2] for cell in owners)
        budget.charge("predicates", len(constants) + len(owners))
        boundaries = {0, len(right_levels)}
        for value in constants:
            boundaries.add(_bound(right_levels, value, False, budget))
            boundaries.add(_bound(right_levels, value, True, budget))
        budget.charge("predicates", len(boundaries) * max(1, len(boundaries).bit_length()))
        ordered = sorted(boundaries)
        runs: list[tuple[int, int]] = []
        for lo, end in zip(ordered, ordered[1:], strict=False):
            budget.charge("predicates")
            if _forbidden(bound, b.at(right_levels[lo], budget), owners, budget):
                if runs and runs[-1][1] + 1 == lo:
                    runs[-1] = runs[-1][0], end - 1
                else:
                    runs.append((lo, end - 1))
        row = tuple(runs)
        budget.charge("predicates", 1 + len(row) + len(previous))
        if p and row != previous:
            rectangles.extend((first_row, p - 1, lo, hi) for lo, hi in previous)
            first_row = p
        previous = row
    rectangles.extend((first_row, len(left_levels) - 1, lo, hi) for lo, hi in previous)
    budget.charge("predicates", len(rectangles))
    return tuple(rectangles)


def _cells(primitive: Primitive, height: int) -> set[Cell]:
    lo, hi = primitive.lo, primitive.hi
    if primitive.kind == "M":
        lo, hi = (lo[0], lo[1], height), (hi[0], hi[1], height)
    elif primitive.kind == "R":
        lo = (lo[0], lo[1], min(primitive.endpoint_z, height))
        hi = (lo[0], lo[1], max(primitive.endpoint_z, height))
    return set(product(range(lo[0], hi[0] + 1), range(lo[1], hi[1] + 1), range(lo[2], hi[2] + 1)))


def _budget() -> WorkBudget:
    return WorkBudget(time.monotonic() + 60)


def _primitive(data: PrimitiveData) -> Primitive:
    lo, hi = data["lo"], data["hi"]
    return Primitive(data["kind"], (lo[0], lo[1], lo[2]), (hi[0], hi[1], hi[2]), data["endpoint_z"])


def run(target: Relation = relation, corpus_path: str | None = None) -> dict[str, int | bool]:
    primitives = (
        Primitive("G", (-1, 0, 0), (2, 0, 0)),
        Primitive("G", (-1, 0, 2), (2, 0, 2)),
        Primitive("G", (0, -1, 2), (0, 2, 2)),
        Primitive("G", (0, 0, -2), (0, 0, 3)),
        Primitive("G", (0, 0, 2), (0, 0, 2)),
        Primitive("G", (4, 4, 0), (5, 4, 0)),
        Primitive("M", (-1, 0, 0), (2, 0, 0)),
        Primitive("M", (0, -1, 0), (0, 2, 0)),
        Primitive("M", (0, 0, 0), (0, 0, 0)),
        Primitive("M", (1, 0, 0), (3, 0, 0)),
        Primitive("M", (4, 4, 0), (5, 4, 0)),
        Primitive("R", (0, 0, 0), (0, 0, 0), -2),
        Primitive("R", (0, 0, 0), (0, 0, 0), 0),
        Primitive("R", (0, 0, 0), (0, 0, 0), 3),
        Primitive("R", (2, 0, 0), (2, 0, 0), 2),
        Primitive("R", (4, 4, 0), (4, 4, 0), 5),
    )
    level_sets = ((), (-2, 0, 3), (-1, 2, 5), (0,))
    owner_sets = (
        frozenset[Cell](),
        frozenset({(0, 0, 0)}),
        frozenset({(0, 0, 2), (0, 0, 3)}),
        frozenset({(-1, 0, 0), (0, 0, 0), (1, 0, 0), (2, 0, 0)}),
        frozenset({(9, 9, -2), (9, 9, 2)}),
    )
    comparisons = cells_checked = 0
    for left, right in product(primitives, repeat=2):
        for left_levels, right_levels in product(level_sets, repeat=2):
            for owners in owner_sets:
                actual = target(left, right, left_levels, right_levels, owners, _budget())
                expected = baseline(left, right, left_levels, right_levels, owners, _budget())
                assert actual == expected, (
                    left,
                    right,
                    left_levels,
                    right_levels,
                    owners,
                    actual,
                    expected,
                )
                comparisons += 1
                for p, height in enumerate(left_levels):
                    for q, other_height in enumerate(right_levels):
                        overlap = _cells(left, height) & _cells(right, other_height)
                        forbidden = bool(overlap) and not (len(overlap) == 1 and overlap <= owners)
                        matches = sum(a <= p <= b and c <= q <= d for a, b, c, d in actual)
                        assert matches == int(forbidden), (
                            left,
                            right,
                            height,
                            other_height,
                            owners,
                        )
                        cells_checked += 1

    corpus_cases = corpus_old_work = corpus_new_work = 0
    if corpus_path is not None:
        cases = cast(list[CaseData], json.loads(Path(corpus_path).read_text()))
        for case in cases:
            left, right = _primitive(case["left"]), _primitive(case["right"])
            left_levels, right_levels = tuple(case["left_levels"]), tuple(case["right_levels"])
            owners = frozenset((cell[0], cell[1], cell[2]) for cell in case["owners"])
            old_budget, new_budget = _budget(), _budget()
            expected = baseline(left, right, left_levels, right_levels, owners, old_budget)
            actual = target(left, right, left_levels, right_levels, owners, new_budget)
            assert actual == expected, (corpus_cases, actual, expected)
            recorded = tuple((r[0], r[1], r[2], r[3]) for r in case["rectangles"])
            assert actual == recorded, (corpus_cases, actual, recorded)
            corpus_cases += 1
            corpus_old_work += old_budget.counts.get("predicates", 0)
            corpus_new_work += new_budget.counts.get("predicates", 0)

    levels = tuple(range(3, 27))
    left = Primitive("M", (0, 0, 0), (4, 0, 0))
    right = Primitive("M", (2, -2, 0), (2, 2, 0))
    old_budget, new_budget = _budget(), _budget()
    expected = baseline(left, right, levels, levels, frozenset(), old_budget)
    actual = target(left, right, levels, levels, frozenset(), new_budget)
    assert actual == expected == tuple((i, i, i, i) for i in range(24))
    old_work = old_budget.counts.get("predicates", 0)
    new_work = new_budget.counts.get("predicates", 0)
    assert new_work < old_work, ("common diagonal work must decrease", old_work, new_work)
    if corpus_cases:
        assert corpus_new_work < corpus_old_work, (
            "real corpus work must decrease",
            corpus_old_work,
            corpus_new_work,
        )
    return {
        "ordered_small_relations": comparisons,
        "independent_height_pair_cells": cells_checked,
        "common_rectangles": len(actual),
        "common_baseline_predicates": old_work,
        "common_new_predicates": new_work,
        "corpus_ordered_relations": corpus_cases,
        "corpus_baseline_predicates": corpus_old_work,
        "corpus_new_predicates": corpus_new_work,
        "exact_ordered_rectangles_and_cells": True,
    }


if __name__ == "__main__":
    print(json.dumps(run(corpus_path=sys.argv[1] if len(sys.argv) > 1 else None), sort_keys=True))
