"""Capture actual Family compiler inputs from immutable baseline; not acceptance."""
import ast
import importlib
import inspect
import json
import sys
import time
from dataclasses import asdict
from pathlib import Path
from pydantic import TypeAdapter

name=sys.argv[1]
module=importlib.import_module(name+'.template_cadical')
paths=importlib.import_module(name+'.template_paths')
root=Path(__file__).parent
problem=TypeAdapter(paths.TemplateProblem).validate_json((root.parent/'2026-09-09-cadical-interface-static/problem.json').read_text())
events=[]
def capture(left,right,family):
    events.append({'left':left,'right':right,'family':asdict(family)})
lines=[]
inserted=0
for line in inspect.getsource(module.select).splitlines():
    lines.append(line)
    if line.strip().startswith('family = primitive_indexes[i].family('):
        indent=line[:len(line)-len(line.lstrip())]
        lines.append(indent+'_capture_family(i,j,family)')
        inserted+=1
assert inserted==1
module.__dict__['_capture_family']=capture
exec(compile(ast.parse('\n'.join(lines)),'<family-compiler-inputs>','exec'),module.__dict__)
budget=module.WorkBudget(time.monotonic()+60)
stats=module.SolveStats()
try:
    module.select(problem,budget,stats)
except module.ExperimentRefusal as refusal:
    reason=refusal.detail
else:
    reason=None
(root/'families.json').write_text(json.dumps(events))
report={'scope':'diagnostic corpus, not acceptance','revision':name,'families':len(events),'reason':reason,'work':budget.counts,'stats':asdict(stats)}
(root/'capture-report.json').write_text(json.dumps(report,indent=2))
print(json.dumps({'families':len(events),'reason':reason,'work':budget.counts}))
