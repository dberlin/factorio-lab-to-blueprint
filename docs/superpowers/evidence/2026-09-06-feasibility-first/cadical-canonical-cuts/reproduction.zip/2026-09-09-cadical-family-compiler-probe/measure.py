"""Coarse explicit compiler boundaries, not tracing/function-level profiling."""
import ast
import importlib
import inspect
import json
import sys
import time
import textwrap
from dataclasses import asdict
from pathlib import Path

from pydantic import TypeAdapter

name = sys.argv[1]
module = importlib.import_module(name + ".template_cadical")
paths = importlib.import_module(name + ".template_paths")
root = Path(__file__).parent
problem_path = root.parent / "2026-09-09-cadical-interface-static/problem.json"
problem = TypeAdapter(paths.TemplateProblem).validate_json(problem_path.read_text())
budget = module.WorkBudget(time.monotonic() + 60)
stats = module.SolveStats()
ledger = {}
phase = "domains_and_static_geometry"
last_counts = {}
last_time = time.monotonic()


def mark(next_phase):
    global phase, last_counts, last_time
    now = time.monotonic()
    row = ledger.setdefault(phase, {"seconds": 0.0, "work": {}})
    row["seconds"] += now - last_time
    for key, value in budget.counts.items():
        delta = value - last_counts.get(key, 0)
        row["work"][key] = row["work"].get(key, 0) + delta
    phase, last_counts, last_time = next_phase, dict(budget.counts), now


# Inject only explicit phase boundaries into an in-memory copy of the selector.
# No function wrappers, stack inspection, per-call counters, or source mutation.
source = inspect.getsource(module.select)
markers = {
    "primitive_indexes =": "primitive_membership_preparation",
    "factors = FactorCNF": "factor_cardinality_threshold_cnf",
    "for di, rejected in enumerate(rejected_entries)": "static_exclusion_cnf",
    "stats.preparation_seconds =": "native_solve",
    "budget.charge(\"assignments\")": "native_solve",
    "model = solver.get_model()": "selected_model_decode",
    "geometries =": "selected_path_checks",
    "pair = i, j": "selected_pair_checks",
    "ca, p = divmod": "family_provenance",
    "emitted = factors.forbid": "family_guards",
    "new_cuts += emitted": "family_metadata",
    "new_cuts = 0": "selected_pair_checks",
    "if new_cuts:": "selected_pair_checks",
}
lines = []
seen = set()
for line in source.splitlines():
    for prefix, label in markers.items():
        if line.strip().startswith(prefix):
            indent = line[:len(line) - len(line.lstrip())]
            lines.append(indent + f"_ledger_mark({label!r})")
            seen.add(prefix)
    lines.append(line)
assert seen == set(markers), set(markers) - seen
module.__dict__["_ledger_mark"] = mark
exec(compile(ast.parse("\n".join(lines)), "<coarse-phase-ledger>", "exec"), module.__dict__)
# Explicit compiler stages, not a function profiler or call wrapper.
def instrument_method(module_name, class_name, method_name, stage_markers):
    owner_module = importlib.import_module(name + "." + module_name)
    owner_class = getattr(owner_module, class_name)
    method_source = textwrap.dedent(inspect.getsource(getattr(owner_class, method_name)))
    rewritten = []
    found = set()
    for line in method_source.splitlines():
        for prefix, label in stage_markers.items():
            if line.strip().startswith(prefix):
                indent = line[:len(line) - len(line.lstrip())]
                rewritten.append(indent + f"_ledger_mark({label!r})")
                found.add(prefix)
        rewritten.append(line)
    assert found == set(stage_markers)
    owner_module.__dict__["_ledger_mark"] = mark
    exec(compile(ast.parse("\n".join(rewritten)), "<explicit-family-stages>", "exec"), owner_module.__dict__)
    setattr(owner_class, method_name, owner_module.__dict__.pop(method_name))
instrument_method("family_geometry", "PrimitiveIndex", "family", {
    "rectangles = relation(": "height_relation",
    "if not any(": "family_confirmation",
})
instrument_method("family_cnf", "FactorCNF", "forbid", {
    "before = self.rectangles": "family_rectangle_cnf",
})
outcome = "GEOMETRY_COMPLETE"
reason = None
try:
    module.select(problem, budget, stats)
except module.ExperimentRefusal as failure:
    outcome, reason = failure.reason, failure.detail
finally:
    mark("finished")
report = {"scope": "saved actual geometry,60s diagnostic; excludes emitter/settlement; not original acceptance", "revision": name, "outcome": outcome, "reason": reason, "phases": ledger, "work": budget.counts, "stats": asdict(stats)}
for key, value in budget.counts.items():
    assert sum(row["work"].get(key, 0) for row in ledger.values()) == value
(root / (name + ".json")).write_text(json.dumps(report, indent=2))
print(json.dumps(report, sort_keys=True))
