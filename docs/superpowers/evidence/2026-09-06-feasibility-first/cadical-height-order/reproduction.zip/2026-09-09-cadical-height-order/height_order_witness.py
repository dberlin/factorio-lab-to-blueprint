"""Verify compatibility under increasing z remappings fixing every endpoint level.

XY combinations are unchanged. Endpoint-height classes and the two chosen
heights' order determine a remapping preserving segment intersections and
singleton endpoint ownership. Actual collision cells are never cached by this key.
"""

from __future__ import annotations

import json
import random
import time
from fractions import Fraction

from .template_budget import WorkBudget
from .template_cadical import height_classes, height_order_key
from .template_paths import Endpoint, Obligation, TemplateProblem, _compatible, domains


def run() -> dict[str, int | bool]:
    comparisons = reused = 0
    outcomes: set[bool] = set()
    rng = random.Random(41)
    for (az, bz, cz, dz), shared in (
        ((0, 0, 0, 0), False),
        ((0, 7, 3, 7), False),
        ((7, 3, 7, 0), False),
        ((7, 7, 7, 7), False),
        ((0, 0, 0, 0), True),
    ):
        budget = WorkBudget(time.monotonic() + 60)
        first_source = Endpoint((0, 0 if shared else 5, az), (1, 0), 1, 99 if shared else None)
        second_source = Endpoint(
            (0, 0, cz) if shared else (10, -5, cz), (0, 1), 3, 99 if shared else None
        )
        obligations = (
            Obligation(0, "iron", Fraction(1), first_source, Endpoint((20, 5, bz), (-1, 0), 2)),
            Obligation(1, "iron", Fraction(1), second_source, Endpoint((10, 15, dz), (0, -1), 4)),
        )
        problem = TemplateProblem(
            obligations,
            frozenset(),
            (),
            (-4, 8, 24),
            (-4, 8, 24),
            (3, 4, 5, 6, 7, 8, 9, 11),
        )
        first, second = domains(problem, budget)
        ranks = height_classes(problem, budget)
        combinations = {(0, 0)}
        while len(combinations) < 32:
            combinations.add(
                (rng.randrange(len(first.lengths)), rng.randrange(len(second.lengths)))
            )
        seen: dict[tuple[int, int, int, int, int], bool] = {}
        for first_combo, second_combo in sorted(combinations):
            first_geometries = [
                first._decode(first_combo * len(first.levels) + zi, budget)
                for zi in range(len(first.levels))
            ]
            second_geometries = [
                second._decode(second_combo * len(second.levels) + zi, budget)
                for zi in range(len(second.levels))
            ]
            for first_height, a in zip(first.levels, first_geometries, strict=True):
                for second_height, b in zip(second.levels, second_geometries, strict=True):
                    key = height_order_key(
                        (first_combo, ranks[first_height], first_height),
                        (second_combo, ranks[second_height], second_height),
                        budget,
                    )
                    actual = _compatible(a, b, budget)
                    if key in seen:
                        assert seen[key] == actual, (key, first_height, second_height, shared)
                        reused += 1
                    else:
                        seen[key] = actual
                    comparisons += 1
                    outcomes.add(actual)
    assert outcomes == {False, True}
    return {
        "canonical_comparisons": comparisons,
        "repeated_equivalence_checks": reused,
        "height_order_equivalence": True,
        "endpoint_equalities_and_descending_risers": True,
        "owned_shared_endpoint_case": True,
    }


if __name__ == "__main__":
    print(json.dumps(run(), sort_keys=True))
