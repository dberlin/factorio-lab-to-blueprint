"""Independent, bounded physical audit; a capacity witness is NOT a service theorem.

Only actual Placement/codec records are inputs. No constructor links, planned
rates or selector predicates enter this module. Native mechanical checks retain
their own authority; the additional centreline audit expands complete links.
The caller must interrupt indivisible native calls at the absolute deadline.
"""

from __future__ import annotations

import math
from collections import defaultdict, deque
from collections.abc import Iterator
from dataclasses import dataclass, replace
from fractions import Fraction

from flab2bp.dsp import catalog, codec, colliders, splitter_ports
from flab2bp.dsp.records import BlueprintBuilding
from flab2bp.layout import validate
from flab2bp.layout.base import AreaFrame, PlacedBuilding, Placement
from flab2bp.spec import BuildSpec, MachineGroup

from .template_budget import WorkBudget

Cell = tuple[int, int, Fraction]
Point = tuple[float, float, float]

# Deliberately no flow.* checks: their fair-share propagation is not our model.
MECHANICAL_CHECKS = (
    "geom.footprint",
    "geom.overlap",
    "geom.collide",
    "game.sorter_collide",
    "geom.belt_single_occupancy",
    "geom.machine_ground",
    "geom.altitude_range",
    "geom.altitude_step",
    "geom.bounds",
    "sorter.anchors_present",
    "sorter.reach",
    "sorter.endpoints",
    "sorter.endpoint_pair",
    "sorter.own_slots",
    "sorter.peer_slots",
    "game.inserter_data",
    "game.slot_occupancy",
    "game.inserter_paste",
    "game.inserter_skew",
    "game.belt_crossing",
    "game.belt_collide",
    "sorter.filter",
    "sorter.output_filter",
    "belt.continuity",
    "junction.stack_support",
    "junction.ports",
    "junction.colocated",
    "junction.port_pose",
    "junction.records_no_links",
    "piler.ports",
    "belt.link_adjacent",
    "belt.port_dock",
    "belt.acyclic",
    "belt.tier_allowed",
    "sorter.tier_allowed",
    "piler.tier_allowed",
    "machine.recipe_valid",
    "machine.group_resolved",
    "spec.machine_counts",
)


@dataclass(frozen=True)
class AuditReport:
    passed: bool
    findings: tuple[str, ...]
    buildings: int
    belt_links: int
    expanded_cells: int
    mechanical_checks: tuple[str, ...]
    decoded: bool = False
    scope: str = "catalog and full-link probes; not terrain or in-game paste proof"


@dataclass(frozen=True)
class CapacityEdge:
    source: str
    sink: str
    capacity: Fraction
    flow: Fraction
    kind: str
    buildings: tuple[int, ...] = ()


@dataclass(frozen=True)
class CapacityCut:
    required: Fraction
    achieved: Fraction
    capacity: Fraction
    source_side: tuple[str, ...]
    edges: tuple[CapacityEdge, ...]


@dataclass(frozen=True)
class BoundaryPort:
    building: int
    item: str
    direction: str
    capacity: Fraction


@dataclass(frozen=True)
class RateReport:
    status: str
    capacity_feasible: bool
    findings: tuple[str, ...]
    model_complete: bool
    upper_bound_feasible: bool
    required: Fraction
    achieved: Fraction
    edges: tuple[CapacityEdge, ...]
    cut: CapacityCut | None
    boundary_ports: tuple[BoundaryPort, ...]
    assumptions: tuple[str, ...]
    unproved_mechanics: tuple[str, ...]
    model: str = "joint exact flow on physical resources; steady-state relaxation only"


def _context(
    placement: Placement, spec: BuildSpec, rules: catalog.BeltAltitudeRules, budget: WorkBudget
) -> validate.Context:
    budget.check()
    # Account native index input before calling its indivisible implementation.
    budget.charge("audit_cells", sum(b.width * b.height for b in placement.buildings))
    result = validate._context(
        placement, spec, validate.id_map(spec), 256, rules.max_z, rules.vertical_construction
    )
    budget.check()
    return result


def _cell(building: PlacedBuilding) -> Cell:
    return building.x, building.y, building.z


def _segment_cells(start: Cell, end: Cell, budget: WorkBudget) -> Iterator[Cell]:
    """All half-altitude lattice points, including interiors of arbitrarily tall links."""
    dx, dy, dz = end[0] - start[0], end[1] - start[1], end[2] - start[2]
    # Ramps have one horizontal axis and a half-level rise, not free diagonals.
    if sum(value != 0 for value in (dx, dy, dz)) > 1 and (
        dx and dy or not (dx or dy) or abs(dz) > Fraction(max(abs(dx), abs(dy)), 2)
    ):
        raise ValueError(f"non-template segment {start}->{end}")
    steps = max(abs(dx), abs(dy), math.ceil(abs(dz) * 2), 1)
    for step in range(steps + 1):
        budget.charge("audit_cells")
        x = Fraction(start[0]) + Fraction(dx * step, steps)
        y = Fraction(start[1]) + Fraction(dy * step, steps)
        z = start[2] + dz * Fraction(step, steps)
        # Horizontal nodes are integer cells. Vertical probes include half-levels.
        if x.denominator != 1 or y.denominator != 1:
            continue
        yield int(x), int(y), z


def _dock_owners(placement: Placement, budget: WorkBudget) -> dict[int, tuple[int, int]]:
    """Only validated, distinct actual port identities may share the abstract seat."""
    bs = placement.buildings
    ports = splitter_ports.placement_port_context(bs)
    owners: dict[int, tuple[int, int]] = {}
    claimed: dict[tuple[int, int], int] = {}
    for i, b in enumerate(bs):
        budget.check()
        if not catalog.is_belt(b.item_id):
            continue
        for peer, slot, direction in (
            (b.output_obj, b.output_to_slot, "feed"),
            (b.input_obj, b.input_from_slot, "draw"),
        ):
            if peer is None or not 0 <= peer < len(bs) or bs[peer].item_id != catalog.SPLITTER_ID:
                continue
            expected = ports.expected_port(i, peer, "feed" if direction == "feed" else "draw")
            if expected is None or expected != slot:
                continue
            key = (peer, slot)
            if key in claimed:
                # Neither duplicated claimant earns a geometry exception.
                owners.pop(claimed[key], None)
                continue
            claimed[key] = i
            owners[i] = key
    return owners


def _shared_seat(
    first: int, second: int, owners: dict[int, tuple[int, int]], bs: tuple[PlacedBuilding, ...]
) -> bool:
    a, b = owners.get(first), owners.get(second)
    return (
        a is not None
        and b is not None
        and a[0] == b[0]
        and a[1] != b[1]
        and bs[first].carries_item == bs[second].carries_item
    )


def _full_segments(placement: Placement, budget: WorkBudget) -> tuple[list[str], int, int]:
    bs = placement.buildings
    owners = _dock_owners(placement, budget)
    findings: list[str] = []
    at: dict[Cell, list[tuple[int, int]]] = defaultdict(list)
    links: list[tuple[int, int]] = []
    belts = [i for i, b in enumerate(bs) if catalog.is_belt(b.item_id)]
    incoming: dict[int, int] = defaultdict(int)
    for i in belts:
        budget.check()
        target = bs[i].output_obj
        if target is not None and 0 <= target < len(bs) and catalog.is_belt(bs[target].item_id):
            links.append((i, target))
            incoming[target] += 1
            one, two = bs[i].carries_item, bs[target].carries_item
            if one is not None and two is not None and one != two:
                findings.append(f"ITEM_DIRECTION: belt {i}->{target} changes {one} to {two}")
        predecessor = bs[i].input_obj
        if (
            predecessor is not None
            and 0 <= predecessor < len(bs)
            and catalog.is_belt(bs[predecessor].item_id)
            and bs[predecessor].output_obj != i
        ):
            findings.append(f"BELT_DIRECTION_OWNERSHIP: {i} input {predecessor} lacks forward link")
    attachment_neighbours: dict[int, set[int]] = defaultdict(set)
    for source, sink in links:
        for endpoint, neighbour in ((source, sink), (sink, source)):
            if endpoint in owners:
                a, b = bs[endpoint], bs[neighbour]
                if a.z == b.z and abs(a.x - b.x) + abs(a.y - b.y) == 1:
                    attachment_neighbours[neighbour].add(owners[endpoint][0])
    for i, count in incoming.items():
        if count > 1:
            findings.append(
                f"ENDPOINT_OWNERSHIP: belt {i} has {count} feeders without an explicit junction"
            )
    # Include isolated and terminal nodes: unrelated endpoint coincidence is a conflict.
    primitives = links + [(i, i) for i in belts]
    before = budget.counts.get("audit_cells", 0)
    collider_buckets: dict[tuple[int, int], list[tuple[int, colliders.Box]]] = defaultdict(list)
    for i, b in enumerate(bs):
        budget.check()
        if catalog.is_belt(b.item_id) or catalog.is_sorter(b.item_id):
            continue
        x, y, z = codec.tile_to_local_offset(b.x, b.y, b.z, b.width, b.height)
        for box in colliders.target_boxes(b, *colliders.flat_pose(x, y, z, b.yaw)):
            radius = math.sqrt(sum(h * h for h in box.half)) + colliders.BELT_PROBE_RADIUS
            left, right = (
                math.floor((box.centre[0] - radius) / colliders.GRID_ARC),
                math.ceil((box.centre[0] + radius) / colliders.GRID_ARC),
            )
            low, high = (
                math.floor((box.centre[2] - radius) / colliders.GRID_ARC),
                math.ceil((box.centre[2] + radius) / colliders.GRID_ARC),
            )
            for xcell in range(left, right + 1):
                for ycell in range(low, high + 1):
                    budget.charge("audit_cells")
                    collider_buckets[xcell, ycell].append((i, box))
    seen_conflicts: set[tuple[int, int, int, int]] = set()
    seen_colliders: set[tuple[int, int, int]] = set()
    for source, sink in primitives:
        start, end = _cell(bs[source]), _cell(bs[sink])
        try:
            cells = _segment_cells(start, end, budget)
            for cell in cells:
                endpoint_ids = {i for i in (source, sink) if _cell(bs[i]) == cell}
                for a, b in at[cell]:
                    budget.charge("predicates")
                    if (a, b) == (source, sink):
                        continue
                    other_ids = {i for i in (a, b) if _cell(bs[i]) == cell}
                    if endpoint_ids & other_ids:
                        continue  # Actual shared belt vertex, never just shared coordinates.
                    if (
                        endpoint_ids
                        and other_ids
                        and all(
                            _shared_seat(i, j, owners, bs) for i in endpoint_ids for j in other_ids
                        )
                    ):
                        continue
                    key = (min(source, a), max(source, a), min(sink, b), max(sink, b))
                    if key not in seen_conflicts:
                        seen_conflicts.add(key)
                        findings.append(
                            f"FULL_SEGMENT_CONFLICT: {source}->{sink} and {a}->{b} at {cell}"
                        )
                at[cell].append((source, sink))
                for building, box in collider_buckets.get((cell[0], cell[1]), ()):
                    budget.charge("predicates")
                    key = (source, sink, building)
                    if key in seen_colliders:
                        continue
                    # Seat and first attachment segment belong ONLY to that exact host.
                    own_ends = [i for i in (source, sink) if owners.get(i, (-1, -1))[0] == building]
                    if (
                        own_ends
                        and start[2] == end[2]
                        and max(abs(start[0] - end[0]), abs(start[1] - end[1])) <= 1
                    ):
                        continue
                    if any(building in attachment_neighbours.get(i, set()) for i in endpoint_ids):
                        continue
                    if colliders.sphere_box_overlap(
                        colliders.belt_probe(float(cell[0]), float(cell[1]), float(cell[2])),
                        colliders.BELT_PROBE_RADIUS,
                        box,
                    ):
                        seen_colliders.add(key)
                        findings.append(
                            f"SEGMENT_CLEARANCE: {source}->{sink}, body {building}, {cell}"
                        )
        except ValueError as error:
            findings.append(f"UNSUPPORTED_SEGMENT: {source}->{sink}: {error}")
    return findings, len(links), budget.counts.get("audit_cells", 0) - before


def audit_placement(
    placement: Placement, spec: BuildSpec, rules: catalog.BeltAltitudeRules, budget: WorkBudget
) -> AuditReport:
    """Audit a slot-bound emitted/finalized artifact; never repair it on the caller's behalf."""
    ctx = _context(placement, spec, rules, budget)
    findings: list[str] = []
    for name in MECHANICAL_CHECKS:
        budget.check()
        for finding in validate.CHECKS[name](ctx):
            budget.check()
            if finding.severity is validate.Severity.ERROR:
                findings.append(
                    f"{name}: {finding.message}; {finding.buildings}; {dict(finding.detail)}"
                )
        budget.check()
    extra, links, expanded = _full_segments(placement, budget)
    findings.extend(extra)
    return AuditReport(
        not findings, tuple(findings), len(placement.buildings), links, expanded, MECHANICAL_CHECKS
    )


def _grid(value: float, description: str, *, half: bool = False) -> Fraction:
    if not math.isfinite(value):
        raise ValueError(f"{description} is not finite")
    denominator = 2 if half else 1
    result = Fraction(round(value * denominator), denominator)
    if abs(float(result) - value) > 0.0001:
        raise ValueError(f"{description}={value} is outside the experiment's emitted lattice")
    return result


def _subtract(a: Point, b: Point) -> Point:
    return a[0] - b[0], a[1] - b[1], a[2] - b[2]


def _cross(a: Point, b: Point) -> Point:
    return a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]


def _dot(a: Point, b: Point) -> float:
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def _physical_intersection(a: Point, b: Point, c: Point, d: Point) -> Point | None:
    """Intersection of actual decoded closed straight segments, including overlap."""
    u, v, w = _subtract(b, a), _subtract(d, c), _subtract(c, a)
    normal = _cross(u, v)
    divisor = _dot(normal, normal)
    tolerance = 1e-7
    if divisor > tolerance * tolerance:
        first = _dot(_cross(w, v), normal) / divisor
        second = _dot(_cross(w, u), normal) / divisor
        if not -tolerance <= first <= 1 + tolerance or not -tolerance <= second <= 1 + tolerance:
            return None
        p = (a[0] + first * u[0], a[1] + first * u[1], a[2] + first * u[2])
        q = (c[0] + second * v[0], c[1] + second * v[1], c[2] + second * v[2])
        return p if math.dist(p, q) <= tolerance else None
    length = _dot(u, u)
    if length <= tolerance * tolerance:
        other_length = _dot(v, v)
        if other_length <= tolerance * tolerance:
            return a if math.dist(a, c) <= tolerance else None
        t = _dot(_subtract(a, c), v) / other_length
        closest = (c[0] + t * v[0], c[1] + t * v[1], c[2] + t * v[2])
        return (
            a if -tolerance <= t <= 1 + tolerance and math.dist(a, closest) <= tolerance else None
        )
    if _dot(_cross(w, u), _cross(w, u)) > tolerance * tolerance * length:
        return None
    first = _dot(w, u) / length
    second = _dot(_subtract(d, a), u) / length
    low, high = max(0.0, min(first, second)), min(1.0, max(first, second))
    if low > high + tolerance:
        return None
    t = (low + high) / 2
    return a[0] + t * u[0], a[1] + t * u[1], a[2] + t * u[2]


def _decoded_segments(records: tuple[BlueprintBuilding, ...], budget: WorkBudget) -> list[str]:
    """Spatially indexed algebraic intersections; no rounded/lost codec poses."""
    by_id = {record.index: record for record in records}
    segments: list[tuple[int, int, Point, Point]] = []
    for record in records:
        budget.check()
        if not all(math.isfinite(value) for value in (record.x, record.y, record.z)):
            return [f"DECODED_POSE: record {record.index} has a nonfinite anchor"]
        if not catalog.is_belt(record.item_id):
            continue
        point = (record.x, record.y, record.z)
        segments.append((record.index, record.index, point, point))
        target = by_id.get(record.output_obj_idx)
        if target is not None and catalog.is_belt(target.item_id):
            segments.append((record.index, target.index, point, (target.x, target.y, target.z)))
    buckets: dict[tuple[int, int, int], list[int]] = defaultdict(list)
    findings: list[str] = []
    for ordinal, (source, sink, a, b) in enumerate(segments):
        candidates: set[int] = set()
        cells: list[tuple[int, int, int]] = []
        # Real emitted segments are axis-aligned except the catalog-shifted short
        # dock attachment. The AABB supercover also contains those shifted poses.
        for x in range(math.floor(min(a[0], b[0]) - 1e-7), math.floor(max(a[0], b[0]) + 1e-7) + 1):
            for y in range(
                math.floor(min(a[1], b[1]) - 1e-7), math.floor(max(a[1], b[1]) + 1e-7) + 1
            ):
                for z in range(
                    math.floor(min(a[2], b[2]) - 1e-7), math.floor(max(a[2], b[2]) + 1e-7) + 1
                ):
                    budget.charge("audit_cells")
                    key = (x, y, z)
                    cells.append(key)
                    candidates.update(buckets[key])
        for other in sorted(candidates):
            budget.charge("predicates")
            first, last, c, d = segments[other]
            hit = _physical_intersection(a, b, c, d)
            if hit is None:
                continue
            one = {i for i, p in ((source, a), (sink, b)) if math.dist(p, hit) < 1e-7}
            two = {i for i, p in ((first, c), (last, d)) if math.dist(p, hit) < 1e-7}
            if one & two:
                continue
            findings.append(
                f"DECODED_FULL_SEGMENT: {source}->{sink} and {first}->{last} intersect at {hit}"
            )
        for key in cells:
            buckets[key].append(ordinal)
    return findings


def audit_blueprint(
    blueprint: str, spec: BuildSpec, rules: catalog.BeltAltitudeRules, budget: WorkBudget
) -> AuditReport:
    """Audit decoded links and dock anchors before pose normalization."""
    budget.check()
    decoded = codec.decode(blueprint)
    budget.check()
    if not decoded.hash_valid or len(decoded.areas) != 1:
        return AuditReport(
            False,
            ("DECODED_ARTIFACT: invalid hash or unsupported multiple areas",),
            len(decoded.buildings),
            0,
            0,
            (),
            True,
        )
    area = decoded.areas[0]
    frame = AreaFrame(area.width, area.height, area.area_segments, (area.area_segments,), False)
    findings = _decoded_segments(decoded.buildings, budget)
    for issue in splitter_ports.blueprint_issues(decoded.buildings, frame=frame):
        budget.check()
        findings.append(f"DECODED_PORT_POSE: {issue.message}; {issue.detail()}")
    ids = {b.index: i for i, b in enumerate(decoded.buildings)}
    if len(ids) != len(decoded.buildings):
        findings.append("DECODED_IDENTITY: duplicate building IDs")
    rebuilt: list[PlacedBuilding] = []
    try:
        for record in decoded.buildings:
            budget.charge("audit_cells")
            if record.area_index != area.index or any(
                (record.tilt, record.tilt2, record.pitch, record.pitch2)
            ):
                raise ValueError(f"record {record.index}: unsupported area or nonzero tilt/pitch")
            width, height = catalog.oriented_footprint(record.item_id, record.yaw)
            x, y, z = record.x, record.y, record.z
            # Splitter stubs encode physical slot anchors, not the abstract seat.
            # Their exact *decoded* anchors have already passed blueprint_issues.
            if catalog.is_belt(record.item_id):
                for peer in (record.input_obj_idx, record.output_obj_idx):
                    if peer in ids and decoded.buildings[ids[peer]].item_id == catalog.SPLITTER_ID:
                        host = decoded.buildings[ids[peer]]
                        x, y = host.x, host.y
                        # Height is a catalog port elevation, not the host's anchor.
                        slot = (
                            record.input_from_slot
                            if peer == record.input_obj_idx
                            else record.output_to_slot
                        )
                        poses = catalog.port_poses_for_model(host.model_index)
                        if not 0 <= slot < len(poses):
                            raise ValueError(
                                f"record {record.index}: nonexistent splitter slot {slot}"
                            )
                        z = host.z + poses[slot].dz * float(catalog.BELT_Z_PER_WORLD_UNIT)
            output = None if record.output_obj_idx == -1 else ids.get(record.output_obj_idx)
            incoming = None if record.input_obj_idx == -1 else ids.get(record.input_obj_idx)
            if (
                record.output_obj_idx != -1
                and output is None
                or record.input_obj_idx != -1
                and incoming is None
            ):
                raise ValueError(f"record {record.index}: dangling link identity")
            sorter = catalog.is_sorter(record.item_id)
            rebuilt.append(
                PlacedBuilding(
                    item_id=record.item_id,
                    model_index=record.model_index,
                    x=int(_grid(x - width / 2 + 0.5, f"{record.index}.x")),
                    y=int(_grid(y - height / 2 + 0.5, f"{record.index}.y")),
                    z=_grid(z, f"{record.index}.z", half=True),
                    width=width,
                    height=height,
                    yaw=record.yaw,
                    x2=int(_grid(record.x2, f"{record.index}.x2")) if sorter else None,
                    y2=int(_grid(record.y2, f"{record.index}.y2")) if sorter else None,
                    z2=_grid(record.z2, f"{record.index}.z2", half=True) if sorter else None,
                    yaw2=record.yaw2 if sorter else None,
                    recipe_id=record.recipe_id,
                    filter_id=record.filter_id,
                    output_obj=output,
                    input_obj=incoming,
                    output_to_slot=record.output_to_slot,
                    input_from_slot=record.input_from_slot,
                    output_from_slot=record.output_from_slot,
                    input_to_slot=record.input_to_slot,
                    output_offset=record.output_offset,
                    input_offset=record.input_offset,
                    parameters=record.parameters,
                )
            )
    except (ValueError, KeyError) as error:
        findings.append(f"DECODED_POSE: {error}")
        return AuditReport(False, tuple(findings), len(decoded.buildings), 0, 0, (), True)
    # Item attribution comes from encoded filters/icons/recipes, not the lost carries_item field.
    placement = Placement(tuple(rebuilt), frame=frame)
    items, _, attribution = _incidence(placement, spec, rules, budget)
    findings.extend(attribution)
    placement = replace(
        placement,
        buildings=tuple(
            replace(b, carries_item=items.get(i)) for i, b in enumerate(placement.buildings)
        ),
    )
    report = audit_placement(placement, spec, rules, budget)
    return replace(
        report,
        passed=report.passed and not findings,
        findings=tuple(findings) + report.findings,
        decoded=True,
    )


def _incidence(
    placement: Placement, spec: BuildSpec, rules: catalog.BeltAltitudeRules, budget: WorkBudget
) -> tuple[dict[int, str], dict[int, MachineGroup], list[str]]:
    """Attribute entire connected transport components; mixed resources never get cloned."""
    ctx = _context(placement, spec, rules, budget)
    bs = placement.buildings
    machine: dict[int, MachineGroup] = {}
    problems: list[str] = []
    for i, kind in enumerate(ctx.kinds):
        budget.check()
        if kind is validate.Kind.MACHINE:
            group = ctx.group_for(i)
            if group is None:
                problems.append(f"UNRESOLVED_MACHINE: building {i}, recipe {bs[i].recipe_id}")
            else:
                machine[i] = group
                if catalog.get_item_id(group.machine_item_id) != bs[i].item_id:
                    problems.append(
                        f"MACHINE_IDENTITY: building {i} is not the frozen {group.machine_item_id}"
                    )
    transport = {
        i
        for i, b in enumerate(bs)
        if catalog.is_belt(b.item_id) or b.item_id in (catalog.SPLITTER_ID, catalog.PILER_ID)
    }
    adjacent: dict[int, set[int]] = defaultdict(set)
    labels: dict[int, set[str]] = defaultdict(set)
    reverse = {
        catalog.get_item_id(item): item
        for item in sorted(
            set(spec.external_inputs)
            | set(spec.outputs)
            | set(spec.surplus_outputs)
            | {
                item
                for group in spec.groups
                for item in (*group.inputs_per_machine, *group.outputs_per_machine)
            }
        )
    }
    for i in transport:
        budget.check()
        b = bs[i]
        predecessor = b.input_obj
        if (
            catalog.is_belt(b.item_id)
            and predecessor is not None
            and 0 <= predecessor < len(bs)
            and catalog.is_belt(bs[predecessor].item_id)
            and bs[predecessor].output_obj != i
        ):
            problems.append(
                f"BELT_DIRECTION_UNSUPPORTED: {i} input {predecessor} lacks forward link"
            )
        if b.carries_item:
            labels[i].add(b.carries_item)
        if b.parameters and b.parameters[0] in reverse:
            labels[i].add(reverse[b.parameters[0]])
        for peer in (b.output_obj, b.input_obj):
            if peer in transport:
                adjacent[i].add(peer)
                adjacent[peer].add(i)
    # Real filters and unique machine buffer identities seed belt labels.
    for b in bs:
        if not catalog.is_sorter(b.item_id):
            continue
        budget.check()
        known: set[str] = set()
        if b.filter_id:
            name = reverse.get(b.filter_id)
            if name is not None:
                known.add(name)
        if not known:
            candidates: list[set[str]] = []
            if b.input_obj in machine:
                candidates.append(set(machine[b.input_obj].outputs_per_machine))
            if b.output_obj in machine:
                candidates.append(set(machine[b.output_obj].inputs_per_machine))
            if candidates:
                known = candidates[0].intersection(*candidates[1:])
        if len(known) == 1:
            for peer in (b.input_obj, b.output_obj):
                if peer in transport:
                    labels[peer].update(known)
    items: dict[int, str] = {}
    seen: set[int] = set()
    for start in sorted(transport):
        if start in seen:
            continue
        component: list[int] = []
        queue = [start]
        component_items: set[str] = set()
        while queue:
            budget.check()
            current = queue.pop()
            if current in seen:
                continue
            seen.add(current)
            component.append(current)
            component_items.update(labels[current])
            queue.extend(sorted(adjacent[current] - seen, reverse=True))
        # Unused stack-support junctions have no transport obligation.
        if not component_items and all(
            bs[i].item_id == catalog.SPLITTER_ID and not adjacent[i] for i in component
        ):
            continue
        if len(component_items) != 1:
            problems.append(
                f"ITEM_INCIDENCE_UNSUPPORTED: {component[:16]}, items={sorted(component_items)}"
            )
        else:
            item = next(iter(component_items))
            for i in component:
                items[i] = item
    for i, b in enumerate(bs):
        if not catalog.is_sorter(b.item_id):
            continue
        possible: list[set[str]] = []
        if b.input_obj in machine:
            possible.append(set(machine[b.input_obj].outputs_per_machine))
        elif b.input_obj in items:
            possible.append({items[b.input_obj]})
        if b.output_obj in machine:
            possible.append(set(machine[b.output_obj].inputs_per_machine))
        elif b.output_obj in items:
            possible.append({items[b.output_obj]})
        if b.filter_id:
            name = reverse.get(b.filter_id)
            possible.append(set() if name is None else {name})
        eligible = possible[0].intersection(*possible[1:]) if possible else set[str]()
        if len(eligible) == 1:
            items[i] = next(iter(eligible))
        else:
            problems.append(
                f"SORTER_ITEM_INCIDENCE: {i}, {b.input_obj}->{b.output_obj}, {sorted(eligible)}"
            )
    return items, machine, problems


@dataclass
class _Residual:
    to: int
    reverse: int
    remaining: Fraction


class _Network:
    def __init__(self, budget: WorkBudget) -> None:
        self.budget: WorkBudget = budget
        self.names: list[str] = []
        self.ids: dict[str, int] = {}
        self.graph: list[list[_Residual]] = []
        self.original: list[tuple[int, int, CapacityEdge]] = []

    def node(self, name: str) -> int:
        if name not in self.ids:
            self.ids[name] = len(self.names)
            self.names.append(name)
            self.graph.append([])
        return self.ids[name]

    def add(
        self, source: str, sink: str, capacity: Fraction, kind: str, buildings: tuple[int, ...] = ()
    ) -> None:
        self.budget.charge("arcs")
        a, b = self.node(source), self.node(sink)
        forward = _Residual(b, len(self.graph[b]), capacity)
        backward = _Residual(a, len(self.graph[a]), Fraction())
        self.original.append(
            (
                a,
                len(self.graph[a]),
                CapacityEdge(source, sink, capacity, Fraction(), kind, buildings),
            )
        )
        self.graph[a].append(forward)
        self.graph[b].append(backward)

    def solve(
        self, required: Fraction
    ) -> tuple[Fraction, tuple[CapacityEdge, ...], CapacityCut | None]:
        source, sink = self.node("SOURCE"), self.node("SINK")
        total = Fraction()
        reached: set[int] = set()
        while total < required:
            self.budget.check()
            parent: dict[int, tuple[int, int]] = {}
            reached = {source}
            queue = deque([source])
            while queue and sink not in reached:
                here = queue.popleft()
                self.budget.check()
                for ordinal, edge in enumerate(self.graph[here]):
                    self.budget.check()
                    if edge.remaining > 0 and edge.to not in reached:
                        reached.add(edge.to)
                        parent[edge.to] = (here, ordinal)
                        queue.append(edge.to)
            if sink not in reached:
                break
            self.budget.charge("augmentations")
            amount = required - total
            here = sink
            while here != source:
                self.budget.check()
                previous, ordinal = parent[here]
                amount = min(amount, self.graph[previous][ordinal].remaining)
                here = previous
            here = sink
            while here != source:
                self.budget.check()
                previous, ordinal = parent[here]
                edge = self.graph[previous][ordinal]
                edge.remaining -= amount
                self.graph[here][edge.reverse].remaining += amount
                here = previous
            total += amount
        edges = tuple(
            replace(edge, flow=edge.capacity - self.graph[a][ordinal].remaining)
            for a, ordinal, edge in self.original
        )
        cut = None
        if total < required:
            crossing = tuple(
                edge
                for edge in edges
                if self.ids[edge.source] in reached and self.ids[edge.sink] not in reached
            )
            cut = CapacityCut(
                required,
                total,
                sum((edge.capacity for edge in crossing), Fraction()),
                tuple(self.names[i] for i in sorted(reached)),
                crossing,
            )
        return total, edges, cut


def rate_assessment(
    placement: Placement, spec: BuildSpec, rules: catalog.BeltAltitudeRules, budget: WorkBudget
) -> RateReport:
    """Inspect joint physical capacity; never assert simultaneous in-game service."""
    items, machines, problems = _incidence(placement, spec, rules, budget)
    bs = placement.buildings
    mechanics: list[str] = []
    assumptions = (
        "Continuous configured power is assumed, not proved.",
        "Only actual import heads are supplied, at frozen aggregate rates; no extra roots.",
        "Exports and surplus drain continuously; no invented throttles or priorities.",
        "Buffers start empty except frozen self_loop_seeds; finite startup is unproved.",
        "All machine and boundary rates must hold together after startup, not every tick.",
    )
    if spec.self_loop_seeds:
        mechanics.append(
            f"Declared seed delivery/loop startup remains unproved: {spec.self_loop_seeds}"
        )
    if spec.coproduct_buffer_proofs:
        mechanics.append("Local coproduct buffer facts do not prove joint startup or composition.")
    if spec.spray_lanes or any(g.is_proliferated for g in spec.groups):
        problems.append(
            "SPRAY_MECHANICS_UNSUPPORTED: shared supply and local dose incidence unmodeled"
        )
    stacks_supported = spec.belt_stack == 1 and all(
        b.item_id not in (catalog.PILER_ID, 2014) for b in bs
    )
    if not stacks_supported:
        problems.append(
            "STACK_MECHANICS_UNSUPPORTED: cargo-stack invariant missing; capacity is an upper bound"
        )
    for group in spec.groups:
        count = sum(g is group for g in machines.values())
        if count != group.count:
            problems.append(
                f"MACHINE_COUNT: {group.recipe_id} needs {group.count}, actual resolved {count}"
            )
    network = _Network(budget)
    produced = consumed = Fraction()
    for i, group in machines.items():
        budget.check()
        for item, rate in group.outputs_per_machine.items():
            network.add(
                "SOURCE", f"machine:{i}:out:{item}", rate, "shared-machine-output-pool", (i,)
            )
            produced += rate
        for item, rate in group.inputs_per_machine.items():
            network.add(f"machine:{i}:in:{item}", "SINK", rate, "machine-consumption", (i,))
            consumed += rate
    for item, rate in sorted(spec.external_inputs.items()):
        network.add("SOURCE", f"import:{item}", rate, "frozen-import-total")
        produced += rate
    exports: dict[str, Fraction] = defaultdict(Fraction)
    for table in (spec.outputs, spec.surplus_outputs):
        for item, rate in table.items():
            exports[item] += rate
    for item, rate in sorted(exports.items()):
        network.add(f"export:{item}", "SINK", rate, "frozen-export-plus-surplus")
        consumed += rate
    if produced != consumed:
        problems.append(
            f"EXACT_BOUNDARY_BALANCE: supply={produced}, demand={consumed}; no disposal sink"
        )
    generous = max(produced, consumed, Fraction(1))
    belt_capacity: dict[int, Fraction] = {}
    incoming: dict[int, list[int]] = defaultdict(list)
    outgoing: dict[int, list[int]] = defaultdict(list)
    sorter_inputs: dict[int, list[int]] = defaultdict(list)
    sorter_outputs: dict[int, list[int]] = defaultdict(list)
    for i, b in enumerate(bs):
        budget.check()
        if catalog.is_belt(b.item_id):
            capacity = catalog.BELT_RATE.get(b.item_id)
            if capacity is None:
                problems.append(f"BELT_CAPACITY_UNKNOWN: {i}, tier {b.item_id}")
                continue
            belt_capacity[i] = capacity * (1 if stacks_supported else catalog.PILER_MAX_STACK)
            network.add(
                f"transport:{i}:in",
                f"transport:{i}:out",
                belt_capacity[i],
                "physical-belt-capacity",
                (i,),
            )
            target = b.output_obj
            if target is not None:
                incoming[target].append(i)
                outgoing[i].append(target)
            if (
                b.input_obj is not None
                and 0 <= b.input_obj < len(bs)
                and not catalog.is_belt(bs[b.input_obj].item_id)
            ):
                outgoing[b.input_obj].append(i)
                incoming[i].append(b.input_obj)
        elif catalog.is_sorter(b.item_id):
            if b.input_obj is not None:
                sorter_inputs[b.input_obj].append(i)
            if b.output_obj is not None:
                sorter_outputs[b.output_obj].append(i)
    # Every junction is one conserved resource, never one source copy per leaf.
    for i, b in enumerate(bs):
        if b.item_id not in (catalog.SPLITTER_ID, catalog.PILER_ID):
            continue
        budget.check()
        if b.parameters or b.filter_id:
            problems.append(
                f"JUNCTION_CONFIGURATION_UNSUPPORTED: {i}, {b.parameters}, filter={b.filter_id}"
            )
        ins = sum((belt_capacity.get(j, Fraction()) for j in incoming[i]), Fraction())
        outs = sum((belt_capacity.get(j, Fraction()) for j in outgoing[i]), Fraction())
        network.add(
            f"transport:{i}:in",
            f"transport:{i}:out",
            min(ins, outs),
            "junction-incident-port-cut",
            (i,),
        )
        if incoming[i] or outgoing[i]:
            mechanics.append(
                f"junction {i}: allocation, contention and finite-buffer nonstarvation unproved"
            )
    for source, targets in outgoing.items():
        for sink in targets:
            budget.check()
            if source not in items or sink not in items or items[source] != items[sink]:
                problems.append(
                    f"PHYSICAL_ITEM_EDGE: {source}->{sink} missing or inconsistent item identity"
                )
                continue
            if source in machines or sink in machines:
                problems.append(
                    f"MACHINE_BELT_PORT_UNSUPPORTED: {source}->{sink}; mode service unmodeled"
                )
                continue
            network.add(
                f"transport:{source}:out",
                f"transport:{sink}:in",
                generous,
                "actual-transport-link",
                (source, sink),
            )
    tier_index = {catalog.get_item_id(name): i for i, name in enumerate(spec.sorter_item_ids)}
    for i, b in enumerate(bs):
        if not catalog.is_sorter(b.item_id):
            continue
        budget.check()
        item = items.get(i)
        source, sink = b.input_obj, b.output_obj
        if (
            item is None
            or source is None
            or sink is None
            or not 0 <= source < len(bs)
            or not 0 <= sink < len(bs)
        ):
            problems.append(f"SORTER_INCIDENCE_UNSUPPORTED: sorter {i}, endpoints {source}->{sink}")
            continue
        if b.x2 is None or b.y2 is None:
            problems.append(f"SORTER_CAPACITY_UNKNOWN: sorter {i} has no second anchor")
            continue
        span = max(abs(b.x - b.x2), abs(b.y - b.y2))
        if not 1 <= span <= catalog.SORTER_MAX_REACH or b.item_id not in catalog.SORTER_RATE_AT_1:
            problems.append(f"SORTER_CAPACITY_UNKNOWN: sorter {i} tier={b.item_id}, span={span}")
            continue
        rate = catalog.sorter_rate(b.item_id, span)
        if not stacks_supported:
            tier = tier_index.get(b.item_id)
            pick = spec.sorter_pick_stacks[tier] if tier is not None else catalog.PILER_MAX_STACK
            rate *= catalog.PILER_MAX_STACK * pick
        a = f"machine:{source}:out:{item}" if source in machines else f"transport:{source}:out"
        z = f"machine:{sink}:in:{item}" if sink in machines else f"transport:{sink}:in"
        network.add(a, z, rate, "actual-sorter-capacity", (source, i, sink))
    ports: list[BoundaryPort] = []
    roots: dict[str, list[int]] = defaultdict(list)
    for i, capacity in belt_capacity.items():
        budget.check()
        item = items.get(i)
        if item is None:
            continue
        # Incoming sorter incidence matters: an unlinked producer lane is not a player root.
        if (
            not incoming[i]
            and not sorter_outputs[i]
            and bs[i].input_obj is None
            and item in spec.external_inputs
        ):
            roots[item].append(i)
            ports.append(BoundaryPort(i, item, "import", capacity))
            network.add(f"import:{item}", f"transport:{i}:in", capacity, "actual-import-root", (i,))
        if not outgoing[i] and not sorter_inputs[i] and item in exports:
            ports.append(BoundaryPort(i, item, "export", capacity))
            network.add(
                f"transport:{i}:out", f"export:{item}", capacity, "actual-open-export", (i,)
            )
    for item, indices in sorted(roots.items()):
        if len(indices) > 1:
            mechanics.append(
                f"import {item}: roots {indices} share frozen total; per-root schedule unknown"
            )
    for machine, sorters in sorted(sorter_inputs.items()):
        if machine in machines and len(sorters) > 1:
            mechanics.append(f"machine {machine}: shared-buffer sorter service unproved: {sorters}")
    mechanics.append("Static flow omits sorter timing, finite buffers, dependencies and startup.")
    achieved, edges, cut = network.solve(consumed)
    complete = not problems
    upper_feasible = achieved == consumed and produced == consumed
    # A cut is a valid physical refusal only when every admitted incidence and
    # capacity was represented. An incomplete model must not prove impossibility.
    valid_cut = cut if complete else None
    findings = list(problems)
    if valid_cut is not None:
        findings.append(
            f"CAPACITY_CUT: {valid_cut.capacity} < {valid_cut.required}; emitted graph only"
        )
    elif upper_feasible:
        findings.append("Joint static flow is feasible; this is not a service schedule.")
    findings.extend(mechanics)
    return RateReport(
        "CAPACITY_CUT" if valid_cut is not None else "RATE_REALIZATION_UNPROVED",
        complete and upper_feasible,
        tuple(findings),
        complete,
        upper_feasible,
        consumed,
        achieved,
        edges,
        valid_cut,
        tuple(ports),
        assumptions,
        tuple(mechanics),
    )
