"""Focused experiment witnesses, deliberately outside the production test suite.

Run as the experiment package's ``template_paths_witness`` module. Each scenario
owns a fresh ledger; no selector invocation ever resets its supplied ledger.
"""

from __future__ import annotations

import hashlib
import json
import time
from collections.abc import Callable
from dataclasses import asdict, dataclass, replace
from fractions import Fraction
from functools import partial
from itertools import product
from pathlib import Path

from pydantic import BaseModel, TypeAdapter

from .template_budget import ExperimentRefusal, WorkBudget, WorkKind, WorkLimits
from .template_paths import (
    Cell,
    Endpoint,
    FixedPath,
    Obligation,
    TemplateProblem,
    admit,
    compatible,
    domains,
    select,
)


def _budget(**limits: int) -> WorkBudget:
    return WorkBudget(time.monotonic() + 60, replace(WorkLimits(), **limits))


def _expand(points: tuple[Cell, ...]) -> tuple[Cell, ...]:
    """Independent cell expansion, not selector interval arithmetic."""
    cells = [points[0]]
    for a, b in zip(points, points[1:], strict=False):
        axes = [i for i in range(3) if a[i] != b[i]]
        if not axes:
            continue
        assert len(axes) == 1, (a, b)
        axis = axes[0]
        step = 1 if b[axis] > a[axis] else -1
        for coordinate in range(a[axis] + step, b[axis] + step, step):
            xyz = list(a)
            xyz[axis] = coordinate
            cells.append((xyz[0], xyz[1], xyz[2]))
    return tuple(cells)


def _path(points: tuple[Cell, ...], port: int, item: str = "iron") -> FixedPath:
    clean = tuple(p for i, p in enumerate(points) if i == 0 or p != points[i - 1])
    assert len(clean) >= 2
    directions: list[tuple[int, int]] = []
    for a, b in ((clean[0], clean[1]), (clean[-1], clean[-2])):
        directions.append(((b[0] > a[0]) - (b[0] < a[0]), (b[1] > a[1]) - (b[1] < a[1])))
    return FixedPath(
        points,
        Endpoint(clean[0], directions[0], port),
        Endpoint(clean[-1], directions[1], port + 1),
        item,
    )


def _refusal(action: Callable[[], object], expected: str) -> str:
    try:
        action()
    except ExperimentRefusal as exc:
        assert exc.reason == expected, (exc.reason, exc.detail)
        return exc.detail
    raise AssertionError(f"expected {expected}")


def _obligation(
    ordinal: int, source: Cell, sink: Cell, out: tuple[int, int], back: tuple[int, int]
) -> Obligation:
    return Obligation(
        ordinal,
        "iron",
        Fraction(1),
        Endpoint(source, out, ordinal * 2),
        Endpoint(sink, back, ordinal * 2 + 1),
    )


def _problem(
    *obligations: Obligation,
    blocked: frozenset[Cell] = frozenset(),
    levels: tuple[int, ...] = (3,),
    y_tracks: tuple[int, ...] = (),
) -> TemplateProblem:
    return TemplateProblem(tuple(obligations), blocked, (), (), y_tracks, levels)


def _valid_cells(problem: TemplateProblem) -> list[list[tuple[tuple[Cell, ...], frozenset[Cell]]]]:
    """Exhaustive tiny-domain oracle using cell uniqueness/occupancy, not predicates."""
    result: list[list[tuple[tuple[Cell, ...], frozenset[Cell]]]] = []
    ledger = _budget()
    for domain in domains(problem, ledger):
        choices: list[tuple[tuple[Cell, ...], frozenset[Cell]]] = []
        for candidate_id in domain._ids(ledger):
            points = domain._decode(candidate_id, ledger).path.points
            cells = _expand(points)
            occupied = frozenset(cells)
            if len(cells) != len(occupied):
                continue
            allowed = {
                endpoint.cell
                for endpoint in (domain.obligation.source, domain.obligation.sink)
                if endpoint in problem.owned_endpoints
            }
            if (occupied - allowed) & problem.blocked:
                continue
            choices.append((points, occupied))
        result.append(choices)
    return result


def _exhaustive(problem: TemplateProblem) -> bool:
    choices = _valid_cells(problem)
    return any(
        all(not a[1] & b[1] for i, a in enumerate(selection) for b in selection[i + 1 :])
        for selection in product(*choices)
    )


def _assert_selected(problem: TemplateProblem, result: dict[int, tuple[Cell, ...]]) -> None:
    assert set(result) == {o.ordinal for o in problem.obligations}
    occupied: set[Cell] = set()
    for o in problem.obligations:
        points = result[o.ordinal]
        assert points[0] == o.source.cell and points[-1] == o.sink.cell
        cells = _expand(points)
        assert len(cells) == len(set(cells))
        allowed = {
            endpoint.cell for endpoint in (o.source, o.sink) if endpoint in problem.owned_endpoints
        }
        assert not (set(cells) - allowed) & problem.blocked
        assert not occupied.intersection(cells)
        occupied.update(cells)


def _backtrack_problem() -> TemplateProblem:
    a = _obligation(0, (0, 0, 0), (20, 0, 0), (1, 0), (-1, 0))
    b = _obligation(1, (10, -10, 0), (10, 10, 0), (0, 1), (0, -1))
    base = _problem(a, b, y_tracks=(18,))
    short = ((0, 0, 0), (2, 0, 0), (2, 0, 3), (18, 0, 3), (18, 0, 0), (20, 0, 0))
    detour = (
        (0, 0, 0),
        (2, 0, 0),
        (2, 0, 3),
        (2, 18, 3),
        (18, 18, 3),
        (18, 0, 3),
        (18, 0, 0),
        (20, 0, 0),
    )
    vertical = ((10, -10, 0), (10, -8, 0), (10, -8, 3), (10, 8, 3), (10, 8, 0), (10, 10, 0))
    allowed = set(_expand(short)) | set(_expand(detour)) | set(_expand(vertical))
    candidate_cells: set[Cell] = set()
    ledger = _budget()
    for d in domains(base, ledger):
        for candidate_id in d._ids(ledger):
            candidate_cells.update(_expand(d._decode(candidate_id, ledger).path.points))
    return replace(base, blocked=frozenset(candidate_cells - allowed))


class _RetainedFlight(BaseModel):
    id: int
    item: str
    points_at_level_3: tuple[Cell, ...]


def _retained_pair() -> int:
    path = Path(__file__).resolve().parent / "capacity-first-cases/unsprayed-mall/flights.json"
    raw = path.read_bytes()
    assert (
        hashlib.sha256(raw).hexdigest()
        == "7be50d3227e6f328f679c714cde32c1b410622365c7890c380221b6939789a30"
    )
    rows = TypeAdapter(list[_RetainedFlight]).validate_json(raw)
    pair = [next(row for row in rows if row.id == ordinal) for ordinal in (61, 114)]
    ledger = _budget()
    checked = 0
    for first_level in range(3, 27):
        for second_level in range(3, 27):
            paths: list[FixedPath] = []
            for i, (row, level) in enumerate(zip(pair, (first_level, second_level), strict=True)):
                points = tuple((x, y, level if z == 3 else z) for x, y, z in row.points_at_level_3)
                paths.append(_path(points, 10_000 + 2 * i, row.item))
            assert set(_expand(paths[0].points)) & set(_expand(paths[1].points))
            assert not compatible(paths[0], paths[1], ledger)
            checked += 1
    return checked


@dataclass
class _TickClock:
    calls: int = 0

    def __call__(self) -> float:
        self.calls += 1
        return float(self.calls)


def run() -> dict[str, object]:
    vertical = _path(((0, 0, 0), (2, 0, 0), (2, 0, 8), (6, 0, 8), (6, 0, 0), (8, 0, 0)), 100)
    interior = _path(((0, -2, 5), (2, -2, 5), (2, 2, 5), (4, 2, 5)), 200)
    assert (2, 0, 5) not in vertical.points and (2, 0, 5) not in interior.points
    assert not compatible(vertical, interior, _budget())
    ground = _path(((1, -2, 0), (1, 0, 0), (1, 0, 4), (10, 0, 4), (10, 0, 0), (12, 0, 0)), 300)
    assert not compatible(vertical, ground, _budget())
    a = _path(((0, 0, 0), (4, 0, 0)), 10)
    b = _path(((4, 0, 0), (8, 0, 0)), 20)
    assert not compatible(a, b, _budget())
    owned = replace(b, source=replace(b.source, port_id=a.sink.port_id))
    assert compatible(a, owned, _budget())
    assert not compatible(a, replace(owned, item="copper"), _budget())
    north = _path(((0, 0, 0), (0, 4, 0)), 30)
    assert not compatible(a, north, _budget())
    ja = replace(a, source=replace(a.source, junction_id=99))
    jn = replace(north, source=replace(north.source, junction_id=99))
    assert compatible(ja, jn, _budget())
    assert not compatible(ja, replace(jn, source=replace(jn.source, junction_id=100)), _budget())
    assert not compatible(
        ja,
        replace(ja, source=replace(ja.source, port_id=40), sink=replace(ja.sink, port_id=41)),
        _budget(),
    )
    retrace = _path(((0, 0, 0), (4, 0, 0), (2, 0, 0), (2, 4, 0)), 50)
    assert not compatible(retrace, b, _budget())

    obligation = _obligation(0, (0, 0, 0), (20, 0, 0), (1, 0), (-1, 0))
    basic = _problem(obligation)
    unowned = replace(basic, blocked=frozenset((obligation.source.cell, obligation.sink.cell)))
    _refusal(lambda: select(unowned, _budget()), "TEMPLATE_FAMILY_EXHAUSTED")
    mismatched_owner = replace(
        unowned,
        owned_endpoints=(replace(obligation.source, port_id=999), obligation.sink),
    )
    _refusal(lambda: select(mismatched_owner, _budget()), "TEMPLATE_FAMILY_EXHAUSTED")
    endpoints = replace(unowned, owned_endpoints=(obligation.source, obligation.sink))
    _assert_selected(endpoints, select(endpoints, _budget()))
    ground_cut = replace(basic, blocked=frozenset(((1, 0, 0),)))
    exhausted = _refusal(lambda: select(ground_cut, _budget()), "TEMPLATE_FAMILY_EXHAUSTED")
    # A reservation inside the complete riser, not merely an emitted vertex.
    full_riser = replace(basic, blocked=frozenset(((2, 0, 2),)))
    _assert_selected(full_riser, select(full_riser, _budget()))
    local = _path(((-4, 0, 0), (0, 0, 0)), 1_000)
    local = replace(local, sink=replace(local.sink, port_id=obligation.source.port_id))
    continuation = replace(
        endpoints,
        fixed_paths=(local,),
        owned_endpoints=endpoints.owned_endpoints + (local.source, local.sink),
    )
    _assert_selected(continuation, select(continuation, _budget()))
    bad_local = replace(local, sink=replace(local.sink, port_id=1_001))
    invalid_fixed = replace(
        endpoints,
        fixed_paths=(bad_local,),
        owned_endpoints=endpoints.owned_endpoints + (bad_local.source, bad_local.sink),
    )
    _refusal(lambda: select(invalid_fixed, _budget()), "TEMPLATE_FAMILY_EXHAUSTED")

    backtracking = _backtrack_problem()
    cases = (
        basic,
        ground_cut,
        endpoints,
        unowned,
        mismatched_owner,
        backtracking,
        _problem(obligation, _obligation(1, (0, 8, 0), (20, 8, 0), (1, 0), (-1, 0))),
        _problem(obligation, _obligation(1, (10, -10, 0), (10, 10, 0), (0, 1), (0, -1))),
    )
    for case in cases:
        expected = _exhaustive(case)
        try:
            result = select(case, _budget())
        except ExperimentRefusal as exc:
            assert not expected and exc.reason == "TEMPLATE_FAMILY_EXHAUSTED", (
                expected,
                exc.reason,
            )
        else:
            assert expected
            _assert_selected(case, result)
    ledger = _budget()
    selected = select(backtracking, ledger)
    assert ledger.counts.get("assignments", 0) > len(backtracking.obligations)
    assert any(p[1] == 18 for p in selected[0]), selected
    assert select(backtracking, _budget()) == selected

    rich = replace(
        basic,
        x_tracks=(-8, -4, 4, 8, 12, 16, 24, 28),
        y_tracks=(-8, -4, 4, 8, 12, 16),
        levels=(3, 4, 5, 6, 7),
    )
    admission_ledger = _budget()
    admission = admit(rich, admission_ledger)
    assert admission.domain_counts == (1_250,) and admission.sampled == 1_024
    assert admission_ledger.counts.get("assignments", 0) == 0
    assert admission_ledger.counts.get("candidates", 0) == 1_024
    assert admission.bitset_bytes == 3 * ((1_250 + 7) // 8)
    assert admit(rich, _budget(), sample_limit=2_000).sampled == 1_024
    assert admit(rich, _budget(), sample_limit=0).sampled == 0

    cap_details: dict[str, str] = {}
    kinds: tuple[WorkKind, ...] = (
        "arcs",
        "augmentations",
        "candidates",
        "audit_cells",
        "predicates",
        "assignments",
    )
    for kind in kinds:
        capped = _budget(**{kind: 1})
        capped.charge(kind)
        cap_details[kind] = _refusal(partial(capped.charge, kind), "POLICY_BOUND")
        assert capped.counts[kind] == 1
    for selector_kind in ("candidates", "predicates", "assignments"):
        cap_details[f"selector_{selector_kind}"] = _refusal(
            partial(select, basic, _budget(**{selector_kind: 0})), "POLICY_BOUND"
        )
    no_time = WorkBudget(0, clock=lambda: 0)
    _refusal(lambda: select(basic, no_time), "DEADLINE")
    clock = _TickClock()
    in_loop = WorkBudget(2_000, clock=clock)
    _refusal(lambda: admit(rich, in_loop), "DEADLINE")
    assert in_loop.counts.get("candidates", 0) > 0
    assert clock.calls >= 2_000
    # Exhausted resource ledgers stay exhausted across independent selector calls.
    shared = _budget(assignments=1)
    _assert_selected(basic, select(basic, shared))
    _refusal(lambda: select(basic, shared), "POLICY_BOUND")

    return {
        "full_vertical_interiors": True,
        "ground_collision": True,
        "exact_endpoint_and_junction_ownership": True,
        "small_domain_exhaustive_cases": len(cases),
        "backtrack_assignments": ledger.counts.get("assignments", 0),
        "deterministic": True,
        "retained_negative_height_pairs": _retained_pair(),
        "admission": asdict(admission),
        "caps": cap_details,
        "absolute_deadline_inside_loop": True,
        "exhaustion_witness": exhausted,
        "scope": "experiment-only centreline witnesses; no physical clearance/service claim",
    }


if __name__ == "__main__":
    print(json.dumps(run(), sort_keys=True))
