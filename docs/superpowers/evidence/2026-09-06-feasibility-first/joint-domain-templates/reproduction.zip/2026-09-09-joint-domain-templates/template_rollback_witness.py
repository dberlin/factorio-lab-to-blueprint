"""Finite real-geometry witnesses for blocker lifetime and bounded rollback work."""

from __future__ import annotations

import json
import time
from collections.abc import Iterator
from dataclasses import dataclass, replace
from fractions import Fraction
from itertools import product
from pathlib import Path
from typing import override
from unittest.mock import patch

from . import template_paths as paths
from .template_budget import ExperimentRefusal, WorkBudget, WorkLimits
from .template_paths import Cell, Domain, FixedPath, Obligation, TemplateProblem
from .template_paths_witness import _assert_selected, _expand, _path


@dataclass(frozen=True, slots=True)
class FiniteDomain(Domain):
    """Enumerate supplied complete paths; all real geometry predicates remain active."""

    choices: tuple[FixedPath, ...]

    @property
    @override
    def count(self) -> int:
        return len(self.choices)

    @override
    def _ids(self, budget: WorkBudget) -> Iterator[int]:
        for candidate in range(self.count):
            budget.check()
            yield candidate

    @override
    def _decode(self, candidate_id: int, budget: WorkBudget) -> paths._Geometry:
        budget.charge("candidates")
        return paths._geometry(self.choices[candidate_id], budget)


def fixture(
    *, ancestor_can_change: bool, sibling_can_succeed: bool, target: str = "mixed"
) -> tuple[TemplateProblem, tuple[Domain, ...]]:
    ancestor = _path(
        ((-10, 10, 0), (-8, 10, 0), (-8, 10, 3), (18, 10, 3), (18, 10, 0), (20, 10, 0)),
        0,
    )
    changed_ancestor = replace(
        ancestor,
        points=(
            (-10, 10, 0),
            (-8, 10, 0),
            (-8, 10, 3),
            (-8, 30, 3),
            (18, 30, 3),
            (18, 10, 3),
            (18, 10, 0),
            (20, 10, 0),
        ),
    )

    def sibling(x: int) -> FixedPath:
        return _path(
            (
                (5, -5, 0),
                (5, -3, 0),
                (5, -3, 3),
                (x, -3, 3),
                (x, 3, 3),
                (5, 3, 3),
                (5, 3, 0),
                (5, 5, 0),
            ),
            2,
        )

    direct = _path(((0, 0, 0), (2, 0, 0), (2, 0, 3), (8, 0, 3), (8, 0, 0), (10, 0, 0)), 4)

    def detour(y: int) -> FixedPath:
        return replace(
            direct,
            points=(
                (0, 0, 0),
                (2, 0, 0),
                (2, 0, 3),
                (2, y, 3),
                (8, y, 3),
                (8, 0, 3),
                (8, 0, 0),
                (10, 0, 0),
            ),
        )

    ancestor_paths = (ancestor, changed_ancestor) if ancestor_can_change else (ancestor,)
    sibling_paths = tuple(sibling(x) for x in (3, 4, 5, 15 if sibling_can_succeed else 6))
    blocked_by_ancestor = tuple(detour(y) for y in range(10, 30))
    target_paths = {
        "mixed": (detour(-10), direct, *blocked_by_ancestor),
        "direct": (direct,),
        "detour": (detour(-10), *blocked_by_ancestor),
    }[target]
    all_paths = (ancestor_paths, sibling_paths, target_paths)
    obligations = tuple(
        Obligation(i, "iron", Fraction(1), choices[0].source, choices[0].sink)
        for i, choices in enumerate(all_paths)
    )
    problem = TemplateProblem(obligations, frozenset(((2, -10, 3),)), (), (), (), (3,))
    domains = tuple(
        FiniteDomain(obligation, (3,), (), (), (), choices)
        for obligation, choices in zip(obligations, all_paths, strict=True)
    )
    return problem, domains


def exhaustive(problem: TemplateProblem, domains: tuple[Domain, ...]) -> bool:
    valid: list[list[frozenset[Cell]]] = []
    budget = WorkBudget(time.monotonic() + 10)
    for domain in domains:
        choices: list[frozenset[Cell]] = []
        for candidate in domain._ids(budget):
            geometry = domain._decode(candidate, budget)
            cells = _expand(geometry.path.points)
            occupied = frozenset(cells)
            if len(cells) == len(occupied) and not occupied & problem.blocked:
                choices.append(occupied)
        valid.append(choices)
    return any(
        all(not a & b for i, a in enumerate(choice) for b in choice[i + 1 :])
        for choice in product(*valid)
    )


def solve(
    problem: TemplateProblem, domains: tuple[Domain, ...], budget: WorkBudget
) -> dict[int, tuple[Cell, ...]]:
    # Only the finite input enumeration is supplied. No collision result, cache,
    # live-domain state, rollback, choice or budget operation is mocked.
    with patch.object(paths, "domains", return_value=domains):
        return paths.select(problem, budget)


def run() -> dict[str, object]:
    problem, domains = fixture(ancestor_can_change=False, sibling_can_succeed=True)
    assert exhaustive(problem, domains)
    budget = WorkBudget(time.monotonic() + 10, replace(WorkLimits(), candidates=40))
    selection = solve(problem, domains, budget)
    _assert_selected(problem, selection)
    bounded_work = dict(budget.counts)

    checked = 0
    outcomes: list[dict[str, object]] = []
    for ancestor_can_change, sibling_can_succeed, target in product(
        (False, True), (False, True), ("mixed", "direct", "detour")
    ):
        problem, domains = fixture(
            ancestor_can_change=ancestor_can_change,
            sibling_can_succeed=sibling_can_succeed,
            target=target,
        )
        expected = exhaustive(problem, domains)
        try:
            selection = solve(problem, domains, WorkBudget(time.monotonic() + 10))
        except ExperimentRefusal as refusal:
            assert not expected and refusal.reason == "TEMPLATE_FAMILY_EXHAUSTED"
        else:
            assert expected
            _assert_selected(problem, selection)
            assert solve(problem, domains, WorkBudget(time.monotonic() + 10)) == selection
        checked += 1
        outcomes.append(
            {
                "ancestor_can_change": ancestor_can_change,
                "sibling_can_succeed": sibling_can_succeed,
                "target": target,
                "feasible": expected,
            }
        )
    result: dict[str, object] = {
        "scope": "real complete-path geometry on finite enumerated inputs; no factory claim",
        "bounded_sibling_rollback_work": bounded_work,
        "candidate_cap": 40,
        "exhaustive_cases": checked,
        "static_rejection_ancestor_reassignment_and_sibling_lifetimes": outcomes,
    }
    (Path(__file__).parent / "template-rollback-witness.json").write_text(
        json.dumps(result, indent=2)
    )
    return result


if __name__ == "__main__":
    print(json.dumps(run()))
