"""Replay the captured conditional obstruction against the new joint checker."""

from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path

from pydantic import BaseModel

from . import template_paths as paths
from .template_budget import WorkBudget
from .template_paths_witness import _expand


class FrontierInput(BaseModel):
    problem: paths.TemplateProblem
    fixed_prefix: dict[int, int]
    expected_survivors: dict[int, list[int]]
    unconditioned_ids: dict[int, int]


def _share(a: paths.FixedPath, b: paths.FixedPath, cell: paths.Cell) -> bool:
    if a.item != b.item:
        return False
    for ea, direction_a in ((a.source, 1), (a.sink, -1)):
        for eb, direction_b in ((b.source, 1), (b.sink, -1)):
            if ea.cell != cell or eb.cell != cell:
                continue
            if ea.port_id == eb.port_id:
                if direction_a != direction_b and ea.outward == (-eb.outward[0], -eb.outward[1]):
                    return True
            elif (
                ea.junction_id is not None
                and ea.junction_id == eb.junction_id
                and ea.outward != eb.outward
            ):
                return True
    return False


def _independent(
    a: paths.FixedPath, acells: set[paths.Cell], b: paths.FixedPath, bcells: set[paths.Cell]
) -> bool:
    for ea in (a.source, a.sink):
        for eb in (b.source, b.sink):
            if ea.port_id == eb.port_id and (ea.cell != eb.cell or not _share(a, b, ea.cell)):
                return False
    return all(_share(a, b, cell) for cell in acells & bcells)


def run() -> dict[str, object]:
    source = Path(__file__).parent / "joint-frontier-input.json"
    captured = FrontierInput.model_validate_json(source.read_text())
    budget = WorkBudget(time.monotonic() + 30)
    domains = paths.domains(captured.problem, budget)
    by_ordinal = {d.obligation.ordinal: i for i, d in enumerate(domains)}
    offsets: list[int] = []
    total = 0
    for domain in domains:
        offsets.append(total)
        total += domain.count
    selected = {
        by_ordinal[o]: domains[by_ordinal[o]]._decode(ci, budget)
        for o, ci in captured.fixed_prefix.items()
    }
    selected_cells = {di: set(_expand(g.path.points)) for di, g in selected.items()}
    index = paths._FixedIndex(captured.problem, budget)
    residuals: dict[int, list[tuple[int, paths._Geometry]]] = {}
    comparisons = 0
    for ordinal, expected in captured.expected_survivors.items():
        di = by_ordinal[ordinal]
        choices: list[tuple[int, paths._Geometry]] = []
        for ci in domains[di]._ids(budget):
            geometry = domains[di]._decode(ci, budget)
            if paths._path_error(geometry, budget) or index.error(geometry, budget):
                continue
            cells = set(_expand(geometry.path.points))
            for other, existing in selected.items():
                actual = paths._compatible(geometry, existing, budget)
                oracle = _independent(geometry.path, cells, existing.path, selected_cells[other])
                assert actual == oracle, (ordinal, ci, other)
                comparisons += 1
                if not actual:
                    break
            else:
                choices.append((ci, geometry))
        assert [ci for ci, _ in choices] == expected
        residuals[di] = choices
    first, second = tuple(residuals)
    assert paths._joint_conflict(residuals, offsets, paths._PairCache(), budget) == (first, second)
    checked = 0
    for _, a in residuals[first]:
        for _, b in residuals[second]:
            assert not _independent(
                a.path, set(_expand(a.path.points)), b.path, set(_expand(b.path.points))
            )
            checked += 1
    unconditioned: dict[int, list[tuple[int, paths._Geometry]]] = {}
    for ordinal, ci in captured.unconditioned_ids.items():
        di = by_ordinal[ordinal]
        geometry = domains[di]._decode(ci, budget)
        assert paths._path_error(geometry, budget) is None and index.error(geometry, budget) is None
        unconditioned[di] = [(ci, geometry)]
    assert paths._joint_conflict(unconditioned, offsets, paths._PairCache(), budget) is None
    a, b = [choices[0][1].path for choices in unconditioned.values()]
    assert _independent(a, set(_expand(a.points)), b, set(_expand(b.points)))
    result: dict[str, object] = {
        "input_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
        "conditional_candidates": {
            domains[di].obligation.ordinal: len(choices) for di, choices in residuals.items()
        },
        "unsupported_pairs": checked,
        "independent_prefix_comparisons": comparisons,
        "unconditioned_compatible_ids": captured.unconditioned_ids,
        "work": budget.counts,
    }
    (source.parent / "template-frontier-witness.json").write_text(json.dumps(result, indent=2))
    return result


if __name__ == "__main__":
    print(json.dumps(run()))
