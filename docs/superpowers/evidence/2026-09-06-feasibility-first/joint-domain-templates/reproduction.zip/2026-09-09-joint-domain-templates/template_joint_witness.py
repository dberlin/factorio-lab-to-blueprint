"""Real-path correctness witnesses for bounded residual consistency and backjumping."""

from __future__ import annotations

import json
import time
from collections.abc import Iterator
from dataclasses import replace
from fractions import Fraction
from pathlib import Path
from unittest.mock import patch

from . import template_paths as paths
from .template_budget import ExperimentRefusal, WorkBudget, WorkLimits
from .template_paths import Cell, Domain, FixedPath, Obligation, TemplateProblem
from .template_paths_witness import _assert_selected, _expand, _path
from .template_rollback_witness import FiniteDomain, exhaustive, solve


def fixture(*, escape: bool = True) -> tuple[TemplateProblem, tuple[Domain, ...]]:
    ancestor = _path(
        ((-10, 10, 0), (-8, 10, 0), (-8, 10, 3), (18, 10, 3), (18, 10, 0), (20, 10, 0)),
        0,
    )
    changed = replace(
        ancestor,
        points=(
            (-10, 10, 0),
            (-8, 10, 0),
            (-8, 10, 3),
            (-8, 30, 3),
            (18, 30, 3),
            (18, 10, 3),
            (18, 10, 0),
            (20, 10, 0),
        ),
    )
    stone = _path(((50, 0, 0), (52, 0, 0), (52, 0, 3), (58, 0, 3), (58, 0, 0), (60, 0, 0)), 2)
    left = _path(((0, 0, 0), (2, 0, 0), (2, 0, 3), (8, 0, 3), (8, 0, 0), (10, 0, 0)), 4)
    alternatives = tuple(
        replace(
            left,
            points=(
                (0, 0, 0),
                (2, 0, 0),
                (2, 0, 3),
                (2, y, 3),
                (8, y, 3),
                (8, 0, 3),
                (8, 0, 0),
                (10, 0, 0),
            ),
        )
        for y in range(10, 15)
    )
    right = _path(((5, -5, 0), (5, -3, 0), (5, -3, 3), (5, 3, 3), (5, 3, 0), (5, 5, 0)), 6)
    choices = (
        (ancestor, changed) if escape else (ancestor,),
        (stone,) * 4,
        (left, *alternatives),
        (right,) * 6,
    )
    obligations = tuple(
        Obligation(i, "iron", Fraction(1), paths[0].source, paths[0].sink)
        for i, paths in enumerate(choices)
    )
    problem = TemplateProblem(obligations, frozenset(), (), (), (), (3,))
    domains = tuple(
        FiniteDomain(obligation, (3,), (), (), (), paths)
        for obligation, paths in zip(obligations, choices, strict=True)
    )
    return problem, domains


def _finite(
    choices: tuple[tuple[FixedPath, ...], ...],
) -> tuple[TemplateProblem, tuple[Domain, ...]]:
    obligations = tuple(
        Obligation(i, "iron", Fraction(1), candidates[0].source, candidates[0].sink)
        for i, candidates in enumerate(choices)
    )
    problem = TemplateProblem(obligations, frozenset(), (), (), (), (3,))
    domains = tuple(
        FiniteDomain(obligation, (3,), (), (), (), candidates)
        for obligation, candidates in zip(obligations, choices, strict=True)
    )
    return problem, domains


def _joint_blockers(
    *, ancestor_escape: bool, sibling_escape: bool
) -> tuple[TemplateProblem, tuple[Domain, ...]]:
    ancestor = _path(
        ((-10, 10, 0), (-8, 10, 0), (-8, 10, 3), (18, 10, 3), (18, 10, 0), (20, 10, 0)),
        0,
    )
    ancestor_changed = replace(
        ancestor,
        points=(
            (-10, 10, 0),
            (-8, 10, 0),
            (-8, 10, 3),
            (-8, 60, 3),
            (18, 60, 3),
            (18, 10, 3),
            (18, 10, 0),
            (20, 10, 0),
        ),
    )
    sibling = _path(
        ((15, -10, 0), (15, -8, 0), (15, -8, 3), (15, 8, 3), (15, 8, 0), (15, 10, 0)),
        2,
    )
    sibling_changed = replace(
        sibling,
        points=(
            (15, -10, 0),
            (15, -8, 0),
            (15, -8, 3),
            (70, -8, 3),
            (70, 8, 3),
            (15, 8, 3),
            (15, 8, 0),
            (15, 10, 0),
        ),
    )
    stone = _path(
        ((100, 0, 0), (102, 0, 0), (102, 0, 3), (108, 0, 3), (108, 0, 0), (110, 0, 0)),
        4,
    )
    left = _path(
        ((0, 0, 0), (2, 0, 0), (2, 0, 3), (8, 0, 3), (8, 0, 0), (10, 0, 0)),
        6,
    )
    left_detours = tuple(
        replace(
            left,
            points=(
                (0, 0, 0),
                (2, 0, 0),
                (2, 0, 3),
                (2, y, 3),
                (8, y, 3),
                (8, 0, 3),
                (8, 0, 0),
                (10, 0, 0),
            ),
        )
        for y in range(10, 44)
    )
    right = _path(
        ((5, -5, 0), (5, -3, 0), (5, -3, 3), (5, 3, 3), (5, 3, 0), (5, 5, 0)),
        8,
    )
    right_detours = tuple(
        replace(
            right,
            points=(
                (5, -5, 0),
                (5, -3, 0),
                (5, -3, 3),
                (x, -3, 3),
                (x, 3, 3),
                (5, 3, 3),
                (5, 3, 0),
                (5, 5, 0),
            ),
        )
        for x in range(15, 49)
    )
    # Real blocked prefixes make left small after selecting ancestor, then
    # right small after selecting sibling. Stone is already active when the
    # next complete residual pass proves the unsupported left/right pair.
    return _finite(
        (
            (ancestor, ancestor_changed if ancestor_escape else ancestor),
            (sibling, sibling_changed if sibling_escape else sibling, sibling),
            (stone,) * 4,
            (*left_detours, *((left,) * 6)),
            (*right_detours, *((right,) * 6)),
        )
    )


def _observed_solve(
    problem: TemplateProblem, domains: tuple[Domain, ...], budget: WorkBudget
) -> tuple[dict[int, tuple[Cell, ...]] | None, dict[str, object]]:
    real_frame = paths._Frame
    real_joint = paths._joint_conflict
    frames: list[paths._Frame] = []
    first_conflict: tuple[paths._Frame, ...] | None = None
    crossed = False

    def frame(domain: int, iterator: Iterator[int]) -> paths._Frame:
        result = real_frame(domain, iterator)
        frames.append(result)
        return result

    def joint(
        residuals: dict[int, list[tuple[int, paths._Geometry]]],
        offsets: list[int],
        cache: paths._PairCache,
        work: WorkBudget,
    ) -> tuple[int, int] | None:
        nonlocal first_conflict, crossed
        # Observe real frame lifetimes, not mocked search/predicate decisions.
        # A chronological retry would leave this same stone frame active.
        if first_conflict is not None and not crossed:
            ancestor, sibling, stone = first_conflict
            assert ancestor.active and sibling.active and not stone.active
            crossed = True
        result = real_joint(residuals, offsets, cache, work)
        if result is not None and first_conflict is None:
            assert result == (3, 4)
            active = tuple(current for current in frames if current.active)
            assert tuple(current.domain for current in active) == (0, 1, 2)
            first_conflict = active
        return result

    with (
        patch.object(paths, "_Frame", side_effect=frame),
        patch.object(paths, "_joint_conflict", side_effect=joint),
    ):
        try:
            selected = solve(problem, domains, budget)
        except ExperimentRefusal as refusal:
            assert refusal.reason == "TEMPLATE_FAMILY_EXHAUSTED"
            selected = None
    assert first_conflict is not None and crossed
    return selected, {
        "contradictory_domains": [3, 4],
        "selected_at_contradiction": [0, 1, 2],
        "crossed_active_irrelevant_domain": 2,
        "resumed_explaining_domain": 1,
    }


def _blocker_cases() -> list[dict[str, object]]:
    outcomes: list[dict[str, object]] = []
    for ancestor_escape, sibling_escape in (
        (False, False),
        (False, True),
        (True, False),
        (True, True),
    ):
        problem, domains = _joint_blockers(
            ancestor_escape=ancestor_escape, sibling_escape=sibling_escape
        )
        expected = exhaustive(problem, domains)
        assert expected == (ancestor_escape or sibling_escape)
        budget = WorkBudget(time.monotonic() + 10)
        selected, observed = _observed_solve(problem, domains, budget)
        assert (selected is not None) == expected
        if selected is not None:
            _assert_selected(problem, selected)
            for domain in domains:
                assert isinstance(domain, FiniteDomain)
                occupied = frozenset(_expand(selected[domain.obligation.ordinal]))
                assert occupied in {frozenset(_expand(choice.points)) for choice in domain.choices}
            # Only the ancestor can free a left detour; only the sibling can
            # free a right detour. These alternatives were deleted earlier.
            if not sibling_escape:
                assert selected[0] != domains[0]._decode(0, budget).path.points
                assert any(y >= 10 and z == 3 for _, y, z in selected[3])
            if not ancestor_escape:
                assert selected[1] != domains[1]._decode(0, budget).path.points
                assert any(x >= 15 and z == 3 for x, _, z in selected[4])
        outcomes.append(
            {
                "ancestor_escape": ancestor_escape,
                "sibling_escape": sibling_escape,
                "feasible": expected,
                "backjump": observed,
                "work": dict(budget.counts),
            }
        )
    return outcomes


def _incomplete_cases() -> dict[str, object]:
    _, original_domains = fixture()
    left_domain, right_domain = original_domains[2:]
    budget = WorkBudget(time.monotonic() + 10)
    left = left_domain._decode(0, budget)
    detour = left_domain._decode(1, budget)
    right = right_domain._decode(0, budget)
    # The only support lies beyond the first failed probe. A local cutoff must
    # remain unknown both for this satisfiable pair and a truly unsupported one.
    compatible = {0: [(0, left), (1, detour)], 1: [(0, right)]}
    unsupported = {0: [(0, left), (1, left)], 1: [(0, right)]}
    assert frozenset(_expand(left.path.points)) & frozenset(_expand(right.path.points))
    assert not frozenset(_expand(detour.path.points)) & frozenset(_expand(right.path.points))
    with patch.object(paths, "_JOINT_PAIR_LIMIT", 1):
        assert paths._joint_conflict(compatible, [0, 2], paths._PairCache(), budget) is None
        assert paths._joint_conflict(unsupported, [0, 2], paths._PairCache(), budget) is None
    with patch.object(paths, "_JOINT_PAIR_LIMIT", 2):
        assert paths._joint_conflict(compatible, [0, 2], paths._PairCache(), budget) is None
        assert paths._joint_conflict(unsupported, [0, 2], paths._PairCache(), budget) == (0, 1)

    stone = original_domains[1]._decode(0, budget).path
    problem, domains = _finite(((stone,), (left.path, detour.path), (right.path, right.path)))
    assert exhaustive(problem, domains)
    with patch.object(paths, "_JOINT_PAIR_LIMIT", 1):
        selected = solve(problem, domains, budget)
    _assert_selected(problem, selected)
    assert selected[1] == detour.path.points
    return {
        "incomplete_compatible_pair": "unknown",
        "incomplete_unsupported_pair": "unknown",
        "complete_unsupported_pair": [0, 1],
        "compatible_solution_after_local_cutoff": True,
        "work": dict(budget.counts),
    }


def run() -> dict[str, object]:
    problem, domains = fixture()
    assert exhaustive(problem, domains)
    budget = WorkBudget(time.monotonic() + 10, replace(WorkLimits(), assignments=8))
    selected = solve(problem, domains, budget)
    _assert_selected(problem, selected)
    result: dict[str, object] = {
        "bounded_escape_work": dict(budget.counts),
        "assignment_cap": 8,
        "joint_blocker_exhaustive_cases": _blocker_cases(),
        "incomplete_local_checks": _incomplete_cases(),
    }
    (Path(__file__).parent / "template-joint-witness.json").write_text(json.dumps(result, indent=2))
    return result


if __name__ == "__main__":
    print(json.dumps(run()))
