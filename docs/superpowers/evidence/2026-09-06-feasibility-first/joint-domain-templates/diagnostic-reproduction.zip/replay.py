"""Observe an extracted frozen revision without changing selector decisions."""

from __future__ import annotations

import argparse
import hashlib
import importlib
import json
import sys
import tempfile
import zipfile
from pathlib import Path
from unittest.mock import patch


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("archive", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    with tempfile.TemporaryDirectory(prefix="joint-replay-") as temporary:
        with zipfile.ZipFile(args.archive) as archive:
            archive.extractall(temporary)
        prefix = "2026-09-09-joint-domain-templates"
        package = Path(temporary) / prefix
        sys.path.insert(0, temporary)
        paths = importlib.import_module(prefix + ".template_paths")
        experiment = importlib.import_module(prefix + ".template_experiment")
        routing = importlib.import_module("flab2bp.layout.routing_domain")
        policy = json.loads((package / "template-policy.json").read_text())
        for name, digest in policy["source_sha256"].items():
            assert hashlib.sha256((package / name).read_bytes()).hexdigest() == digest
        reference = json.loads((package / "template-cases/three-output/result.json").read_text())
        original_joint = paths._joint_conflict
        original_decode = paths.Domain._decode
        events = []
        assignments = []
        last_assignment = -1
        max_depth = 0
        joint_calls = 0
        joint_predicates = 0

        def search_state():
            frame = sys._getframe(1)
            while frame is not None:
                if frame.f_code is paths.select.__code__:
                    return frame.f_locals
                frame = frame.f_back
            return None

        def decode(domain, candidate, budget):
            nonlocal last_assignment, max_depth
            state = search_state()
            if state is not None:
                selected = state.get("selected", {})
                max_depth = max(max_depth, len(selected))
                assignment = budget.counts.get("assignments", 0)
                if assignment != last_assignment:
                    last_assignment = assignment
                    domains = state["ds"]
                    assignments.append(
                        {
                            "assignment": assignment,
                            "trying_obligation": domain.obligation.ordinal,
                            "candidate": candidate,
                            "selected": {
                                domains[i].obligation.ordinal: ci for i, (ci, _) in selected.items()
                            },
                            "work": dict(budget.counts),
                        }
                    )
            return original_decode(domain, candidate, budget)

        def joint(residuals, offsets, cache, budget):
            nonlocal joint_calls, joint_predicates
            joint_calls += 1
            before = budget.counts.get("predicates", 0)
            try:
                result = original_joint(residuals, offsets, cache, budget)
            finally:
                joint_predicates += budget.counts.get("predicates", 0) - before
            if result is not None:
                state = search_state()
                assert state is not None
                domains = state["ds"]
                owners = {
                    owner
                    for owner, deletions in state["pruned"].items()
                    if any(di in result for di, _ in deletions)
                }
                chosen = state["selected"]
                events.append(
                    {
                        "targets": [domains[i].obligation.ordinal for i in result],
                        "residual_sizes": [len(residuals[i]) for i in result],
                        "selected": {
                            domains[i].obligation.ordinal: ci for i, (ci, _) in chosen.items()
                        },
                        "explaining_owners": sorted(domains[i].obligation.ordinal for i in owners),
                        "work": dict(budget.counts),
                    }
                )
            return result

        with (
            patch.object(paths, "_joint_conflict", joint),
            patch.object(paths.Domain, "_decode", decode),
            patch.object(
                routing, "_route_all", side_effect=AssertionError("global router forbidden")
            ) as router,
        ):
            result = experiment.execute("three-output", "GEOMETRY_ONLY")
            assert router.call_count == 0
        same = result["outcome"] == reference["outcome"] and result["work"] == reference["work"]
        assert same, (reference["work"], result["work"])
        report = {
            "same_frozen_outcome_and_counters": same,
            "result": result,
            "maximum_selected_depth_observed": max_depth,
            "joint_calls": joint_calls,
            "joint_predicates": joint_predicates,
            "joint_contradictions": events,
            "assignments": assignments,
        }
        args.output.write_text(json.dumps(report, indent=2))
        print(json.dumps({k: v for k, v in report.items() if k not in ("assignments", "result")}))


if __name__ == "__main__":
    main()
