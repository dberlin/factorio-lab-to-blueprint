"""Exercise public construction, process deadlines, and production portfolio dispatch."""
from __future__ import annotations
import argparse
import json
import multiprocessing
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / "src"))
from flab2bp import pipeline
from flab2bp.dsp import codec
from flab2bp.lab.data import load_vendored
from flab2bp.lab.flow import canonicalize_dataset
from flab2bp.lab.techs import belt_rules_for_url
from flab2bp.layout.base import NoValidLayout
from flab2bp.layout.transport_routing.strategy import TransportRoutingLayout
from flab2bp.spec import BuildSpec


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("surface", choices=("layout", "pipeline", "best", "deadline"))
    args = parser.parse_args()
    saved = ROOT / ".superpowers/sdd/2026-09-10-cadical-settlement-trace/frozen"
    manifest = json.loads((saved / "manifest.json").read_text())
    entry = next(row for row in manifest if row["name"] == "three-output")
    spec = BuildSpec.model_validate_json((saved / "three-output.json").read_bytes())
    rules = belt_rules_for_url(entry["url"], canonicalize_dataset(load_vendored()))
    started = time.monotonic()
    if args.surface in ("layout", "deadline"):
        strategy = TransportRoutingLayout(belt_rules=rules)
        try:
            placement = strategy.lay_out(spec, time_budget_s=0.01 if args.surface == "deadline" else 30)
        except NoValidLayout as exc:
            assert args.surface == "deadline" and "DEADLINE" in exc.reason
            result = {"surface": args.surface, "reason": exc.reason}
        else:
            assert args.surface == "layout"
            decoded = codec.decode(codec.encode(placement))
            result = {"surface": args.surface, "buildings": len(decoded.buildings), "stats": placement.stats}
    else:
        events = []
        built = pipeline.build(
            entry["url"], strategy="best" if args.surface == "best" else "transport-routing",
            time_budget_s=30, no_proliferator=True, workers=16,
            on_progress=lambda event: events.append((event.strategy, event.phase)),
            race=args.surface == "best",
        )
        assert built.report.ok and not built.report.skipped
        assert len(codec.decode(built.blueprint).buildings) == len(built.placement.buildings)
        result = {"surface": args.surface, "strategy": built.strategy, "checks": len(built.report.checks_run),
                  "events": events, "attempts": [attempt.strategy for attempt in built.attempts],
                  "refused": [failure.strategy for failure in built.refused]}
        if args.surface == "best":
            assert {strategy for strategy, phase in events if phase == "started"} == set(pipeline.PRODUCTION_STRATEGIES)
    assert not multiprocessing.active_children(), multiprocessing.active_children()
    result["seconds"] = time.monotonic() - started
    output = Path(__file__).parent / f"public-transport-{args.surface}.json"
    output.write_text(json.dumps(result, indent=2))
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
