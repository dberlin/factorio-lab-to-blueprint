"""Independent final public-strategy acceptance against frozen factory specs."""
from __future__ import annotations

import json
import multiprocessing
import sys
import time
from dataclasses import asdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / "src"))
from flab2bp.dsp import codec
from flab2bp.lab.data import load_vendored
from flab2bp.lab.flow import canonicalize_dataset
from flab2bp.lab.techs import belt_rules_for_url
from flab2bp.layout import validate
from flab2bp.layout.transport_routing.strategy import TransportRoutingLayout
from flab2bp.spec import BuildSpec


def main() -> None:
    saved = ROOT / ".superpowers/sdd/2026-09-10-cadical-settlement-trace/frozen"
    manifest = json.loads((saved / "manifest.json").read_text())
    records = []
    for case, budget in (("three-output", 30), ("unsprayed-mall", 60)):
        entry = next(row for row in manifest if row["name"] == case)
        spec = BuildSpec.model_validate_json((saved / f"{case}.json").read_bytes())
        rules = belt_rules_for_url(entry["url"], canonicalize_dataset(load_vendored()))
        started = time.monotonic()
        placement = TransportRoutingLayout(belt_rules=rules).lay_out(spec, time_budget_s=budget)
        layout_s = time.monotonic() - started
        report = validate.certify(placement, spec, belt_rules=rules, expect_power=True)
        decoded = codec.decode(codec.encode(placement))
        record = {"case": case, "budget_s": budget, "layout_s": layout_s,
                  "total_s": time.monotonic() - started, "buildings": len(decoded.buildings),
                  "area": placement.area, "checks": len(report.checks_run),
                  "errors": [asdict(error) for error in report.errors], "skipped": report.skipped,
                  "children_remaining": len(multiprocessing.active_children())}
        records.append(record)
        print(json.dumps(record, default=str), flush=True)
        assert report.ok and not report.skipped
        assert len(decoded.buildings) == len(placement.buildings)
        assert not multiprocessing.active_children()
    (Path(__file__).parent / "final-transport-factories.json").write_text(json.dumps(records, indent=2))


if __name__ == "__main__":
    main()
