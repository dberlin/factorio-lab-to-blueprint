"""Exercise the promoted source against preserved original factory inputs."""
from __future__ import annotations
import argparse
import json
import sys
import time
from dataclasses import asdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / "src"))
from flab2bp.dsp import codec
from flab2bp.lab.data import load_vendored
from flab2bp.lab.flow import canonicalize_dataset
from flab2bp.lab.techs import belt_rules_for_url
from flab2bp.layout import finalize, markers, validate
from flab2bp.layout.band_policy import BandPolicy
from flab2bp.layout.transport_routing.budget import WorkBudget
from flab2bp.layout.transport_routing.composition import construct
from flab2bp.layout.transport_routing.routing import RoutingRun
from flab2bp.spec import BuildSpec


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("case", choices=("three-output", "unsprayed-mall"))
    args = parser.parse_args()
    saved = ROOT / ".superpowers/sdd/2026-09-10-cadical-settlement-trace/frozen"
    manifest = json.loads((saved / "manifest.json").read_text())
    entry = next(row for row in manifest if row["name"] == args.case)
    spec = BuildSpec.model_validate_json((saved / f"{args.case}.json").read_bytes())
    rules = belt_rules_for_url(entry["url"], canonicalize_dataset(load_vendored()))
    started = time.monotonic()
    budget = WorkBudget(started + (30 if args.case == "three-output" else 60))
    session = RoutingRun(budget)
    policy = BandPolicy("portable")
    placement = construct(spec, rules, policy, session)
    constructed_s = time.monotonic() - started
    raw_placement = placement
    print(json.dumps({"stage": "constructed", "seconds": constructed_s, "work": budget.counts}), flush=True)
    placement = finalize.compact_open_boundary_belts(placement, spec, expect_power=True, belt_rules=rules)
    print(json.dumps({"stage": "compacted", "seconds": time.monotonic()-started}), flush=True)
    try:
        placement = finalize.finalize_placement(placement, policy, cancelled=lambda: time.monotonic() >= budget.deadline)
    except Exception:
        from pydantic import TypeAdapter
        from flab2bp.layout.base import PlacedBuilding
        output = Path(__file__).parent
        serializer = TypeAdapter(tuple[PlacedBuilding, ...])
        (output / f"{args.case}-native-raw.json").write_bytes(serializer.dump_json(raw_placement.buildings))
        (output / f"{args.case}-native-compacted.json").write_bytes(serializer.dump_json(placement.buildings))
        print(json.dumps({"stage": "projection-refused", "seconds": time.monotonic()-started}), flush=True)
        raise
    report = validate.certify(placement, spec, belt_rules=rules, expect_power=True)
    blueprint = codec.encode(markers.mark_external_belts(placement, spec))
    decoded = codec.decode(blueprint)
    result = {"case": args.case, "constructed_s": constructed_s, "total_s": time.monotonic()-started,
              "buildings": len(decoded.buildings), "area": placement.area,
              "checks": len(report.checks_run), "skipped": report.skipped,
              "errors": [asdict(error) for error in report.errors], "work": budget.counts}
    print(json.dumps(result, default=str), flush=True)
    assert not report.errors and not report.skipped
    budget.check()


if __name__ == "__main__":
    main()
