"""Retain complete command output while returning a bounded terminal summary."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
if __name__ == '__main__':
    name, *command = sys.argv[1:]
    environment = os.environ.copy()
    environment['PYTHONPATH'] = str(ROOT / 'src')
    environment['VIRTUAL_ENV'] = str(ROOT / '.venv')
    started = time.monotonic()
    completed = subprocess.run(command, cwd=ROOT, env=environment, capture_output=True, text=True, timeout=1200)
    record = {'command': command, 'exit': completed.returncode, 'seconds': time.monotonic() - started,
              'stdout': completed.stdout, 'stderr': completed.stderr}
    output = Path(__file__).parent / f'{name}.json'
    output.write_text(json.dumps(record, indent=2))
    print(json.dumps({'name': name, 'exit': completed.returncode, 'seconds': record['seconds'],
                      'output': str(output), 'summary': completed.stdout[-1200:], 'stderr': completed.stderr[-300:]}), flush=True)
    sys.exit(completed.returncode)
