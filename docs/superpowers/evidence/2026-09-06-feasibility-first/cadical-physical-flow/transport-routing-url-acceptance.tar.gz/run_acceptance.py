"""Retain real default web-worker and literal CLI outcomes at requested budgets."""
from __future__ import annotations
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
WORK = ROOT.parents[2]
sys.path.insert(0, str(WORK / 'src'))
from flab2bp import pipeline
from flab2bp.dsp import codec
from diagnose_url import URL as ORIGINAL_URL
from preserve_variant import URL as SIMPLER_URL


def run_case(case: tuple[str, int], surface: str) -> dict:
    name, budget = case
    url = ORIGINAL_URL if name == 'original' else SIMPLER_URL
    dest = ROOT / 'evidence' / name / f'{surface}-{budget}s'
    dest.mkdir(parents=True, exist_ok=True)
    environment = os.environ.copy()
    environment['PYTHONPATH'] = str(WORK / 'src')
    environment['VIRTUAL_ENV'] = str(WORK / '.venv')
    if surface == 'web':
        command = [sys.executable, str(ROOT / 'run_public.py'), name, 'web', str(budget)]
    else:
        command = [sys.executable, '-m', 'flab2bp.cli', url, '--budget', str(budget), '--out', str(dest / 'blueprint.txt')]
        identity = {str(path.relative_to(WORK / 'src')): hashlib.sha256(path.read_bytes()).hexdigest()
                    for path in (WORK / 'src').rglob('*') if path.is_file() and path.suffix in ('.py', '.pyx', '.so')}
        (dest / 'source-hashes.json').write_text(json.dumps(identity, indent=2))
    started = time.monotonic()
    completed = subprocess.run(command, cwd=WORK, env=environment, capture_output=True, text=True, timeout=budget * 9 + 120)
    (dest / 'stdout.txt').write_text(completed.stdout)
    (dest / 'stderr.txt').write_text(completed.stderr)
    result = {'request': name, 'surface': surface, 'budget_s': budget, 'command': command,
              'exit': completed.returncode, 'elapsed_s': time.monotonic() - started,
              'status': 'success' if completed.returncode == 0 else 'refused' if completed.returncode == 3 else 'error',
              'workers': min(pipeline._available_cpu_count(), pipeline.DEFAULT_WORKER_BUDGET_CAP),
              'strategies': pipeline.PRODUCTION_STRATEGIES, 'source': pipeline.__file__}
    if completed.returncode == 0:
        decoded = codec.decode((dest / 'blueprint.txt').read_text().strip())
        result['decoded_buildings'] = len(decoded.buildings)
    (dest / 'command-result.json').write_text(json.dumps(result, indent=2))
    print(json.dumps({key: value for key, value in result.items() if key not in ('command', 'source')}), flush=True)
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('surface', choices=('web', 'literal-cli'))
    args = parser.parse_args()
    cases = [(name, budget) for name in ('original', 'simpler-variant') for budget in (15, 30, 60)]
    with ThreadPoolExecutor(max_workers=3) as pool:
        results = list(pool.map(lambda case: run_case(case, args.surface), cases))
    (ROOT / f'{args.surface}-results.json').write_text(json.dumps(results, indent=2))
    raise SystemExit(0 if all(result['exit'] == 0 for result in results) else 1)
