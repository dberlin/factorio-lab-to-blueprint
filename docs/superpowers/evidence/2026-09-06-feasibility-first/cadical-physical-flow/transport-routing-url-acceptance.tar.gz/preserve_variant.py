import json, pathlib, sys, time
from flab2bp import pipeline
from diagnose_url import encode
URL = 'https://factoriolab.github.io/dsp/list?z=eJzLt3UyUMu3LdUyNDAw0NIyVMu3TdIyVcu3dYqCUJVIMgEgNoTp5I4kXoUkXo4k7hSIJBEGY2cmpdo6qRWlVtjGq-XmFtkW1BXXZdYFqpXZGhoCAJ0uJB0_&v=11'
ROOT = pathlib.Path(__file__).resolve().parent
if __name__ == '__main__':
    started = time.monotonic()
    data = pipeline.canonicalize_dataset(pipeline.load_vendored())
    request = pipeline.canonicalize_request(pipeline.parse_url(URL))
    specs = pipeline._build_candidates_canonical(data, request, power_tower_item_id=pipeline._resolve_power_tower(None, request))
    dest = ROOT/'simpler-variant'; dest.mkdir(exist_ok=True)
    (dest/'request.json').write_text(json.dumps(encode(request), indent=2)+'\n')
    (dest/'specs.json').write_text(json.dumps(encode(specs), indent=2)+'\n')
    result = {'url':URL, 'command':sys.argv, 'source':pipeline.__file__, 'elapsed_s':time.monotonic()-started, 'candidates':[{'label':s.label,'groups':len(s.groups),'machines':s.machine_count,'outputs':encode(s.outputs)} for s in specs.candidates]}
    (dest/'decode.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result, indent=2))
