from __future__ import annotations
import argparse, hashlib, json, os, pathlib, pickle, sys, time, traceback
from flab2bp import pipeline
from flab2bp.layout.base import NoValidLayout
from flab2bp.web.jobs import Options, run_build
from flab2bp.web.payload import describe, refusal
from diagnose_url import URL as ORIGINAL_URL, encode
from preserve_variant import URL as SIMPLER_URL

ROOT = pathlib.Path(__file__).resolve().parent
if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('request', choices=('original','simpler-variant'))
    parser.add_argument('surface', choices=('web','cli'))
    parser.add_argument('budget', type=float)
    args = parser.parse_args()
    url = ORIGINAL_URL if args.request == 'original' else SIMPLER_URL
    dest = ROOT/'evidence'/args.request/f'{args.surface}-{args.budget:g}s'
    dest.mkdir(parents=True, exist_ok=True)
    source_root = pathlib.Path(pipeline.__file__).resolve().parent
    identity = {str(p.relative_to(source_root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in source_root.rglob('*') if p.is_file() and p.suffix in ('.py','.pyx','.so')}
    (dest/'source-hashes.json').write_text(json.dumps(identity,indent=2)+'\n')
    started = time.monotonic()
    outcome = {'command':sys.argv,'cwd':os.getcwd(),'source':pipeline.__file__,'url':url,'surface':args.surface,'budget_s':args.budget,'python':sys.version,'workers':min(pipeline._available_cpu_count(), pipeline.DEFAULT_WORKER_BUDGET_CAP),'strategy':'best','candidate_policy':'all three defaults','band':'portable','race':args.surface=='web'}
    def note(step):
        event = {'elapsed_s':time.monotonic()-started,'step':encode(step)}
        with (dest/'progress.jsonl').open('a') as stream: stream.write(json.dumps(event)+'\n')
    try:
        build = run_build(Options(url=url,budget_s=args.budget),note) if args.surface=='web' else pipeline.build(url,time_budget_s=args.budget,on_progress=note)
        outcome.update(status='success',report_ok=build.report.ok,strategy_selected=build.strategy,candidate_selected=build.spec.label)
        (dest/'blueprint.txt').write_text(build.blueprint+'\n')
        (dest/'payload.json').write_text(json.dumps(describe(build),indent=2)+'\n')
    except NoValidLayout as exc:
        outcome.update(status='refused',reason=str(exc),details=encode(vars(exc)))
        (dest/'refusal.json').write_text(json.dumps(refusal(exc.attempt_failures,message=str(exc)),indent=2,allow_nan=False)+'\n')
    except BaseException as exc:
        outcome.update(status='error',reason=repr(exc),traceback=traceback.format_exc())
    outcome['elapsed_s'] = time.monotonic()-started
    (dest/'terminal.json').write_text(json.dumps(outcome,indent=2)+'\n')
    print(json.dumps({k:v for k,v in outcome.items() if k not in ('details','reason')},indent=2))
    raise SystemExit(0 if outcome['status']=='success' else 3 if outcome['status']=='refused' else 2)
